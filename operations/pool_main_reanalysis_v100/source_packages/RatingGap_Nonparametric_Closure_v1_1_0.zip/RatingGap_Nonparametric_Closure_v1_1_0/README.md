# RatingGap Nonparametric Closure v1.1.0

## What changed

v1.1.0 keeps the v1.0.x scientific specification but replaces the execution
engine with a Parquet-first, parallel, resumable workflow.

### Storage
- Every tabular intermediate and public output is Parquet + ZSTD.
- JSON is used only for small receipts/settings/progress.
- No CSV roundtrips.
- Private cache is partitioned by `eval_band` and `month` to create natural
  Parquet shards and improve pruning/concurrent streaming.

### Parallel execution
- Preprocessing uses DuckDB with 8 threads.
- Model estimation runs in multiple independent processes.
- Worker count, worker threads, and worker DuckDB memory are automatically
  chosen from physical RAM and logical CPU count.
- Maximum model workers is 8.
- Each worker has its own DuckDB temp/spill directory.
- This avoids nested BLAS/OpenMP oversubscription and allows safe disk spill.

### Resume
Each model writes:
- `models/<model>_coefficients.parquet`
- `models/<model>_receipt.json`

The receipt stores the coefficient-Parquet SHA-256. On rerun, completed models
authenticate and skip. Partial/failed models rerun.

## Scientific design

Unchanged from v1.0.x:
- 50-Elo bins, omitted `[-25,+25)`.
- Chooser FE.
- Chooser-clustered CR1.
- K20 primary.
- K50 closure.
- stable RD/K restriction.
- year-by-year replication.
- common-support weaker/equal and stronger/equal contrasts.
- five board-evaluation bands.
- all, <=10 ply, >10 ply.

## Source

Authenticated private cache from the completed K/RD decomposition:
`/Volumes/XT_Pro/lichess_kindness/output/rating_gap_krd_decomposition_20260831T183339Z/private_cache/rating_gap_krd_derived_private.parquet`

## Expected runtime

Roughly 45-180 minutes, most likely 75-120 minutes. Actual worker count is
printed before model estimation.

## Privacy

Never upload or commit:
- `private_cache/`
- `private_cache_inventory.parquet`

The launcher lists the public Parquet outputs safe to return.
