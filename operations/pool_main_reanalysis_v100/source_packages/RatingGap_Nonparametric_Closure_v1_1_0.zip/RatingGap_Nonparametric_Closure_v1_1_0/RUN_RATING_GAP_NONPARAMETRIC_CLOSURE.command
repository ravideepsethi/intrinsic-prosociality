#!/bin/bash
set -euo pipefail

ROOT="/Volumes/XT_Pro/lichess_kindness"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_PY="$ROOT/venv/bin/python"
ANALYSIS="$SCRIPT_DIR/rating_gap_nonparametric_closure_parallel.py"
RENDER="$SCRIPT_DIR/render_rating_gap_nonparametric_closure.py"

[[ -d "$ROOT" ]] || { echo "ERROR: project root not mounted: $ROOT" >&2; exit 1; }
[[ -x "$PROJECT_PY" ]] || { echo "ERROR: project Python missing: $PROJECT_PY" >&2; exit 1; }

PLOT_PY=""
try_plot_python() {
  local c="$1"
  [[ -n "$c" && -x "$c" ]] || return 1
  "$c" - <<'PY' >/dev/null 2>&1
import numpy, pandas, pyarrow, matplotlib
PY
}
if try_plot_python "/opt/anaconda3/bin/python"; then
  PLOT_PY="/opt/anaconda3/bin/python"
elif [[ -n "${CONDA_PREFIX:-}" ]] && try_plot_python "$CONDA_PREFIX/bin/python"; then
  PLOT_PY="$CONDA_PREFIX/bin/python"
elif try_plot_python "$PROJECT_PY"; then
  PLOT_PY="$PROJECT_PY"
else
  echo "ERROR: no existing plotting Python with pandas+pyarrow+matplotlib." >&2
  exit 1
fi

# New stable root: do not mix v1.1.0 engineering lineage with v1.0.x outputs.
OUT="$ROOT/output/RATING_GAP_NONPARAMETRIC_CLOSURE_V110"
LOGDIR="$ROOT/logs/rating_gap_nonparametric_closure"
mkdir -p "$LOGDIR"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
LOG="$LOGDIR/rating_gap_nonparametric_closure_v110_${STAMP}.log"

printf 'RATING-GAP NONPARAMETRIC CLOSURE v1.1.0 — PARQUET-FIRST PARALLEL\n'
printf 'Scientific design: unchanged from v1.0.x.\n'
printf 'Storage: Parquet-first for all tabular intermediates and outputs.\n'
printf 'Preprocessing: DuckDB 8 threads.\n'
printf 'Models: automatic multi-process workers sized to CPU/RAM; per-worker DuckDB spill enabled.\n'
printf 'Expected runtime: roughly 45-180 minutes; most likely 75-120 minutes.\n'
printf 'The run is model-level resumable; rerun this exact launcher after interruption.\n'
printf 'No API requests. No mutation of canonical Stage 07 or canonical Python env.\n'
printf 'Output root: %s\n' "$OUT"
printf 'Log: %s\n\n' "$LOG"

export PYTHONDONTWRITEBYTECODE=1
export OMP_NUM_THREADS=1
export MKL_NUM_THREADS=1
export VECLIB_MAXIMUM_THREADS=1
export NUMEXPR_NUM_THREADS=1

printf 'Running synthetic estimator self-test...\n'
"$PROJECT_PY" -u "$ANALYSIS" --self-test

set +e
/usr/bin/caffeinate -dimsu "$PROJECT_PY" -u "$ANALYSIS" \
  --out-root "$OUT" \
  --prep-threads 8 \
  --prep-memory-limit 12GB \
  --model-workers 0 \
  --worker-threads 0 \
  2>&1 | tee "$LOG"
STATUS="${PIPESTATUS[0]}"
set -e

if [[ "$STATUS" -ne 0 ]]; then
  printf '\nERROR: v1.1.0 closure stopped with code %s.\n' "$STATUS" >&2
  printf 'Rerun this exact launcher: authenticated completed model Parquets will skip.\n' >&2
  printf 'Log: %s\n' "$LOG" >&2
  exit "$STATUS"
fi

"$PLOT_PY" -u "$RENDER" --out-root "$OUT" 2>&1 | tee -a "$LOG"

for f in \
  source_authentication.json \
  00_private_cache_receipt.json \
  private_cache_inventory.parquet \
  00_descriptive_rating_gap_curves.parquet \
  common_support_chooser_equal_differences.parquet \
  model_plan.parquet \
  fe_nonparametric_coefficients.parquet \
  fe_nonparametric_curves.parquet \
  fe_nonparametric_receipts.parquet \
  settings.json
do
  [[ -s "$OUT/$f" ]] || {
    echo "ERROR: expected output missing/empty: $OUT/$f" >&2
    exit 1
  }
done

printf '\nRATING_GAP_NONPARAMETRIC_CLOSURE_V110_COMPLETE\n'
printf 'Output root: %s\n' "$OUT"
printf 'Log: %s\n' "$LOG"

printf '\nUPLOAD THESE PUBLIC FILES:\n'
printf '  %s\n' "$OUT/00_descriptive_rating_gap_curves.parquet"
printf '  %s\n' "$OUT/common_support_chooser_equal_differences.parquet"
printf '  %s\n' "$OUT/fe_nonparametric_curves.parquet"
printf '  %s\n' "$OUT/fe_nonparametric_coefficients.parquet"
printf '  %s\n' "$OUT/fe_nonparametric_receipts.parquet"
printf '  %s\n' "$OUT/model_plan.parquet"
printf '  %s\n' "$OUT/settings.json"

printf '\nPlots:\n'
printf '  %s\n' "$OUT/plots"

printf '\nDO NOT UPLOAD OR COMMIT:\n'
printf '  %s\n' "$OUT/private_cache"
printf '  %s\n' "$OUT/private_cache_inventory.parquet"

