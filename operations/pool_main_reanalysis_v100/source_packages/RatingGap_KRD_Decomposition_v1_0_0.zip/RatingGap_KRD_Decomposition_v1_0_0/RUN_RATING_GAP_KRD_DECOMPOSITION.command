#!/bin/bash
set -euo pipefail

ROOT="/Volumes/XT_Pro/lichess_kindness"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_PY="$ROOT/venv/bin/python"
ANALYSIS="$SCRIPT_DIR/rating_gap_krd_decomposition.py"
RENDER="$SCRIPT_DIR/render_rating_gap_krd.py"

[[ -d "$ROOT" ]] || { echo "ERROR: project root not mounted: $ROOT" >&2; exit 1; }
[[ -x "$PROJECT_PY" ]] || { echo "ERROR: canonical project Python missing: $PROJECT_PY" >&2; exit 1; }

PLOT_PY=""
try_plot_python() {
    local c="$1"
    [[ -n "$c" && -x "$c" ]] || return 1
    "$c" - <<'PY' >/dev/null 2>&1
import numpy, pandas, matplotlib
PY
}
if try_plot_python "/opt/anaconda3/bin/python"; then
    PLOT_PY="/opt/anaconda3/bin/python"
elif [[ -n "${CONDA_PREFIX:-}" ]] && try_plot_python "$CONDA_PREFIX/bin/python"; then
    PLOT_PY="$CONDA_PREFIX/bin/python"
elif try_plot_python "$PROJECT_PY"; then
    PLOT_PY="$PROJECT_PY"
else
    echo "ERROR: no existing plotting Python with matplotlib." >&2
    exit 1
fi

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT="$ROOT/output/rating_gap_krd_decomposition_${STAMP}"
LOGDIR="$ROOT/logs/rating_gap_krd"
mkdir -p "$LOGDIR"
LOG="$LOGDIR/rating_gap_krd_${STAMP}.log"

printf 'RATING-GAP / EXPECTED-SCORE / K-RD DECOMPOSITION\n'
printf 'Scientific status: exploratory diagnostic prompted by the observed surface.\n'
printf 'Expected runtime: about 25-90 minutes; most likely 35-60 minutes.\n'
printf 'The run is read-only with respect to canonical Stage 07 data.\n'
printf 'A private compressed derived cache will be written only inside the new output root.\n'
printf 'Aggregation/regression Python: %s\n' "$PROJECT_PY"
printf 'Rendering Python:              %s\n' "$PLOT_PY"
printf 'Output:                        %s\n' "$OUT"
printf 'Log:                           %s\n\n' "$LOG"

export PYTHONDONTWRITEBYTECODE=1
export OMP_NUM_THREADS=1
export MKL_NUM_THREADS=1
export VECLIB_MAXIMUM_THREADS=1
export NUMEXPR_NUM_THREADS=1

set +e
/usr/bin/caffeinate -dimsu /bin/bash -lc "
  '$PROJECT_PY' -u '$ANALYSIS' --out-root '$OUT' --threads 8 --memory-limit 12GB &&
  '$PLOT_PY' -u '$RENDER' --out-root '$OUT' --min-n 500
" 2>&1 | tee "$LOG"
STATUS="${PIPESTATUS[0]}"
set -e

if [[ "$STATUS" -ne 0 ]]; then
    printf '\nERROR: decomposition stopped with code %s.\n' "$STATUS" >&2
    printf 'Log: %s\n' "$LOG" >&2
    exit "$STATUS"
fi

for f in \
    mechanical_validation.csv \
    rating_gap_broad_rates.csv \
    rating_gap_u_metrics.csv \
    rating_gap_curves.csv \
    expected_score_curves.csv \
    krd_descriptives.csv \
    fe_model_coefficients.csv \
    fe_model_band_contrasts.csv \
    fe_model_receipts.csv \
    settings.json
do
    [[ -s "$OUT/$f" ]] || {
        echo "ERROR: missing expected public output: $OUT/$f" >&2
        exit 1
    }
done

printf '\nRATING_GAP_KRD_DECOMPOSITION_COMPLETE\n'
printf 'Output root: %s\n' "$OUT"
printf 'Log: %s\n' "$LOG"
printf '\nUPLOAD THESE PUBLIC FILES FIRST:\n'
printf '  %s\n' "$OUT/mechanical_validation.csv"
printf '  %s\n' "$OUT/rating_gap_broad_rates.csv"
printf '  %s\n' "$OUT/rating_gap_u_metrics.csv"
printf '  %s\n' "$OUT/krd_descriptives.csv"
printf '  %s\n' "$OUT/fe_model_coefficients.csv"
printf '  %s\n' "$OUT/fe_model_band_contrasts.csv"
printf '  %s\n' "$OUT/fe_model_receipts.csv"
printf '  %s\n' "$OUT/settings.json"
printf '\nDO NOT UPLOAD OR COMMIT:\n'
printf '  %s\n' "$OUT/private_cache"
printf '\nPlots:\n'
printf '  %s\n' "$OUT/plots"
