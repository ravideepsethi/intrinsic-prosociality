RatingGap_KRD_Decomposition v1.0.0
Prepared 2026-08-31

Purpose
=======
Decompose the newly observed asymmetric U-shape in kindness into:

1. displayed rating distance;
2. expected-score distance;
3. Glicko update scale K / rating-deviation mechanics;
4. chooser composition versus within-chooser behavior;
5. early (<=10 ply) versus later (>10 ply) games.

This is exploratory analysis prompted by an observed descriptive surface. It is
not a preregistered or confirmatory result family.

Authority
=========
Certified Stage 07:
  /Volumes/XT_Pro/lichess_kindness/derived/replication/analysis_panel_24m_sf100k

Expected:
  47,587,020 rows
  24 months, 2023-11 through 2025-10
  Stockfish 18 nodes=100,000

The script authenticates the authority before analysis.

Important privacy rule
======================
The run creates:
  private_cache/rating_gap_krd_derived_private.parquet

That file contains chooser identifiers. DO NOT upload it, publish it, or commit
it to Git. The CSV outputs requested by the launcher are aggregate/model outputs.

Main outputs
============
mechanical_validation.csv
  Verifies the reconstructed Glicko K*(0.5-E) decomposition against the
  certified chooser_draw_payoff_v2 and reports mechanical correlations.

rating_gap_broad_rates.csv / rating_gap_u_metrics.csv
  Coarse raw U-shape in actual displayed Elo distance.

rating_gap_curves.csv
  Fine curves in displayed Elo distance, by board state, game stage, and year.

expected_score_curves.csv
  Fine curves in |expected score - 0.5|.

krd_descriptives.csv
  Rating distance, expected-score distance, K, chooser RD, opponent RD.

fe_model_coefficients.csv
  Chooser-FE LPM coefficients with chooser-clustered CR1 inference.

fe_model_band_contrasts.csv
  Intuitive fitted left-arm/right-arm changes from the FE models.

fe_model_receipts.csv
  N, chooser clusters, matrix rank, condition number, runtime, dropped terms.

Expected runtime
================
25-90 minutes; most likely 35-60 minutes on the canonical machine.
The expensive step is the chooser-FE clustered inference, not aggregation.

No API requests. No mutation of the canonical environment.
