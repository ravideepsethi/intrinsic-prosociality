#!/usr/bin/env python3
"""Recover v1.0.0's persisted tables without modifying its database.

No network requests, dependency installation, source-table rewriting, or global
billions-of-rows window query. Large intermediates are private ZSTD Parquets.
Only DuckDB and the Python standard library are required.
"""
from __future__ import annotations
import argparse
import contextlib
import dataclasses
import datetime as dt
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import random
import resource
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import traceback
import uuid
import zipfile
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Callable
from rematch_logic import side_query, census_query

VERSION='1.0.1'
ALGORITHM='user-sharded-observed-adjacency-20260908-v101'
ROOT=Path('/Volumes/XT_Pro/lichess_kindness')
DEFAULT_SOURCE=ROOT/'output/immediate_rematch_census_v100/20260908T031408Z_6459'
EVENT_FIELDS='game_id, utc_ms, archive_ordinal, user_id, opponent_id'
class RecoveryBusy(RuntimeError):
    pass


REQUIRED={
    'focal': {'game_id','p1','p2'},
    'target_users': {'user_id'},
    'relevant_games': {'game_id','utc_ms','archive_ordinal','white_id','black_id'},
    'user_events': {'game_id','utc_ms','archive_ordinal','user_id','opponent_id'},
}
EMPTY_EVENTS='''SELECT CAST(NULL AS VARCHAR) game_id, CAST(NULL AS BIGINT) utc_ms,
    CAST(NULL AS BIGINT) archive_ordinal, CAST(NULL AS BIGINT) user_id,
    CAST(NULL AS BIGINT) opponent_id WHERE FALSE'''
EMPTY_TARGETS='SELECT CAST(NULL AS VARCHAR) game_id, CAST(NULL AS BIGINT) user_id WHERE FALSE'


def utc() -> str:
    return dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')


def log(message: str) -> None:
    print(f'[{utc()}] {message}',flush=True)


def lit(value: Any) -> str:
    return "'"+str(value).replace("'","''")+"'"


def paths_sql(paths: list[Path] | list[str]) -> str:
    if not paths: raise ValueError('Empty Parquet input list')
    return '['+','.join(lit(p) for p in paths)+']'


def parquet_sql(paths: list[Path] | list[str]) -> str:
    return f'read_parquet({paths_sql(paths)}, hive_partitioning=false)'


def sha(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(8*1024*1024),b''): h.update(block)
    return h.hexdigest()


def write_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_name(path.name+'.writing_'+uuid.uuid4().hex)
    with tmp.open('w') as f:
        json.dump(obj,f,indent=2,sort_keys=True,allow_nan=False);f.write('\n')
        f.flush();os.fsync(f.fileno())
    os.replace(tmp,path)


def read_json(path: Path) -> Any:
    return json.loads(path.read_text())


def signature(path: Path) -> dict:
    s=path.stat()
    with path.open('rb') as f: head=hashlib.sha256(f.read(65536)).hexdigest()
    return {'path':str(path.resolve()),'size':s.st_size,'mtime_ns':s.st_mtime_ns,
            'inode':s.st_ino,'device':s.st_dev,'first_64k_sha256':head}


def db_signature(path: Path) -> dict:
    wal=Path(str(path)+'.wal')
    return {'database':signature(path),'wal':signature(wal) if wal.exists() else None,
            'method':'file identity, size, modification time and first 64KiB; NOT a full-content hash'}


def physical_ram() -> int | None:
    try:
        if sys.platform=='darwin':
            return int(subprocess.check_output(['/usr/sbin/sysctl','-n','hw.memsize'],text=True).strip())
        return int(os.sysconf('SC_PAGE_SIZE'))*int(os.sysconf('SC_PHYS_PAGES'))
    except Exception: return None


def fd_limit() -> None:
    soft,hard=resource.getrlimit(resource.RLIMIT_NOFILE)
    desired=4096 if hard==resource.RLIM_INFINITY else min(4096,hard)
    if soft<desired: resource.setrlimit(resource.RLIMIT_NOFILE,(desired,hard))


def connect(temp: Path, memory_gb: float=3, threads: int=1):
    import duckdb
    temp.mkdir(parents=True,exist_ok=True)
    con=duckdb.connect(':memory:',config={
        'threads':str(threads),'memory_limit':f'{memory_gb}GB',
        'preserve_insertion_order':'false','temp_directory':str(temp),
    })
    # Small row groups and a single export thread bound partition-writer buffers.
    # Keep partition writers open to avoid generating millions of tiny files.
    con.execute('SET partitioned_write_max_open_files=2048')
    con.execute('SET partitioned_write_flush_threshold=262144')
    return con


@contextlib.contextmanager
def heartbeat(label: str, enabled: bool=True):
    stop=threading.Event(); started=time.monotonic()
    def tick():
        while not stop.wait(60): log(f'{label}: still running ({(time.monotonic()-started)/60:.1f} min)')
    t=threading.Thread(target=tick,daemon=True)
    if enabled:t.start()
    try:yield
    finally:
        stop.set()
        if enabled:t.join()


def copy_query(con, query: str, destination: Path, partition: str | None=None,
               row_group: int=65536) -> int:
    opts=['FORMAT PARQUET','COMPRESSION ZSTD','COMPRESSION_LEVEL 1',f'ROW_GROUP_SIZE {row_group}']
    if partition:opts.extend([f'PARTITION_BY ({partition})',"FILENAME_PATTERN 'part_{i}'"])
    result=con.execute(f'COPY ({query}) TO {lit(destination)} ('+', '.join(opts)+')').fetchone()
    if not result: raise RuntimeError('COPY did not return a row count')
    return int(result[0])


def parquet_count(con, paths: list[Path]) -> int:
    return int(con.execute(f'SELECT count(*) FROM {parquet_sql(paths)}').fetchone()[0]) if paths else 0


def inventory(root: Path) -> list[dict]:
    result=[]
    for p in sorted(root.rglob('*.parquet')):
        result.append({'path':p.relative_to(root).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)})
    return result


def verify_done(root: Path) -> dict:
    done=read_json(root/'_DONE.json')
    if done['algorithm']!=ALGORITHM: raise RuntimeError(f'Checkpoint algorithm mismatch: {root.name}')
    for item in done['files']:
        p=root/item['path']
        if not p.is_file() or p.stat().st_size!=item['bytes'] or sha(p)!=item['sha256']:
            raise RuntimeError(f'Checkpoint file failed authentication: {root.name}')
    return done


def run_dir(root: Path, producer: Callable[[Path],dict]) -> dict:
    if (root/'_DONE.json').is_file():return verify_done(root)
    if root.exists():
        raise RuntimeError(f'Unrecognized/incomplete checkpoint directory: {root}; it was not overwritten')
    root.parent.mkdir(parents=True,exist_ok=True)
    staging=root.parent/('.partial_'+root.name+'_'+uuid.uuid4().hex)
    staging.mkdir()
    try:
        info=producer(staging)
        files=inventory(staging)
        done={'algorithm':ALGORITHM,'version':VERSION,'created_utc':utc(),'files':files,**info}
        write_json(staging/'_DONE.json',done)
        os.rename(staging,root)
        return done
    except BaseException:
        # Preserve failed new work. Never delete the source or a completed checkpoint.
        raise


def dataset_paths(root: Path, done: dict) -> list[Path]:
    return [root/x['path'] for x in done['files']]


def split_by_partition(root: Path, done: dict, name: str) -> dict[int,list[Path]]:
    answer={}
    for item in done['files']:
        p=Path(item['path']);parts=[s for s in p.parts if s.startswith(name+'=')]
        if len(parts)!=1:raise RuntimeError('Unexpected partition path layout')
        key=int(parts[0].split('=',1)[1])
        answer.setdefault(key,[]).append(root/p)
    return answer


@dataclasses.dataclass
class Config:
    source_run: Path
    output: Path
    review_dir: Path
    user_buckets: int=512
    game_buckets: int=128
    chunk_rows: int=64000000
    workers: int=2
    memory_gb: float=3.0
    expected_focal_rows: int=47587020
    expected_users: int=4846362
    expected_relevant_games: int=2409473913
    check_disk: bool=True
    quiet: bool=False
    inline_workers: bool=False


def check_space(cfg: Config, projected_bytes: int=0) -> None:
    if not cfg.check_disk:return
    # Reserve for compact final outputs, worker spill and metadata. Refine the
    # remaining chronology-shard requirement from completed chunks, not DB size.
    reserve=24*1024**3 + cfg.expected_focal_rows*180
    required=int(projected_bytes+reserve)
    free=shutil.disk_usage(cfg.output).free
    log(f'Disk check: {free/1024**3:.1f} GiB free; estimated remaining requirement {required/1024**3:.1f} GiB')
    if free<required:
        raise RuntimeError('Insufficient free space for estimated remaining checkpoints plus reserve. '
                           'Completed work is preserved. Free unrelated disk space and rerun the same command.')


def prepare(cfg: Config, con, source_db: Path) -> dict:
    con.execute(f'ATTACH {lit(source_db)} AS prior (READ_ONLY)')
    table_names={r[0] for r in con.execute("SELECT table_name FROM information_schema.tables WHERE table_catalog='prior' AND table_schema='main'").fetchall()}
    missing=set(REQUIRED)-table_names
    if missing:raise RuntimeError('Saved tables missing: '+', '.join(sorted(missing))+'. No expensive rebuild was attempted.')
    schemas={}
    for table,fields in REQUIRED.items():
        cols=con.execute(f'DESCRIBE prior.main.{table}').fetchall()
        schemas[table]=[{'name':r[0],'type':r[1]} for r in cols]
        if not fields.issubset({r[0] for r in cols}):raise RuntimeError('Unexpected saved schema: '+table)
    counts={}
    for table in REQUIRED:
        counts[table]=int(con.execute(f'SELECT count(*) FROM prior.main.{table}').fetchone()[0])
    for key,expected in [('focal',cfg.expected_focal_rows),('target_users',cfg.expected_users),('relevant_games',cfg.expected_relevant_games)]:
        if counts[key]!=expected:raise RuntimeError(f'Saved {key} count is {counts[key]:,}, expected {expected:,}; stopped without rebuilding.')
    if not counts['relevant_games']<=counts['user_events']<=2*counts['relevant_games']:
        raise RuntimeError('Saved user_events count is inconsistent with saved relevant_games')
    bad=con.execute("SELECT count(*) FROM prior.main.focal WHERE game_id IS NULL OR game_id='' OR p1 IS NULL OR p2 IS NULL OR p1<=0 OR p2<=0 OR p1=p2").fetchone()[0]
    if bad:raise RuntimeError(f'{bad:,} invalid saved focal records; no row was silently dropped.')
    lo,hi=con.execute('SELECT min(rowid),max(rowid) FROM prior.main.user_events').fetchone()
    if lo!=0 or hi!=counts['user_events']-1:
        raise RuntimeError('Saved user_events row IDs are not the dense CTAS layout expected by this recovery')
    info={'counts':counts,'schemas':schemas,'source_database_read_only':True,
          'rowid_min':lo,'rowid_max':hi,'source_signature':db_signature(source_db),
          'inherited_configured_history_months':['2023-10','2025-11'],
          'history_scope':'Observed rated-standard start chronology. Completeness against all casual/variant games is not established.',
          'original_global_adjacent_table_reused':False}
    write_json(cfg.output/'private/source_preflight.json',info)
    return info


def export_inputs(cfg: Config, con, counts: dict) -> tuple[dict,dict,list[Path]]:
    B,G=cfg.user_buckets,cfg.game_buckets
    private=cfg.output/'private'
    target_root=private/'targets_by_user'
    def targets_producer(d):
        query=f'''SELECT game_id,user_id,CAST(user_id % {B} AS INTEGER) AS ub FROM (
          SELECT game_id,p1 AS user_id FROM prior.main.focal
          UNION ALL SELECT game_id,p2 AS user_id FROM prior.main.focal) t'''
        n=copy_query(con,query,d,'ub',8192)
        if n!=2*counts['focal']:raise RuntimeError('Target-side row conservation failed')
        if parquet_count(con,list(d.rglob('*.parquet')))!=n:raise RuntimeError('Target export footer count failed')
        return {'rows':n}
    with heartbeat('Exporting focal target sides',not cfg.quiet):
        targets=run_dir(target_root,targets_producer)
    if not cfg.quiet:log(f'Focal target sides ready: {targets["rows"]:,}')
    focal_root=private/'focal_by_game'
    def focal_producer(d):
        n=copy_query(con,f'SELECT game_id,p1,p2,CAST(hash(game_id) % {G} AS INTEGER) AS gb FROM prior.main.focal',d,'gb',8192)
        if n!=counts['focal'] or parquet_count(con,list(d.rglob('*.parquet')))!=n:raise RuntimeError('Focal export row conservation failed')
        return {'rows':n}
    with heartbeat('Exporting focal game partitions',not cfg.quiet):focal=run_dir(focal_root,focal_producer)
    by_user={i:[] for i in range(B)}
    N=counts['user_events'];start=time.monotonic();new_rows=0;completed_rows=0;completed_bytes=0
    n_chunks=math.ceil(N/cfg.chunk_rows)
    for k in range(n_chunks):
        low=k*cfg.chunk_rows;high=min(N,low+cfg.chunk_rows)
        chunk=private/'chronology_chunks'/f'chunk_{k:05d}'
        reused=(chunk/'_DONE.json').exists()
        if not reused and cfg.check_disk:
            projected=int(1.20*(completed_bytes/completed_rows)*(N-completed_rows)) if completed_rows else cfg.chunk_rows*64
            check_space(cfg,projected)
        def producer(d):
            sql=f'''SELECT {EVENT_FIELDS},CAST(user_id % {B} AS INTEGER) AS ub
              FROM prior.main.user_events WHERE rowid>={low} AND rowid<{high}'''
            n=copy_query(con,sql,d,'ub',8192)
            if n!=high-low:raise RuntimeError('Saved rowid chunk count mismatch')
            if parquet_count(con,list(d.rglob('*.parquet')))!=n:raise RuntimeError('Chronology export footer count failed')
            return {'rows':n,'rowid_first':low,'rowid_stop_exclusive':high}
        with heartbeat(f'Chronology partition chunk {k+1}/{n_chunks}',not cfg.quiet):done=run_dir(chunk,producer)
        for ub,pp in split_by_partition(chunk,done,'ub').items():
            if ub not in by_user:raise RuntimeError('Out-of-range user bucket, possibly an invalid user ID')
            by_user[ub].extend(pp)
        completed_rows+=done['rows'];completed_bytes+=sum(x['bytes'] for x in done['files'])
        if not reused:new_rows+=done['rows']
        elapsed=time.monotonic()-start
        eta=(N-completed_rows)/(new_rows/elapsed) if new_rows and elapsed else None
        if not cfg.quiet:
            log(f'PARTITION {k+1}/{n_chunks}: {completed_rows:,}/{N:,} player-events; '
                +('verified checkpoint reused' if reused else f'{new_rows/elapsed:,.0f} new rows/s')
                +(f'; remaining partition ETA {eta/3600:.2f} h' if eta is not None else ''))
    if completed_rows!=N:raise RuntimeError('Chronology chunk row conservation failed')
    return by_user,split_by_partition(target_root,targets,'ub'),dataset_paths(focal_root,focal)


def is_oom(exc: BaseException) -> bool:
    return exc.__class__.__name__=='OutOfMemoryException' or 'Out of Memory Error' in str(exc)


def process_user_bucket(task: dict) -> dict:
    fd_limit()
    base=Path(task['output'])/'private'/'side_shards'/f'ub_{task["bucket"]:04d}'
    base.mkdir(parents=True,exist_ok=True)
    B=task['buckets'];bucket=task['bucket']
    def node(depth: int,sub: int) -> dict:
        root=base/f'node_d{depth:02d}_s{sub:05d}'
        split_file=base/f'split_d{depth:02d}_s{sub:05d}.json'
        if split_file.exists():
            a=node(depth+1,sub);b=node(depth+1,sub+(1<<depth))
            return {'paths':a['paths']+b['paths'],'rows':a['rows']+b['rows'],
                    'input_events':a['input_events']+b['input_events'],
                    'target_sides':a['target_sides']+b['target_sides'],
                    'oom_splits':1+a['oom_splits']+b['oom_splits']}
        con=None
        def producer(d):
            nonlocal con
            con=connect(d/'spill',task['memory_gb'],1)
            mod=B*(1<<depth);rem=bucket+B*sub
            ev=(f'SELECT {EVENT_FIELDS} FROM {parquet_sql(task["events"])} WHERE user_id % {mod}={rem}'
                if task['events'] else EMPTY_EVENTS)
            targets=(f'SELECT game_id,user_id FROM {parquet_sql(task["targets"])} WHERE user_id % {mod}={rem}'
                     if task['targets'] else EMPTY_TARGETS)
            con.execute('CREATE VIEW ev AS '+ev);con.execute('CREATE VIEW targets AS '+targets)
            ne=con.execute('SELECT count(*) FROM ev').fetchone()[0]
            nt=con.execute('SELECT count(*) FROM targets').fetchone()[0]
            invalid=con.execute("SELECT count(*) FROM ev WHERE game_id IS NULL OR game_id='' OR user_id IS NULL OR user_id<=0 OR utc_ms IS NULL OR utc_ms<=0").fetchone()[0]
            if invalid:raise RuntimeError(f'{invalid:,} invalid chronology events in a shard; no events were silently discarded')
            # Separate small-shard validation from the window operator.
            for table in ('ev','targets'):
                dup=con.execute(f'SELECT 1 FROM {table} GROUP BY game_id,user_id HAVING count(*)>1 LIMIT 1').fetchone()
                if dup:raise RuntimeError('Duplicate (game_id,user_id) in '+table+'; census not certified')
            n=copy_query(con,side_query(),d/'sides.parquet')
            if n>nt:raise RuntimeError('More focal sides than targets')
            if parquet_count(con,[d/'sides.parquet'])!=n:raise RuntimeError('Side export row count failed')
            con.close();con=None
            return {'rows':n,'input_events':ne,'target_sides':nt,'depth':depth,'sub':sub}
        try:
            done=run_dir(root,producer)
            return {'paths':[str(p) for p in dataset_paths(root,done)],'rows':done['rows'],
                    'input_events':done['input_events'],'target_sides':done['target_sides'],'oom_splits':0}
        except Exception as exc:
            if con is not None:
                try:con.close()
                except Exception:pass
                con=None
            if not is_oom(exc) or depth>=12:raise
            write_json(split_file,{'algorithm':ALGORITHM,'reason':'out_of_memory','depth':depth,'sub':sub,
                                   'rule':'split complete user histories by an additional modulo bit'})
            log(f'User bucket {bucket}, depth {depth}: splitting into two smaller user sets after OOM')
            return node(depth,sub)
    result=node(0,0)
    write_json(base/'bucket_result.json',result)
    return result


def run_workers(cfg: Config, by_user: dict, targets: dict, counts: dict) -> list[Path]:
    task_root=cfg.output/'private/worker_tasks';task_root.mkdir(parents=True,exist_ok=True)
    tasks=[]
    for b in range(cfg.user_buckets):
        task={'output':str(cfg.output),'bucket':b,'buckets':cfg.user_buckets,'memory_gb':cfg.memory_gb,
              'events':[str(p) for p in by_user[b]],'targets':[str(p) for p in targets.get(b,[])]}
        path=task_root/f'ub_{b:04d}.json';write_json(path,task);tasks.append((path,task))
    def launch(item):
        path,task=item
        if cfg.inline_workers:return process_user_bucket(task)
        logpath=path.with_suffix('.log')
        with logpath.open('a') as f:
            result=subprocess.run([sys.executable,'-u',str(Path(__file__).resolve()),'--worker-task',str(path)],stdout=f,stderr=subprocess.STDOUT)
        if result.returncode:
            raise RuntimeError(f'User bucket {task["bucket"]} stopped; detailed private worker log: {logpath}')
        return read_json(cfg.output/'private/side_shards'/f'ub_{task["bucket"]:04d}'/'bucket_result.json')
    results=[];started=time.monotonic()
    with ThreadPoolExecutor(max_workers=cfg.workers) as pool:
        futures=[pool.submit(launch,t) for t in tasks]
        try:
            for future in as_completed(futures):
                result=future.result();results.append(result)
                if not cfg.quiet:
                    k=len(results);seconds=time.monotonic()-started
                    log(f'ADJACENCY {k}/{cfg.user_buckets}: {sum(r["rows"] for r in results):,} focal sides saved; '
                        f'rough remaining shard ETA {seconds/k*(cfg.user_buckets-k)/3600:.2f} h')
        except BaseException:
            for f in futures:f.cancel()
            raise
    if sum(r['input_events'] for r in results)!=counts['user_events']:raise RuntimeError('Worker input-event conservation failed')
    if sum(r['target_sides'] for r in results)!=2*counts['focal']:raise RuntimeError('Worker target-side conservation failed')
    write_json(cfg.output/'private/worker_totals.json',{
        'input_events':sum(r['input_events'] for r in results),'focal_sides':sum(r['rows'] for r in results),
        'target_sides':sum(r['target_sides'] for r in results),'oom_splits':sum(r['oom_splits'] for r in results)})
    return sorted(Path(p) for r in results for p in r['paths'])


def summarize_part(con, path: Path) -> dict:
    con.execute('CREATE OR REPLACE VIEW c AS SELECT * FROM '+parquet_sql([path]))
    keys=['rows','unmapped_focal','mutual_previous_observed','mutual_next_observed',
          'mutual_previous_same_pair','mutual_next_same_pair','previous_unknown','next_unknown',
          'previous_start_order_ambiguous','next_start_order_ambiguous']
    row=con.execute('''SELECT count(*),
      count(*) FILTER(WHERE NOT focal_mapping_ok),
      count(*) FILTER(WHERE mutual_previous_observed),count(*) FILTER(WHERE mutual_next_observed),
      count(*) FILTER(WHERE mutual_previous_same_pair),count(*) FILTER(WHERE mutual_next_same_pair),
      count(*) FILTER(WHERE mutual_previous_same_pair IS NULL),count(*) FILTER(WHERE mutual_next_same_pair IS NULL),
      count(*) FILTER(WHERE previous_start_order_ambiguous),count(*) FILTER(WHERE next_start_order_ambiguous) FROM c''').fetchone()
    result=dict(zip(keys,map(int,row)))
    result['previous_status_counts']={r[0]:r[1] for r in con.execute('SELECT previous_classification_status,count(*) FROM c GROUP BY 1').fetchall()}
    result['next_status_counts']={r[0]:r[1] for r in con.execute('SELECT next_classification_status,count(*) FROM c GROUP BY 1').fetchall()}
    return result


def finish(cfg: Config, con, focal_paths: list[Path], side_paths: list[Path], counts: dict) -> dict:
    sides_root=cfg.output/'private/sides_by_game'
    def producer(d):
        n=copy_query(con,f'SELECT *,CAST(hash(game_id) % {cfg.game_buckets} AS INTEGER) AS gb FROM {parquet_sql(side_paths)}',d,'gb',8192)
        if n!=parquet_count(con,side_paths):raise RuntimeError('Final side repartition row conservation failed')
        return {'rows':n}
    with heartbeat('Repartitioning compact focal sides by game',not cfg.quiet):sides_done=run_dir(sides_root,producer)
    side_map=split_by_partition(sides_root,sides_done,'gb')
    focal_root=cfg.output/'private/focal_by_game';focal_done=read_json(focal_root/'_DONE.json')
    focal_map=split_by_partition(focal_root,focal_done,'gb')
    totals={};part_summaries=[]
    for gb in sorted(focal_map):
        part=cfg.output/'private/final'/f'gb_{gb:04d}'
        def part_producer(d):
            con.execute('CREATE OR REPLACE VIEW f AS SELECT game_id,p1,p2 FROM '+parquet_sql(focal_map[gb]))
            if gb in side_map:
                con.execute('CREATE OR REPLACE VIEW sides AS SELECT * FROM '+parquet_sql(side_map[gb]))
            else:
                con.execute('CREATE OR REPLACE VIEW empty_ev AS '+EMPTY_EVENTS)
                con.execute('CREATE OR REPLACE VIEW empty_targets AS '+EMPTY_TARGETS)
                con.execute('CREATE OR REPLACE VIEW sides AS '+side_query('empty_ev','empty_targets'))
            for sql in ['SELECT 1 FROM f GROUP BY game_id HAVING count(*)>1 LIMIT 1',
                        'SELECT 1 FROM sides GROUP BY game_id,user_id HAVING count(*)>1 LIMIT 1']:
                if con.execute(sql).fetchone():raise RuntimeError('Duplicate focal game or side during final assembly')
            n=con.execute('SELECT count(*) FROM f').fetchone()[0]
            outpath=d/'census.parquet';n2=copy_query(con,census_query(),outpath)
            if n2!=n:raise RuntimeError('Final LEFT-join row conservation failed')
            stats=summarize_part(con,outpath)
            if stats['rows']!=n:raise RuntimeError('Final Parquet row count mismatch')
            # Keep ambiguous observed candidates as well, not just the clean subset.
            copy_query(con,'SELECT * FROM c WHERE mutual_previous_observed',d/'predecessor_candidates.parquet')
            copy_query(con,'SELECT * FROM c WHERE mutual_next_observed',d/'successor_candidates.parquet')
            copy_query(con,'SELECT * FROM c WHERE NOT focal_mapping_ok',d/'unmapped_focal.parquet')
            return {'rows':n,'summary':stats}
        done=run_dir(part,part_producer);part_summaries.append(done['summary'])
        if not cfg.quiet and (len(part_summaries)%8==0 or len(part_summaries)==len(focal_map)):
            log(f'FINAL ASSEMBLY {len(part_summaries)}/{len(focal_map)} game partitions')
    for stat in part_summaries:
        for key,value in stat.items():
            if isinstance(value,dict):
                dest=totals.setdefault(key,{})
                for k,v in value.items():dest[k]=dest.get(k,0)+v
            else:totals[key]=totals.get(key,0)+value
    if totals.get('rows')!=counts['focal']:raise RuntimeError('Final census does not conserve the entire focal panel')
    return totals


def public_review(cfg: Config) -> tuple[Path,Path]:
    cfg.review_dir.mkdir(parents=True,exist_ok=True)
    allowed=['summary.json','RUN_STATUS.json','RESOURCE_SETTINGS.json','TEST_RESULTS.json']
    current=read_json(cfg.output/'RUN_STATUS.json').get('status') if (cfg.output/'RUN_STATUS.json').is_file() else None
    if current=='IMMEDIATE_REMATCH_ADJACENCY_RECOVERY_OK':allowed.append('_SUCCESS.json')
    if current=='ADJACENCY_ASSEMBLED_BUT_FOCAL_COVERAGE_BLOCKED':allowed.append('_BLOCKED.json')
    entries=[cfg.output/n for n in allowed if (cfg.output/n).is_file()]
    name=f'IMMEDIATE_REMATCH_RECOVERY_REPORT_v101_{cfg.source_run.name}_{utc()}_{uuid.uuid4().hex[:6]}.zip'
    dest=cfg.review_dir/name
    manifest=''.join(f'{sha(p)}  {p.name}\n' for p in sorted(entries))
    with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED) as z:
        for p in entries:z.write(p,p.name)
        z.writestr('REPORT_MANIFEST.sha256',manifest)
        z.writestr('README.txt','Aggregate-only recovery report. No game IDs, user IDs, source DB, raw data, or worker logs are included.\n')
    side=Path(str(dest)+'.sha256');side.write_text(f'{sha(dest)}  {dest.name}\n')
    return dest,side


def run_recovery(cfg: Config) -> dict:
    import duckdb
    cfg.source_run=cfg.source_run.resolve();cfg.output=cfg.output.resolve()
    source_db=cfg.source_run/'rematch_census.duckdb'
    if not source_db.is_file():raise RuntimeError(f'Saved database not found: {source_db}; original scan was not rerun.')
    if cfg.output==cfg.source_run or cfg.source_run in cfg.output.parents:
        raise RuntimeError('Recovery output must be separate from the original run')
    cfg.output.mkdir(parents=True,exist_ok=True)
    (cfg.output/'private').mkdir(exist_ok=True)
    (cfg.output/'PRIVATE_ROW_LEVEL_DATA.txt').write_text('PRIVATE: all files under private/ contain or link to game/user identifiers. Do not upload or commit that directory.\n')
    lock=open(cfg.output/'.run.lock','a+')
    try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:
        lock.close();raise RecoveryBusy('A recovery is already running for this output; do not launch a second copy.')
    started=time.monotonic();initial=db_signature(source_db)
    try:
        fd_limit()
        code_root=Path(__file__).parent
        contract={'algorithm':ALGORITHM,'duckdb_version':duckdb.__version__,'source':initial,
                  'user_buckets':cfg.user_buckets,'game_buckets':cfg.game_buckets,'chunk_rows':cfg.chunk_rows,
                  'expected_focal_rows':cfg.expected_focal_rows,'expected_users':cfg.expected_users,
                  'expected_relevant_games':cfg.expected_relevant_games,
                  'code_sha256':{p.name:sha(p) for p in [code_root/'recover_rematches.py',code_root/'rematch_logic.py']}}
        cp=cfg.output/'private/RUN_CONTRACT.json'
        if cp.exists():
            if read_json(cp)!=contract:raise RuntimeError('Input, executable, DuckDB version or partition settings changed since this recovery began. No checkpoints overwritten.')
        else:write_json(cp,contract)
        ram=physical_ram()
        if ram:
            permitted=max(1,int((ram*.55-1e9)//(cfg.memory_gb*1e9)))
            cfg.workers=min(cfg.workers,permitted)
        write_json(cfg.output/'RESOURCE_SETTINGS.json',{'version':VERSION,'duckdb':duckdb.__version__,
            'python':sys.version,'platform':platform.platform(),'detected_physical_ram_bytes':ram,
            'adjacency_workers':cfg.workers,'duckdb_memory_limit_gb_per_worker':cfg.memory_gb,
            'worker_threads':1,'partition_threads':1,'preserve_insertion_order':False,
            'note':'DuckDB buffer limits are not whole-process RSS caps. Source database is attached READ_ONLY; workers open only Parquets.'})
        if (cfg.output/'_SUCCESS.json').exists():
            if not cfg.quiet:log('Previously completed recovery found; authenticating final result files.')
            finals=sorted((cfg.output/'private/final').glob('gb_*'))
            if not finals:raise RuntimeError('Completed receipt exists but final partitions are missing')
            for p in finals:verify_done(p)
            success=read_json(cfg.output/'_SUCCESS.json')
            if sha(cfg.output/'summary.json')!=success['summary_sha256']:raise RuntimeError('Stored summary hash mismatch')
            expected_partitions=set(split_by_partition(cfg.output/'private/focal_by_game',read_json(cfg.output/'private/focal_by_game/_DONE.json'),'gb'))
            if {int(p.name.split('_')[1]) for p in finals}!=expected_partitions:raise RuntimeError('One or more completed final partitions are missing')
            write_json(cfg.output/'RUN_STATUS.json',{'status':'IMMEDIATE_REMATCH_ADJACENCY_RECOVERY_OK','stage':'verified_completed_recovery','version':VERSION,'utc':utc()})
            return read_json(cfg.output/'summary.json')
        write_json(cfg.output/'RUN_STATUS.json',{'status':'RUNNING','stage':'source_preflight','utc':utc(),'version':VERSION})
        con=connect(cfg.output/'private/controller_spill',cfg.memory_gb,1)
        try:
            with heartbeat('Checking persisted source tables',not cfg.quiet):info=prepare(cfg,con,source_db)
            counts=info['counts']
            if not cfg.quiet:
                log('Saved source verified: '+', '.join(f'{k}={v:,}' for k,v in counts.items()))
                log(f'Adjacency uses {cfg.workers} workers x {cfg.memory_gb:g} GB DuckDB limit; source scan/export uses one thread.')
            write_json(cfg.output/'RUN_STATUS.json',{'status':'RUNNING','stage':'partition_saved_tables','utc':utc(),'version':VERSION})
            by_user,targets,focal_paths=export_inputs(cfg,con,counts)
        finally:con.close()
        # Release the controller's buffer pool before launching independent workers.
        write_json(cfg.output/'RUN_STATUS.json',{'status':'RUNNING','stage':'user_adjacency_shards','utc':utc(),'version':VERSION})
        with heartbeat('User-shard adjacency',not cfg.quiet):side_paths=run_workers(cfg,by_user,targets,counts)
        write_json(cfg.output/'RUN_STATUS.json',{'status':'RUNNING','stage':'final_assembly','utc':utc(),'version':VERSION})
        con=connect(cfg.output/'private/final_spill',cfg.memory_gb,1)
        try:
            with heartbeat('Final assembly and audit',not cfg.quiet):totals=finish(cfg,con,focal_paths,side_paths,counts)
        finally:con.close()
        if db_signature(source_db)!=initial:raise RuntimeError('Source database changed during recovery; outputs not certified')
        summary={'version':VERSION,'algorithm':ALGORITHM,'source_run_id':cfg.source_run.name,
                 'saved_table_counts':counts,'census':totals,'elapsed_seconds_this_invocation':time.monotonic()-started,
                 'workers':cfg.workers,'user_buckets':cfg.user_buckets,'game_buckets':cfg.game_buckets,
                 'source_database_unchanged':True,'source_signature_is_full_content_hash':False,
                 'source_database_opened_read_only':True,'original_chronology_parquets_rescanned':False,
                 'network_requests':0,'timing_classification_complete':False,
                 'focal_sample_window_utc':['2023-11-01','2025-10-31'],
                 'inherited_configured_history_months':['2023-10','2025-11'],
                 'scope':'Mutual adjacency in the observed rated-standard game-start chronology, across the saved speed categories.',
                 'limitations':['Not an exhaustive census of verified immediate rematches.',
                   'No literal game-end time or end-to-start gap is inferred.',
                   'Missing neighbors and ambiguous start ordering are NULL, not negative classifications.',
                   'Casual/variant/aborted or otherwise unrecorded games can be absent from the source.',
                   'One boundary month does not establish full-history negative classifications.'],
                 'final_dataset':'private/final/gb_*/census.parquet',
                 'predecessor_candidates':'private/final/gb_*/predecessor_candidates.parquet',
                 'successor_candidates':'private/final/gb_*/successor_candidates.parquet'}
        write_json(cfg.output/'summary.json',summary)
        if totals['unmapped_focal']:
            status='ADJACENCY_ASSEMBLED_BUT_FOCAL_COVERAGE_BLOCKED'
            write_json(cfg.output/'_BLOCKED.json',{'status':status,'unmapped_focal':totals['unmapped_focal'],
                       'reason':'Focal rows retained, but both chronology sides did not map consistently for every focal game.'})
        else:
            status='IMMEDIATE_REMATCH_ADJACENCY_RECOVERY_OK'
            write_json(cfg.output/'_SUCCESS.json',{'status':status,'version':VERSION,'summary_sha256':sha(cfg.output/'summary.json'),
                'all_focal_rows_retained':True,'all_focal_sides_mapped':True,'end_to_start_rematches_certified':False,
                'unknown_direction_flags_retained':True,'source_unchanged':True,'utc':utc()})
        write_json(cfg.output/'RUN_STATUS.json',{'status':status,'stage':'finished','version':VERSION,'utc':utc()})
        return summary
    finally:
        fcntl.flock(lock,fcntl.LOCK_UN);lock.close()


def integration_selftest() -> dict:
    """Real DuckDB smoke test: persisted DB -> chunks -> workers -> final outputs.

    Run on the user's existing DuckDB interpreter before opening their real DB.
    Includes source-preservation, source-row/chunk conservation, independent
    Python reference comparisons, recursion/split path and checkpoint resume.
    """
    import duckdb
    from test_logic import reference
    rng=random.Random(20260908);games=[];t=1700000000000
    for i in range(240):
        a,b=rng.sample(range(1,30),2);t+=rng.choice([0,1000,10000,300000])
        games.append((f'g{i:07d}',t,i,a,b))
    # Guaranteed unambiguous chain, with colours swapped.
    games.extend([('chain001',t+1000,241,101,102),('chain002',t+2000,242,102,101),('chain003',t+3000,243,101,102)])
    focal=[(g,a,b) for i,(g,tt,ii,a,b) in enumerate(games) if i%2==0 or g.startswith('chain')]
    users=sorted({u for _,a,b in focal for u in (a,b)});user_set=set(users)
    relevant=[r for r in games if r[3] in user_set or r[4] in user_set]
    ev=[(g,tt,i,u,v) for g,tt,i,a,b in relevant for u,v in [(a,b),(b,a)] if u in user_set]
    with tempfile.TemporaryDirectory(prefix='rematch_v101_selftest_') as tmp:
        tmp=Path(tmp);source=tmp/'source';source.mkdir();db=source/'rematch_census.duckdb'
        c=duckdb.connect(str(db))
        c.execute('CREATE TABLE focal(game_id VARCHAR,p1 BIGINT,p2 BIGINT)');c.executemany('INSERT INTO focal VALUES (?,?,?)',focal)
        c.execute('CREATE TABLE target_users(user_id BIGINT)');c.executemany('INSERT INTO target_users VALUES (?)',[(u,) for u in users])
        c.execute('CREATE TABLE relevant_games(game_id VARCHAR,utc_ms BIGINT,archive_ordinal BIGINT,white_id BIGINT,black_id BIGINT)')
        c.executemany('INSERT INTO relevant_games VALUES (?,?,?,?,?)',relevant)
        c.execute('CREATE TABLE user_events(game_id VARCHAR,utc_ms BIGINT,archive_ordinal BIGINT,user_id BIGINT,opponent_id BIGINT)')
        c.executemany('INSERT INTO user_events VALUES (?,?,?,?,?)',ev);c.close()
        original_hash=sha(db)
        cfg=Config(source,tmp/'recovery',tmp/'reports',user_buckets=8,game_buckets=4,chunk_rows=71,workers=2,
                   memory_gb=.25,expected_focal_rows=len(focal),expected_users=len(users),expected_relevant_games=len(relevant),
                   check_disk=False,quiet=True,inline_workers=False)
        # Force the adaptive split/resume branch for one bucket without inducing OOM.
        split_root=cfg.output/'private/side_shards/ub_0001';split_root.mkdir(parents=True)
        write_json(split_root/'split_d00_s00000.json',{'algorithm':ALGORITHM,'reason':'selftest_forced_split'})
        result=run_recovery(cfg)
        if result['census']['rows']!=len(focal) or result['census']['unmapped_focal']!=0:raise AssertionError('Integration row conservation failed')
        cc=duckdb.connect();pp=sorted((cfg.output/'private/final').glob('gb_*/census.parquet'))
        cursor=cc.execute('SELECT * FROM '+parquet_sql(pp));cols=[d[0] for d in cursor.description]
        got={r[0]:dict(zip(cols,r)) for r in cursor.fetchall()};cc.close()
        for g,row in reference(games,focal).items():
            for k,v in row.items():
                if got[g][k]!=v:raise AssertionError(f'DuckDB/reference disagreement for {k}')
        before={str(p):sha(p) for p in pp}
        # Verify the interrupted-run path: reuse chunks, shard outputs and final parts.
        (cfg.output/'_SUCCESS.json').unlink()
        run_recovery(cfg)
        if before!={str(p):sha(p) for p in pp}:raise AssertionError('Resume rewrote final Parquets')
        if sha(db)!=original_hash:raise AssertionError('Source database was changed')
        report,side=public_review(cfg)
        with zipfile.ZipFile(report) as z:
            if any(n.endswith('.parquet') or n.startswith('private/') for n in z.namelist()):raise AssertionError('Private output leaked into report')
        return {'status':'DUCKDB_INTEGRATION_SELFTEST_OK','duckdb':duckdb.__version__,
                'focal_games':len(focal),'source_unchanged':True,'independent_reference_agreement':True,
                'checkpoint_resume':True,'subprocess_workers':True,'forced_adaptive_split_path':True,'utc':utc()}


def parser():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source-run',type=Path,default=DEFAULT_SOURCE)
    p.add_argument('--output',type=Path)
    p.add_argument('--review-dir',type=Path,default=Path.home()/'Desktop/Lichess_Desktop')
    p.add_argument('--workers',type=int,default=2)
    p.add_argument('--memory-gb',type=float,default=3.0)
    p.add_argument('--user-buckets',type=int,default=512)
    p.add_argument('--game-buckets',type=int,default=128)
    p.add_argument('--chunk-rows',type=int,default=64000000)
    p.add_argument('--worker-task',type=Path)
    p.add_argument('--self-test-only',action='store_true')
    p.add_argument('--execute',action='store_true')
    return p


def main():
    a=parser().parse_args()
    if a.worker_task:
        try:process_user_bucket(read_json(a.worker_task))
        except BaseException:traceback.print_exc();raise
        return
    if not a.execute and not a.self_test_only:
        print('Dry run. Use --execute to run the mandatory integration self-test and recovery.');return
    import duckdb
    log('Running a small end-to-end DuckDB self-test before touching the original database.')
    test=integration_selftest();log(test['status'])
    if a.self_test_only:return
    if not 1<=a.workers<=10 or not 0.5<=a.memory_gb<=16:raise SystemExit('Invalid worker or memory setting')
    if a.user_buckets<8 or a.user_buckets>1024 or a.game_buckets<4 or a.game_buckets>512:raise SystemExit('Invalid bucket count')
    if a.chunk_rows<100000:raise SystemExit('Production chunk is too small')
    output=a.output or (a.source_run.parent.parent/'immediate_rematch_census_v101_recovery'/a.source_run.name)
    cfg=Config(a.source_run,output,a.review_dir,user_buckets=a.user_buckets,game_buckets=a.game_buckets,
               chunk_rows=a.chunk_rows,workers=a.workers,memory_gb=a.memory_gb)
    log('Original database: '+str(cfg.source_run/'rematch_census.duckdb'))
    log('Separate, resumable recovery output: '+str(cfg.output))
    log('Planning runtime: 2-6 hours; not a Mac benchmark. Stage-specific ETAs update from completed work.')
    try:
        result=run_recovery(cfg)
        write_json(cfg.output/'TEST_RESULTS.json',test)
    except RecoveryBusy:
        # Never change the state or report of the already-running owner.
        raise
    except BaseException as exc:
        # Keep verbose failure details local. The aggregate review names only the
        # exception class and prior stage, never SQL payloads or identifier data.
        if cfg.output.exists():
            status=read_json(cfg.output/'RUN_STATUS.json') if (cfg.output/'RUN_STATUS.json').exists() else {}
            write_json(cfg.output/'RUN_STATUS.json',{'status':'STOPPED','version':VERSION,'stage':status.get('stage','preflight'),
                       'error_class':exc.__class__.__name__,'utc':utc(),'completed_checkpoints_preserved':True})
            write_json(cfg.output/'TEST_RESULTS.json',test)
            (cfg.output/'private').mkdir(exist_ok=True)
            (cfg.output/'private'/f'failure_{utc()}_{uuid.uuid4().hex[:6]}.txt').write_text(traceback.format_exc())
            report,side=public_review(cfg);log('REVIEW ZIP: '+str(report));log('SIDECAR: '+str(side))
        raise
    report,side=public_review(cfg)
    log('REVIEW ZIP: '+str(report));log('SIDECAR: '+str(side))
    log(json.dumps(result['census'],sort_keys=True))
    if result['census']['unmapped_focal']:
        log('ADJACENCY_ASSEMBLED_BUT_FOCAL_COVERAGE_BLOCKED');raise SystemExit(3)
    log('IMMEDIATE_REMATCH_ADJACENCY_RECOVERY_OK')
    log('Adjacency candidates only. Actual game-end timing remains unresolved. Do not run the old API timing script.')

if __name__=='__main__':main()
