# Immediate Rematch Recovery v1.0.1

## Purpose and current status

Recover the failed **v1.0.0 adjacency stage** at:

```
/Volumes/XT_Pro/lichess_kindness/output/immediate_rematch_census_v100/20260908T031408Z_6459
```

The reported failure was an OutOfMemoryException while creating a global `adjacent` table from `user_events`. The old program had already issued separate, persistent CREATE TABLE statements for `focal`, `target_users`, `relevant_games`, and `user_events`.

This recovery checks that those tables survived, opens the original database **read-only**, and reuses them. It does not rebuild those tables, reread the original chronology Parquets, change the source database, download data, fetch API metadata, or overwrite a completed checkpoint.

**These outputs are observed-chronology adjacency candidates, not verified immediate rematches.** They do not establish the literal time the preceding game ended. `lastMoveAt` is not substituted for a true game-end timestamp. The old `fetch_and_classify.py` is not included and should not be run as the next step without reviewing the timing source.

## Launch from Lichess_Desktop

Put the ZIP and its `.sha256` sidecar in:

```
~/Desktop/Lichess_Desktop
```

From a fresh Terminal:

```bash
/bin/bash <<'BASH'
set -euo pipefail
cd "$HOME/Desktop/Lichess_Desktop"
/usr/bin/shasum -a 256 -c Immediate_Rematch_Recovery_v1_0_1.zip.sha256
stage="$(/usr/bin/mktemp -d "$PWD/rematch_recovery_v101.XXXXXX")"
/usr/bin/unzip -q Immediate_Rematch_Recovery_v1_0_1.zip -d "$stage"
cd "$stage/Immediate_Rematch_Recovery_v1_0_1"
/usr/bin/shasum -a 256 -c PACKAGE_MANIFEST.sha256
/bin/chmod 700 RUN_RECOVERY.command
/bin/bash ./RUN_RECOVERY.command
BASH
```

The same command is safe to rerun. The extraction location is new each time, but the recovery destination is stable. Completed stages are authenticated and reused. No `rm -rf` is needed. Leave the original v1.0.0 directory and database intact.

The launcher uses the current `python3`, which should be the same interpreter as the failed run. It never installs or upgrades dependencies. `LICHESS_PYTHON` can specify an existing interpreter. Required package: DuckDB. The Python standard library supplies all other dependencies; no Pandas or PyArrow is required.

## Recovery design

1. Verify the saved schema and the three known counts: 47,587,020 focal games; 4,846,362 target users; 2,409,473,913 relevant chronology games. Count the saved player events and validate the dense row-ID layout.
2. Export the focal targets and focal game partitions to private Parquet datasets.
3. Read saved `user_events` in disjoint 64-million-row row-ID chunks. Partition by `user_id % 512`. This avoids rereading the source once per user bucket. Each input chunk is an independently resumable checkpoint.
4. Run previous/next calculations separately on each complete user bucket, retaining all dates and speed categories in that user's saved chronology. Only after the window functions have run are non-focal rows discarded. Write only compact focal-side results, never a global billions-of-rows adjacency table.
5. Repartition the compact focal-side output by game and join both sides to the original focal targets. Every focal game is retained, including a focal game missing both chronology sides.
6. Audit row conservation, duplicate keys, missing mappings, timestamp-order ambiguity and source preservation. Write aggregate summaries and a review ZIP.

Default adjacency parallelism is **two independent processes**, each with one DuckDB thread and a **3 GB DuckDB memory limit**. The controller closes its DuckDB connection before launching these processes. It reduces worker count on smaller-memory machines. The limit concerns DuckDB's managed memory, not total process RSS.

If an adjacency bucket still runs out of memory, its complete user histories are divided using an additional modulo bit, and the two smaller tasks are checkpointed independently. No player's history is split across the two children. The completed output of other buckets is retained.

Export uses one thread, small Parquet row groups, disabled insertion-order preservation, and bounded-memory DuckDB connections. Increasing the original global window's memory limit is not the recovery strategy.

## Time, disk and progress

**Planning estimate: 2–6 hours**, possibly longer with cold/busy external storage, heavy data skew or repeated validation after interruption. This is not a benchmark of the user's Mac or the full dataset. The program prints measured partition throughput and phase-specific remaining-time estimates.

The recovery needs extra disk space for the sharded chronology, compact focal-side files and final outputs. It checks free disk space before exporting and refines the remaining-space estimate from completed chunks, adding a reserve for outputs and spill. When space is insufficient, it stops without deleting anything. Reuse the same command after freeing unrelated disk space.

Completed chunk and shard Parquets carry SHA-256 receipts. Restarting authenticates those files, so verification itself can take time. Incomplete new work is preserved in `.partial_...` directories but is never used as a completed checkpoint. The old source and completed private checkpoints are not deleted automatically.

## Output locations

Private recovery root:

```
/Volumes/XT_Pro/lichess_kindness/output/immediate_rematch_census_v101_recovery/20260908T031408Z_6459
```

Large files remain under `private/`. Important final datasets:

```
private/final/gb_*/census.parquet
private/final/gb_*/predecessor_candidates.parquet
private/final/gb_*/successor_candidates.parquet
private/final/gb_*/unmapped_focal.parquet
```

Read a complete dataset using all matching partition files, not just one `gb_...` folder. For example:

```python
con.execute("SELECT * FROM read_parquet('/Volumes/XT_Pro/lichess_kindness/output/immediate_rematch_census_v101_recovery/20260908T031408Z_6459/private/final/gb_*/census.parquet', hive_partitioning=false)")
```

The launcher writes its log to Lichess_Desktop. A successful run prints:

```
IMMEDIATE_REMATCH_ADJACENCY_RECOVERY_OK
```

If some focal games lack two consistent chronology sides, the assembled dataset retains them, but the run writes `_BLOCKED.json`, not `_SUCCESS.json`, and prints `ADJACENCY_ASSEMBLED_BUT_FOCAL_COVERAGE_BLOCKED`.

An aggregate-only ZIP and its `.sha256` sidecar are written directly to **Lichess_Desktop**. Their exact paths are printed as `REVIEW ZIP` and `SIDECAR`. Upload those two files. Do not upload the original database, worker logs, or `private/` datasets.

## Classification and corrections to v1.0.0

`mutual_previous_observed` / `mutual_next_observed` retain all deterministic same-pair adjacency candidates, including timestamp-order ambiguities. Both players must have a non-null neighbor, must name the same neighboring game, and must have reciprocal opponents and matching neighboring start times.

`mutual_previous_same_pair` / `mutual_next_same_pair` are nullable booleans. They are NULL for an unmapped/inconsistent focal game, a missing neighbor at the observed-history boundary, or ambiguous ordering around tied start times. Otherwise they indicate mutual adjacency in the saved chronology. A TRUE value is **not yet a verified immediate-rematch flag**.

Separate classification-status fields distinguish timing-unresolved candidates, observed non-adjacency, boundary uncertainty and ordering ambiguity. Start-to-start differences are labeled as such; they are not end-to-start gaps. Color reversal is allowed. No pool-only, outcome, board evaluation or game-length filter is applied to intervening saved events.

Two other v1.0.0 issues are corrected in this recovery: its aggregate rule could accept a single non-null neighbor without requiring one for both players, and its mapping audit did not retain focal games absent from both chronology sides. The recovery uses explicit two-sided joins and preserves the whole focal set.

A month of boundary history does not establish lifetime coverage. Casual, variant, aborted or otherwise unrecorded games may be absent from the saved rated-standard chronology. The original v1.0.0 filtering has already happened; this recovery does not claim to recover records the old extraction omitted. This remains an observed-start-chronology stage, not certification of all behavioral rematches.

No rematch-chain IDs or primary time cutoff are certified at this stage. Those depend on resolving the timing and coverage questions.

## Validation and its limits

Before delivery, nine standard-library SQL-logic tests passed, including 40 randomized reference comparisons, mutual adjacency in both directions, color reversal, ordinary intervening games, equal start-time ambiguity, missing neighbors, missing focal mappings and whole-user partition equivalence. The SQLite-backed tests execute the same portable classification SQL used by production. `LOGIC_TEST_RESULTS.txt` records that run. Python syntax compilation and Bash syntax checks also passed.

**The real DuckDB integration self-test was not executed in the delivery environment because DuckDB was unavailable there and dependency retrieval failed.** No claim of a completed DuckDB or full-scale Mac test is made.

The launcher therefore runs a mandatory small end-to-end DuckDB test using the user's installed DuckDB **before opening the real source database**. It builds a temporary persisted source, exports several chunks, launches subprocess workers, exercises a forced subdivision, compares the output with an independent Python reference, tests interrupted-run checkpoint reuse, checks source SHA-256 preservation, and checks that the report excludes private datasets. Temporary test files are removed; production source/checkpoint files are not.

If that small test fails, the large recovery is not attempted. Keep the displayed error and launcher log for diagnosis.

## Source and execution provenance

The original database is identified using its path, file identity, size, modification time, first 64 KiB digest and corresponding WAL metadata, plus saved schemas and counts. This is intentionally **not described as a full-content hash** of the large database. A final signature check confirms that the original file identity and recorded metadata have not changed.

The exact recovery source files, DuckDB version and partition configuration are bound into `private/RUN_CONTRACT.json`. Changing those silently on an existing recovery is rejected. Worker count or memory allowance can change without altering the logical partition contract, but the launcher defaults above should be used first.

Technical background: DuckDB documents windows as memory-intensive blocking operators and notes that out-of-memory errors remain possible with out-of-core execution. References used in developing this recovery:

- https://duckdb.org/docs/current/guides/performance/how_to_tune_workloads
- https://duckdb.org/docs/current/guides/troubleshooting/oom_errors
- https://duckdb.org/docs/stable/data/partitioning/partitioned_writes

These references explain the engine behavior; they are not evidence that this local recovery has completed.
