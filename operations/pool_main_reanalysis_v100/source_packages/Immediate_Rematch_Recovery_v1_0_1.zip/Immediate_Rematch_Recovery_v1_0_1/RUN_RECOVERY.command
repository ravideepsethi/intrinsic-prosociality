#!/bin/bash
set -euo pipefail
umask 077
PKG="$(cd "$(dirname "$0")" && pwd)"
DESKTOP="${HOME}/Desktop/Lichess_Desktop"
SOURCE="/Volumes/XT_Pro/lichess_kindness/output/immediate_rematch_census_v100/20260908T031408Z_6459"
PYTHON="${LICHESS_PYTHON:-python3}"
mkdir -p "$DESKTOP"
RUN_ID="$(/bin/date -u +%Y%m%dT%H%M%SZ)_$$"
LOG="$DESKTOP/immediate_rematch_recovery_v101_${RUN_ID}.log"
cd "$PKG"
/usr/bin/shasum -a 256 -c PACKAGE_MANIFEST.sha256
"$PYTHON" -c 'import duckdb; print("Python DuckDB:", duckdb.__version__)'
if [[ ! -f "$SOURCE/rematch_census.duckdb" ]]; then
  printf '\nSaved database not found:\n%s\nNothing was rebuilt or deleted.\n' "$SOURCE/rematch_census.duckdb" >&2
  exit 2
fi
export PYTHONUNBUFFERED=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export NUMEXPR_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1
printf '\nIMMEDIATE REMATCH RECOVERY v1.0.1\n'
printf 'Saved source: %s\nLog: %s\n' "$SOURCE" "$LOG"
printf 'No API calls. Source database is read-only. Completed checkpoints are reused.\n'
printf 'Planning estimate: 2-6 hours, possibly longer on cold/busy external storage.\n'
printf 'Standard-library logic tests, then a mandatory small DuckDB end-to-end test.\n\n'
"$PYTHON" "$PKG/test_logic.py"
/usr/bin/caffeinate -dimsu "$PYTHON" -u "$PKG/recover_rematches.py" \
  --source-run "$SOURCE" --review-dir "$DESKTOP" \
  --workers 2 --memory-gb 3 --execute 2>&1 | /usr/bin/tee "$LOG"
printf '\nRecovery finished. Upload the printed REVIEW ZIP and its .sha256 sidecar.\n'
printf 'Do not upload the source database or the private/ directory.\n'
