#!/usr/bin/env python3
"""Independent dense fixed-effect OLS check for the streaming plot estimator.

Uses synthetic data only. Checks point estimates and clustered covariance
against an explicit dummy-variable regression, including two pools per chooser.
Does not generate a figure or use the production panel.
"""
from __future__ import annotations
import json
from pathlib import Path
import tempfile
import numpy as np
import pandas as pd
import controlled_reference_price_figure as fix
import reference_price_model_v110 as engine


def main():
    rng = np.random.default_rng(72919)
    chooser_n, pools, per_cell = 40, 2, 32
    n = chooser_n * pools * per_cell
    chooser_code = np.repeat(np.arange(chooser_n), pools * per_cell)
    pool = np.tile(np.repeat(np.arange(pools), per_cell), chooser_n)
    cell = chooser_code * pools + pool
    r = rng.uniform(-0.999, 0.999, n)
    r[rng.random(n) < 0.12] = 0
    z = np.column_stack((0.9 * r + rng.normal(size=n), rng.normal(size=n)))
    g = fix.payoff_design(r)
    probability = np.clip(0.20 + 0.08 * r + 0.025 * z[:, 0] + 0.03 * z[:, 1]
                          + rng.normal(0, 0.015, chooser_n)[chooser_code], 0.02, 0.9)
    y = rng.binomial(1, probability) * 100.0
    frame = pd.DataFrame({"chooser": [f"chooser_{i:04d}" for i in chooser_code],
                          "pool_code": pool, "r": r, "y": y, "z1": z[:, 0], "z2": z[:, 1]})
    names = fix.PRICE_TERMS + ["z1", "z2"]

    def design(f):
        return np.column_stack((fix.payoff_design(f["r"].to_numpy(float)), f[["z1", "z2"]])), names

    # Exercise actual parquet streaming with record boundaries inside clusters.
    with tempfile.TemporaryDirectory(prefix="local_adjustment_validation_") as temporary:
        root = Path(temporary)
        cache = root / "synthetic.parquet"
        frame.to_parquet(cache, index=False)
        factory = engine.frame_factory(cache, 113, "1GB", root / "spill")
        model = engine.fit_within_model(factory, design, lambda _: fix.PRICE_TERMS, "synthetic_validation")
        bins, grid, covariance, checks = fix.build_local_plot_data(factory, model, design_builder=design)

    # Independent full dummy-variable OLS; no within transformation is used here.
    f = np.eye(chooser_n * pools)[cell]
    d = np.column_stack((f, g, z))
    theta = np.linalg.lstsq(d, y, rcond=None)[0]
    u = y - d @ theta
    bread = np.linalg.inv(d.T @ d)
    cluster_starts = np.arange(0, n, pools * per_cell)
    score = np.add.reduceat(d * u[:, None], cluster_starts, axis=0)
    codes = fix.local_bin_codes(r, 1.0, 0.25)
    dense_points, influence = [], []
    for b in range(9):
        mask = codes == b
        # Direct adjustment: y - estimated FE - estimated nuisance effects,
        # then subtract the sample mean of the fitted payoff component.
        adjustment_vector = np.r_[f[mask].mean(axis=0), g.mean(axis=0), z[mask].mean(axis=0)]
        dense_points.append(y.mean() + y[mask].mean() - adjustment_vector @ theta)
        influence.append(np.add.reduceat(np.where(mask, u, 0.0), cluster_starts) / mask.sum()
                         - score @ bread @ adjustment_vector)
    influence = np.column_stack(influence)
    cr1 = chooser_n / (chooser_n - 1) * (n - 1) / (n - d.shape[1])
    dense_covariance = cr1 * influence.T @ influence
    np.testing.assert_allclose(model["beta"], theta[-6:], atol=1e-9, rtol=1e-9)
    np.testing.assert_allclose(bins["adjusted_rate_pct"], dense_points, atol=1e-9, rtol=1e-9)
    np.testing.assert_allclose(covariance, dense_covariance, atol=1e-8, rtol=1e-8)
    np.testing.assert_allclose(bins["payoff_mean"], [r[codes == b].mean() for b in range(9)], atol=1e-14)
    np.testing.assert_allclose(bins["adjusted_rate_pct"] - bins["local_fitted_at_bin_mean_pct"],
                               [u[codes == b].mean() for b in range(9)], atol=1e-9)
    assert model["stats"]["clusters"] == chooser_n
    assert model["stats"]["n_fe"] == chooser_n * pools
    assert abs(np.average(bins["adjusted_rate_pct"], weights=bins["n"]) - y.mean()) < 1e-10
    assert np.max(np.abs(bins["payoff_mean"] - bins["payoff_center"])) > 0.001
    for side in ["loss", "gain"]:
        part = grid.loc[grid["side"] == side]
        slope = (part["fitted_rate_pct"].iloc[-1] - part["fitted_rate_pct"].iloc[0]) / (
            part["r_G"].iloc[-1] - part["r_G"].iloc[0])
        np.testing.assert_allclose(slope, model["beta"][0 if side == "loss" else 1], atol=1e-10)
    print(json.dumps({"status": "PASS", "synthetic_rows": n, "chooser_clusters": chooser_n,
                      "fixed_effect_cells": chooser_n * pools,
                      "max_point_error_pp": float(np.max(np.abs(bins["adjusted_rate_pct"] - dense_points))),
                      "max_clustered_covariance_error_pp2": float(np.max(np.abs(covariance - dense_covariance))),
                      "actual_payoff_bin_means_verified": True,
                      "streaming_cluster_boundaries_verified": True,
                      "same_model_dot_line_identity_verified": True}, indent=2))


if __name__ == "__main__":
    main()
