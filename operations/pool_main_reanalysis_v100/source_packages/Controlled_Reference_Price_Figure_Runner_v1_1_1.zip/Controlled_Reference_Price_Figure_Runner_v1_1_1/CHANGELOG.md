# v1.1.1 — local plotting-data correction

- Construct local dots from the same local residuals, fitted payoff terms,
  sample, and normalization as the fitted lines.
- Place local points at mean actual draw payoff within their bins.
- Compute chooser-clustered adjusted-bin uncertainty, including estimated
  nuisance coefficients and fixed effects.
- Draw the exact-zero estimate once and omit connecting broad-tail segments.
- Export a standalone local figure and a clearly labeled two-panel companion,
  each as vector PDF/SVG and a 600-dpi PNG, with matching LaTeX captions.
- Reuse the completed v1.1.0 private local cache and broad aggregate results.
- Authenticate the refit against all v1.1.0 local coefficients, standard
  errors, contrasts, control columns, and sample counts.
- Add an independent explicit-dummy regression check for the new plotting
  statistics and clustered covariance.
- Keep the frozen v1.1.0 scientific model byte-identical. No change to its
  payoff coordinate, control specification, bandwidth, or sample filters.
- Allow the NumPy 2.3 series already used by the successful Mac run.
