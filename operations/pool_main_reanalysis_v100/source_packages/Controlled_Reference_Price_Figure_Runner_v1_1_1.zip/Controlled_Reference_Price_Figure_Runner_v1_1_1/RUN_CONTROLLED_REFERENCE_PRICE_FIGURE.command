#!/bin/bash
set -euo pipefail

task_package_dir="$(cd "$(dirname "$0")" && pwd)"
task_project="/Volumes/XT_Pro/lichess_kindness"
task_source_id="20260907T043218Z_78462"
task_source="${LICHESS_REFERENCE_PRICE_SOURCE_RUN:-$task_project/output/controlled_reference_price_figure_v110/$task_source_id}"
task_private="${LICHESS_REFERENCE_PRICE_SOURCE_PRIVATE:-$task_project/derived/replication/controlled_reference_price_figure_PRIVATE/$task_source_id}"
task_python="${LICHESS_PYTHON:-$(command -v python3)}"
task_threads="${LICHESS_REFERENCE_PRICE_THREADS:-8}"
task_memory="${LICHESS_REFERENCE_PRICE_MEMORY:-8GB}"
task_run_id="${LICHESS_REFERENCE_PRICE_FIX_RUN_ID:-$(date -u +%Y%m%dT%H%M%SZ)_$$}"
task_out="$task_project/output/controlled_reference_price_figure_v111/$task_run_id"
task_scratch="$task_project/derived/replication/controlled_reference_price_figure_FIX_PRIVATE/$task_run_id"
task_log_dir="$task_project/logs/controlled_reference_price_figure_v111"
task_log="$task_log_dir/controlled_reference_price_figure_fix_${task_run_id}.log"

case "$task_threads" in
  1|2|3|4|5|6|7|8|9|10) ;;
  *) echo "ERROR: LICHESS_REFERENCE_PRICE_THREADS must be an integer from 1 to 10." >&2; exit 1 ;;
esac
[[ -f "$task_source/receipts/completion_receipt.json" ]] || {
  echo "ERROR: completed v1.1.0 run not found: $task_source" >&2
  exit 1
}
[[ -f "$task_private/controlled_reference_price_local_h1_private.parquet" ]] || {
  echo "ERROR: existing private local cache not found: $task_private" >&2
  exit 1
}
export OMP_NUM_THREADS="$task_threads"
export OPENBLAS_NUM_THREADS="$task_threads"
export MKL_NUM_THREADS="$task_threads"
export VECLIB_MAXIMUM_THREADS="$task_threads"
export NUMEXPR_NUM_THREADS="$task_threads"
export MPLBACKEND=Agg
export PYTHONDONTWRITEBYTECODE=1

"$task_python" - <<'PY'
import importlib
missing = []
for name in ["duckdb", "matplotlib", "numpy", "pandas", "pyarrow"]:
    try:
        importlib.import_module(name)
    except Exception:
        missing.append(name)
if missing:
    raise SystemExit("Missing Python packages: " + ", ".join(missing) +
                     ". Install requirements.txt into the selected LICHESS_PYTHON environment.")
PY
mkdir -p "$task_log_dir"
echo
echo "CONTROLLED DRAW-PAYOFF FIGURE: CONSISTENT LOCAL DOTS AND FIT"
echo "Expected runtime: approximately 1-5 minutes using the completed local cache."
echo "Threads: $task_threads (maximum 10)"
echo "Source run: $task_source"
echo "Existing local cache: $task_private"
echo "Output: $task_out"
echo "Log: $task_log"
echo

set +e
/usr/bin/caffeinate -dimsu "$task_python" \
  "$task_package_dir/controlled_reference_price_figure.py" \
  --source-run "$task_source" \
  --source-private "$task_private" \
  --out "$task_out" \
  --scratch "$task_scratch" \
  --threads "$task_threads" \
  --memory "$task_memory" \
  --batch-rows 32768 \
  2>&1 | /usr/bin/tee "$task_log"
task_status=${PIPESTATUS[0]}
set -e
if [[ "$task_status" -ne 0 ]]; then
  echo
  echo "CONTROLLED DRAW-PAYOFF FIGURE FIX FAILED"
  echo "Upload the log: $task_log"
  exit "$task_status"
fi
echo
echo "CONTROLLED DRAW-PAYOFF FIGURE FIX COMPLETE"
echo "Paper figure: $task_out/figures/figure_controlled_draw_payoff_local.pdf"
echo "Upload these two aggregate files:"
echo "  ${task_out}.zip"
echo "  ${task_out}.zip.sha256"
