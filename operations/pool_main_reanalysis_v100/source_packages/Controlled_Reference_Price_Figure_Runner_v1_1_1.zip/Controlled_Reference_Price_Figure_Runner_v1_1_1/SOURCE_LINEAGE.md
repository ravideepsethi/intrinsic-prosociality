# Source lineage

Expected production source: `20260907T043218Z_78462`, completed v1.1.0 run.

The source run returned 15,401,589 broad observations and 11,036,021 local
observations. Its enhanced local loss slope was 0.3621380707645658 and its
gain slope was −0.07070848320238594 percentage points per payoff point.
The display correction must reproduce these coefficients; it does not
choose new coefficients to obtain a preferred visual shape.

Frozen executed model script SHA256:

```text
a7cb4e723599705e3aae7416431d5b46fad27ea0bbd8a92671f1390f132b178f
```

This is the exact content of `reference_price_model_v110.py` in this package.
The correction imports its control construction, within transformation,
coefficient fit, chooser-clustered covariance, and serialization functions.
Its original plotting routine is not used.

The new runner verifies every source manifest entry and preserves a copy of
the source completion receipt. Broad aggregate tables are reused; the local
model is refitted from the existing private cache. All estimated local
coefficients and clustered standard errors must agree within 2e-6 absolute
plus 2e-6 relative tolerance. Sample totals and retained/dropped term lists
must match exactly. The new completion receipt records the maximum numerical
difference, cache file size/mtime, source manifest hash, executed code hashes,
and plotting consistency checks.

This release was developed with the user-supplied project-state documents,
the v1.1.0 executed code and aggregate outputs, and the earlier synthetic
validation cache. Private production observations are held on the user's
Mac. Production plotting-data checks therefore execute in the local runner.
