# Controlled draw-payoff figure correction — v1.1.1

This release fixes the mismatch between the local adjusted dots and fitted
lines in v1.1.0. It reads your existing private local cache and reproduces the
completed local model before constructing the corrected plotting data.

**Expected Mac runtime: approximately 1–5 minutes.** Default: 8 threads;
maximum: 10. This is an estimate based on the completed v1.1.0 runtime; the
corrected production run still needs to execute locally.

## Run on the Mac

Place the new ZIP and its `.zip.sha256` file in
`/Users/u6025368/Desktop/Lichess_Desktop`, then run:

```bash
cd /Users/u6025368/Desktop/Lichess_Desktop
shasum -a 256 -c Controlled_Reference_Price_Figure_Runner_v1_1_1.zip.sha256
ditto -x -k Controlled_Reference_Price_Figure_Runner_v1_1_1.zip .
chmod 700 Controlled_Reference_Price_Figure_Runner_v1_1_1/RUN_CONTROLLED_REFERENCE_PRICE_FIGURE.command
Controlled_Reference_Price_Figure_Runner_v1_1_1/RUN_CONTROLLED_REFERENCE_PRICE_FIGURE.command
```

The launcher uses the Python environment that successfully ran v1.1.0.
`LICHESS_PYTHON` can select a specific Python executable. Dependencies are
listed in `requirements.txt`; an already working environment needs no update.

## Existing inputs

The default source run is:

```text
/Volumes/XT_Pro/lichess_kindness/output/controlled_reference_price_figure_v110/20260907T043218Z_78462
```

The default local cache is:

```text
/Volumes/XT_Pro/lichess_kindness/derived/replication/controlled_reference_price_figure_PRIVATE/20260907T043218Z_78462/controlled_reference_price_local_h1_private.parquet
```

If these directories have moved, set `LICHESS_REFERENCE_PRICE_SOURCE_RUN` and
`LICHESS_REFERENCE_PRICE_SOURCE_PRIVATE` to their current directory paths.
The archive you uploaded contains only aggregates; its contents alone cannot
reconstruct the corrected local dots. The local private parquet is required.

## Output

Each execution creates a new timestamped directory under:

```text
/Volumes/XT_Pro/lichess_kindness/output/controlled_reference_price_figure_v111/
```

Logs go under `logs/controlled_reference_price_figure_v111/`. Any temporary
database spill goes under
`derived/replication/controlled_reference_price_figure_FIX_PRIVATE/`. The
original results and private cache are read only. The runner streams four
passes through the existing local cache and makes no second row-level cache.

The main figure is:

```text
figures/figure_controlled_draw_payoff_local.pdf
```

It has actual draw payoff on the horizontal axis; adjusted local-bin points,
chooser-clustered 95% intervals, and fitted loss/gain lines all come from the
same local model. Exact zero appears once. Its caption is `CAPTION_LOCAL.tex`.

The companion is `figures/figure_controlled_reference_price.pdf`: broad
adjusted bins in Panel A and the corrected local figure in Panel B. The panels
have separately estimated adjustments and sample means, clearly identified
in `CAPTION_DRAFT.tex`. Both figures also export SVG and 600-dpi PNG.

At completion, upload the two aggregate output files printed by the launcher:
the timestamped `.zip` and `.zip.sha256`. The ZIP includes figures, aggregate
tables, captions, executed code, and receipts.

## What this fixes

Version 1.1.0 reused broad-sample adjusted bins in the local panel, then
aligned a separately estimated local line to those broad bins. The local
dots therefore did not represent the data after the local model's adjustment.

Version 1.1.1 forms each local adjusted observation as:

```text
local outcome mean + local model residual
  + fitted local payoff component − mean fitted local payoff component
```

It then bins these adjusted observations against the original draw payoff.
The fitted line uses the same model and the same centering. Local dots are
placed at the actual mean payoff in each bin, rather than the bin midpoint.
The broad panel uses the existing broad estimates with no connecting zigzags.

This is a correction to the model display. Its scientific coefficients and
control specification are reproduced from v1.1.0. The corrected dots are
binned partial residuals from the local model; they are not an independent
nonparametric estimate. `METHOD_NOTE.md` gives the construction and inference.

## Verification

Before exporting figures, the runner verifies the source manifest and frozen
model code, matches all local sample counts, checks all retained/dropped
terms, and reproduces every local coefficient, clustered standard error, and
reported contrast within numerical tolerance. It also checks the local mean
normalization, payoff normal equations, and the agreement between the single
zero-payoff dot and the model's zero estimate and standard error.

The release was tested on a separate explicit fixed-effect dummy regression
and on the previous complete synthetic v1.1.0 run. `RELEASE_VALIDATION.json`
records the results. No private production observations are available in the
development workspace; your local run performs the production verification.

An optional independent numerical self-test (about one second) is:

```bash
python3 Controlled_Reference_Price_Figure_Runner_v1_1_1/validate_local_adjustment.py
```

If a run fails, upload the log printed by the launcher. A failed authentication
does not produce a completed figure receipt.
