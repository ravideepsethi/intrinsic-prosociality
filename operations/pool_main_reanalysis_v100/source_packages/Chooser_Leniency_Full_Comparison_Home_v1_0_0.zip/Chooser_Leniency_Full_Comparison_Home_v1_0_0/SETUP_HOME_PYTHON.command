#!/bin/bash
set -euo pipefail
task_env="$HOME/.venvs/lichess-comparison-home"
task_base="${COMP_HOME_BASE_PYTHON:-$(command -v python3 || true)}"
if [[ -z "$task_base" || ! -x "$task_base" ]]; then
  echo 'Install Python 3.10+ or activate your existing Conda environment first.'
  exit 2
fi
"$task_base" -c 'import sys; assert sys.version_info >= (3,10), "Python 3.10+ required"'
if [[ ! -e "$task_env" ]]; then
  mkdir -p "$(dirname "$task_env")"
  "$task_base" -m venv "$task_env"
fi
[[ -x "$task_env/bin/python" ]] || { echo 'Existing environment path is incomplete; inspect it before retrying.'; exit 2; }
"$task_env/bin/python" -m pip install 'numpy>=1.24,<3' 'pyarrow>=14,<26'
"$task_env/bin/python" -c 'import numpy,pyarrow; print("Ready:",numpy.__version__,pyarrow.__version__)'
echo 'Run the preparation or home command again. It will find this isolated environment.'
