#!/usr/bin/env python3
"""Offline integrity/restart tests. Never contact Lichess or read production data."""
import argparse
import contextlib
import io
import itertools
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import urllib.error
import zipfile
from types import SimpleNamespace
import pyarrow as pa
import transfer_common as c
import prepare_transfer as prep
import enrich_home as home
import return_transfer as ret

def game(gid='AbCd1234',status='mate',source='pool'):
    return dict(id=gid,source=source,status=status,rated=True,variant='standard',speed='blitz',
        createdAt=1700000000123,lastMoveAt=1700000300123,winner='white',
        clock=dict(initial=180,increment=2),players=dict(
            white=dict(user=dict(id='alice',name='Alice'),rating=1500),
            black=dict(user=dict(id='bob',name='Bob'),rating=1502)))

def row(gid='AbCd1234'):
    return dict(game_id=gid,month='2023-11',utc_ms=1700000000000,speed_partition='blitz',
        recipient_id=10,opponent_id=11,recipient_color='black',
        baseline_ledger_json=json.dumps(dict(source=None,source_conflict=False,metadata_usable_records=0,
            api_status=None,created_at_ms=None,stage07_identity_agrees=True,in_certified_stage07=False)))

def transport(objects):
    def write(ids,dest,timeout):
        dest.write_text('\n'.join(json.dumps(x) for x in objects))
    return write

class TransferTests(unittest.TestCase):
    def test_downloader_full_pass_loop_and_second_launch_make_no_duplicate_requests(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)/'home'; root.mkdir(); userhome=Path(d)/'user'; userhome.mkdir()
            targets=pa.Table.from_pylist([row(),row('QWER1234'),row('ZXCV1234')])
            c.write_table(root/'inputs/targets.parquet',targets)
            c.atomic_json(root/'TRANSFER.json',dict(transfer_id='fixture',frame_rows=3,api_targets=3))
            c.manifest(root,'INPUT_MANIFEST.json',dict(transfer_id='fixture'))
            calls=[]; payloads=[json.dumps(game()).encode(),json.dumps(game('QWER1234',status='outoftime')).encode(),b'']
            class Response:
                status=200
                headers={'Content-Type':'application/x-ndjson'}
                def __init__(self,payload):self.payload=payload
                def __enter__(self):return self
                def __exit__(self,*args):pass
                def read(self,size):
                    b=self.payload; self.payload=b''; return b
            def open_url(request,timeout):
                calls.append(request.data.decode()); return Response(payloads.pop(0))
            a=SimpleNamespace(package=root,workers=2,passes=3,pause=1.0,timeout=180)
            with patch.object(c,'FRAME_N',3),patch.object(c,'enough_disk'),patch.object(Path,'home',return_value=userhome),\
                 patch.object(home.urllib.request,'urlopen',side_effect=open_url),patch.object(home.time,'time',side_effect=itertools.count(1700000000,2).__next__):
                home.run(a)
                self.assertEqual(calls,['AbCd1234,QWER1234,ZXCV1234','QWER1234,ZXCV1234','ZXCV1234'])
                self.assertEqual(len(payloads),0)
                home.run(a)
                self.assertEqual(len(calls),3)
                latest=c.load(root/'results/LATEST.json'); summary=c.load(root/latest['summary'])
                self.assertEqual(summary['not_returned'],1)

    def test_prepare_package_reuses_cached_pending_and_preserves_full_frame(self):
        with tempfile.TemporaryDirectory() as d:
            base=Path(d); project=base/'project'; desktop=base/'desktop'; code=base/'code'
            old=project/'derived/replication/chooser_leniency_validity_local_v100_PRIVATE'/c.VALIDITY_ID
            (old/'source24m_and_comparison').mkdir(parents=True); (code/'evidence').mkdir(parents=True)
            (code/'evidence/VALIDITY_REPORT.zip').write_bytes(b'fixture evidence')
            c.atomic_json(code/'CODE_MANIFEST.json',dict(files=[]))
            c.atomic_json(old/'source24m_and_comparison/_COMPLETE.json',dict(files=[]))
            fs=[row('AbCd1234'),row('QWER1234'),row('ZXCV1234')]
            f=pa.Table.from_pylist(fs).drop(['baseline_ledger_json'])
            ls=[]
            for ix,x in enumerate(fs):
                l=json.loads(x['baseline_ledger_json']); l['game_id']=x['game_id']
                if ix==0:l.update(source='pool',metadata_usable_records=1,api_status='mate',created_at_ms=1700000000123)
                ls.append(l)
            fpath=base/'frame.parquet'; lpath=base/'ledger.parquet'
            c.write_table(fpath,f); c.write_table(lpath,pa.Table.from_pylist(ls))
            raw=pa.Table.from_pylist([dict(game_id=x,metadata_json=json.dumps(game(x))) for x in ('AbCd1234','QWER1234')])
            args=SimpleNamespace(project_root=project,desktop=desktop,workers=2,cache_manifest=[])
            with patch.object(c,'CODE_ROOT',code),patch.object(c,'FRAME_N',3),patch.object(c,'PENDING_N',2),\
                 patch.object(prep,'BASELINE_RECORDS',2),patch.object(prep,'BASELINE_NONEMPTY',1),\
                 patch.object(prep,'authenticate',return_value=(fpath,lpath)),\
                 patch.object(prep,'source_jobs',return_value=[None]),patch.object(prep,'read_job',return_value=raw):
                prep.build(args)
                out=next((project/'derived/replication/comparison_home_transfer_v100_PRIVATE').iterdir())
                r=c.verify_input(out)
                self.assertEqual(r['api_targets'],1); self.assertEqual(r['cache_recovered_pending'],1)
                self.assertEqual(c.read_table(out/'inputs/targets.parquet')['game_id'].to_pylist(),['ZXCV1234'])
                self.assertEqual(c.read_table(out/'inputs/frame.parquet').to_pylist(),f.to_pylist())
                self.assertTrue(list(desktop.glob('*PRIVATE.zip.sha256')))

    def test_exact_case_and_unrequested(self):
        for gid in ('abcd1234','XXXX9999'):
            with self.assertRaises(RuntimeError): home.parse_response(json.dumps(game(gid)).encode(),['AbCd1234'])

    def test_duplicate_response_is_not_silently_deduplicated(self):
        data=(json.dumps(game())+'\n'+json.dumps(game())).encode()
        with self.assertRaises(RuntimeError): home.parse_response(data,['AbCd1234'])

    def test_truncated_and_nonobject_response(self):
        for data in (b'{"id":"AbCd1234"',b'[]',b'<html>error</html>'):
            with self.assertRaises((ValueError,RuntimeError)): home.parse_response(data,['AbCd1234'])

    def test_empty_response_records_nonreturn(self):
        self.assertEqual(home.parse_response(b'\n\n',['AbCd1234']),{})

    def test_absent_prior_metadata_can_be_enriched(self):
        f=row(); r=c.normalize(game(),f,json.loads(f['baseline_ledger_json']),'test')
        self.assertTrue(r['metadata_valid'],r['error_codes'])
        self.assertIsNone(r['white_provisional'])

    def test_existing_time_conflict_is_preserved(self):
        f=row(); ledger=json.loads(f['baseline_ledger_json']); ledger['metadata_usable_records']=1
        r=c.normalize(game(),f,ledger,'test')
        self.assertFalse(r['metadata_valid']); self.assertIn('TIME_UNRESOLVED',r['error_codes'])

    def test_wrong_game_start_flagged(self):
        f=row(); g=game(); g['createdAt']+=1000
        r=c.normalize(g,f,json.loads(f['baseline_ledger_json']),'test')
        self.assertIn('CREATED_TIME_FRAME_DISAGREEMENT',r['error_codes'])

    def test_all_terminal_statuses_retained(self):
        for status in ('timeout','outoftime','mate','resign','draw','stalemate'):
            f=row(); r=c.normalize(game(status=status),f,json.loads(f['baseline_ledger_json']),'test')
            self.assertEqual(r['status'],status)

    def test_missing_source_not_nonpool(self):
        f=row(); r=c.normalize(game(source=None),f,json.loads(f['baseline_ledger_json']),'test')
        self.assertIsNone(r['source']); self.assertFalse(r['metadata_valid'])

    def test_retry_after_honored(self):
        self.assertGreaterEqual(home.retry_delay({},0),60)
        self.assertGreaterEqual(home.retry_delay({'Retry-After':'1200'},0),1200)
        self.assertGreater(home.retry_delay({},3),home.retry_delay({},0))

    def test_manifest_corruption_blocks_resume(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d); (p/'x').write_text('old'); m=c.manifest(p,'m.json'); (p/'x').write_text('bad')
            with self.assertRaises(RuntimeError): c.verify_records(p,m['files'])

    def test_path_traversal_and_duplicate_zip(self):
        for names in (['../oops'],['/absolute'],['a\\b'],['a','a']):
            import warnings
            with tempfile.TemporaryDirectory() as d,warnings.catch_warnings():
                warnings.simplefilter('ignore'); p=Path(d)/'bad.zip'
                with zipfile.ZipFile(p,'w') as z:
                    for n in names:z.writestr(n,'test')
                with zipfile.ZipFile(p) as z,self.assertRaises(RuntimeError): ret.archive_members(z)

    def test_batch_resume_does_not_refetch_success(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d); b=p/'batch'; gov={'until':0,'path':str(p/'cooldown.json')}
            r,m=home.process_batch(b,[row(),row('QWER1234')],'fixture',0,180,gov,transport([game()]),lambda _:None)
            self.assertEqual((r['returned'],m),(1,['QWER1234']))
            def forbidden(*args): raise AssertionError('Completed batch was refetched')
            r2,m2=home.process_batch(b,[row(),row('QWER1234')],'fixture',0,180,gov,forbidden)
            self.assertEqual(r,r2); self.assertEqual(m,m2)
            with self.assertRaises(RuntimeError): home.verify_batch(b,['AbCd1234'],'fixture')

    def test_partial_network_write_resumes_without_certifying_it(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d); b=p/'batch'; gov={'until':0,'path':str(p/'cooldown.json')}
            def interrupted(ids,dest,timeout):
                dest.write_bytes(b'{"id":'); raise KeyboardInterrupt()
            with self.assertRaises(KeyboardInterrupt): home.process_batch(b,[row()],'fixture',0,180,gov,interrupted)
            self.assertFalse(b.exists()); self.assertTrue(list(p.glob('_partial_*/attempt*')))
            r,_=home.process_batch(b,[row()],'fixture',0,180,gov,transport([game()]))
            self.assertEqual(r['returned'],1)

    def test_429_then_success(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d); calls=[]; waits=[]; gov={'until':0,'path':str(p/'cooldown.json')}
            def t(ids,dest,timeout):
                calls.append(1)
                if len(calls)==1: raise urllib.error.HTTPError(c.ENDPOINT,429,'limited',{'Retry-After':'65'},None)
                return transport([game()])(ids,dest,timeout)
            r,_=home.process_batch(p/'batch',[row()],'fixture',0,180,gov,t,waits.append)
            self.assertEqual(r['returned'],1); self.assertGreaterEqual(waits[0],64)

    def test_schema_loss_stops_before_committing(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d); gov={'until':0,'path':str(p/'cooldown.json')}
            with self.assertRaises(RuntimeError): home.process_batch(p/'batch',[row()],'fixture',0,180,gov,transport([game(source=None)]))
            self.assertFalse((p/'batch').exists()); self.assertTrue(list(p.glob('_partial_*')))

    def test_frame_orientation_and_pending_alignment(self):
        f=pa.Table.from_pylist([row('AbCd1234'),row('QWER1234')]).drop(['baseline_ledger_json'])
        l=pa.Table.from_pylist([dict(game_id='QWER1234',source=None,metadata_usable_records=0,source_conflict=False),
                               dict(game_id='AbCd1234',source='pool',metadata_usable_records=1,source_conflict=False)])
        aligned,pending=prep.align(f,l,2,1)
        self.assertEqual(aligned['game_id'].to_pylist(),f['game_id'].to_pylist())
        self.assertEqual(pending.tolist(),[False,True]); self.assertEqual(f['recipient_color'].to_pylist(),['black','black'])

    def test_second_pass_returns_only_nonreturns_and_summary_preserves_denominator(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d); gov={'until':0,'path':str(p/'cooldown.json')}
            (p/'results/pass_00').mkdir(parents=True); (p/'results/pass_01').mkdir()
            rows=[row('AbCd1234'),row('QWER1234'),row('ZXCV1234')]
            home.process_batch(p/'results/pass_00/batch_000000',rows,'fixture',0,180,gov,transport([game()]))
            home.process_batch(p/'results/pass_01/batch_000000',rows[1:],'fixture',1,180,gov,transport([game('QWER1234',status='outoftime')]))
            s,pending,invalid,_=home.result_summary(p,pa.Table.from_pylist(rows),'fixture')
            self.assertEqual(s['target_games'],3); self.assertEqual(s['returned_unique'],2)
            self.assertEqual(pending['game_id'].to_pylist(),['ZXCV1234']); self.assertEqual(invalid,[])
            self.assertFalse(s['complete_metadata'])

    def test_private_return_roundtrip_and_idempotent_import(self):
        with tempfile.TemporaryDirectory() as d:
            base=Path(d); root=base/'home'; root.mkdir(); (root/'inputs').mkdir(); desktop=base/'desktop'
            rows=[row(),row('QWER1234')]; targets=pa.Table.from_pylist(rows)
            c.write_table(root/'inputs/targets.parquet',targets)
            sourcef=base/'original_frame.parquet'; sourcel=base/'original_ledger.parquet'
            c.write_table(sourcef,targets); c.write_table(sourcel,pa.table({'x':[1]}))
            receipt=dict(transfer_id='fixture',frame_rows=2,api_targets=2,original_frame_sha256=c.sha(sourcef),original_ledger_sha256=c.sha(sourcel))
            c.atomic_json(root/'TRANSFER.json',receipt); c.manifest(root,'INPUT_MANIFEST.json',{'transfer_id':'fixture'})
            (root/'results/pass_00').mkdir(parents=True)
            c.atomic_json(root/'results/RUN_CONFIG.json',dict(transfer_id='fixture',input_manifest_sha256=c.sha(root/'INPUT_MANIFEST.json')))
            gov={'until':0,'path':str(base/'cooldown.json')}
            home.process_batch(root/'results/pass_00/batch_000000',rows,'fixture',0,180,gov,transport([game()]))
            with patch.object(c,'FRAME_N',2),patch.object(prep,'authenticate',return_value=(sourcef,sourcel)):
                archive=ret.pack(root,desktop,2)
                project=base/'project'; project.mkdir()
                imported=ret.import_archive(archive,project,2)
                self.assertTrue((imported/'IMPORT_RECEIPT.json').is_file())
                again=ret.import_archive(archive,project,2); self.assertEqual(imported,again)
                self.assertEqual(c.read_table(imported/'inputs/targets.parquet')['recipient_color'].to_pylist(),['black','black'])
            public=next(desktop.glob('*REPORT*.zip'))
            with zipfile.ZipFile(public) as z:
                blob=b'\n'.join(z.read(n) for n in z.namelist())
                self.assertNotIn(b'AbCd1234',blob); self.assertNotIn(b'alice',blob)

if __name__=='__main__':
    parser=argparse.ArgumentParser(); parser.add_argument('--require-io',action='store_true'); parser.parse_args()
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(TransferTests))
    if not result.wasSuccessful(): raise SystemExit(1)
    print(f'FULL_COMPARISON_TRANSFER_TESTS_OK tests={result.testsRun}; skips={len(result.skipped)}')
