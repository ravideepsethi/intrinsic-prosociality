#!/usr/bin/env python3
"""Pack private results on home Mac; import into a NEW directory on the data Mac."""
from __future__ import annotations
import argparse
import datetime as dt
import fcntl
import json
import os
from pathlib import Path
import shutil
import stat
import zipfile
import transfer_common as c
import enrich_home as enrich
import prepare_transfer as prepare

def archive_members(z):
    infos=z.infolist(); names=[i.filename for i in infos]
    if len(names)!=len(set(names)): raise RuntimeError('Duplicate archive members')
    total=0
    for i in infos:
        c.relative_safe(i.filename)
        mode=i.external_attr>>16
        if stat.S_ISLNK(mode): raise RuntimeError('Symlink in return archive')
        total+=i.file_size
    return total

def pack(root, desktop, workers):
    receipt=c.verify_input(root,workers)
    results=root/'results'
    if not results.is_dir(): raise RuntimeError('No home results exist')
    with (results/'RUN.lock').open('a+') as lock:
        try: fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError: raise RuntimeError('Stop the downloader before packaging its results')
        config=c.load(results/'RUN_CONFIG.json')
        if config['input_manifest_sha256']!=c.sha(root/'INPUT_MANIFEST.json') or config['transfer_id']!=receipt['transfer_id']:
            raise RuntimeError('Home run does not match this input transfer')
        targets=c.read_table(root/'inputs/targets.parquet')
        summary,pending,invalid,completed=enrich.result_summary(root,targets,receipt['transfer_id'],workers)
        desktop.mkdir(parents=True,exist_ok=True)
        stamp=dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'_'+c.uuid.uuid4().hex[:6]
        report=results/'return_reports'/stamp; report.mkdir(parents=True,exist_ok=False)
        c.atomic_json(report/'SUMMARY.json',summary)
        (report/'README.md').write_text(
            '# Full comparison API enrichment\n\n'
            f'Original comparison frame: {c.FRAME_N:,}.\n'
            f'API targets: {len(targets):,}. Returned: {summary["returned_unique"]:,}. '
            f'Nonreturns: {summary["not_returned"]:,}. Metadata flags: {len(invalid):,}.\n\n'
            'All original statuses and recipient orientations are retained. Missing source is not non-pool. '
            'Missing chat/takebacks do not establish absence. No placebo or selection model is estimated here.\n'
        )
        c.manifest(report,'REPORT_MANIFEST.json')
        public=desktop/f'CHOOSER_COMPARISON_HOME_REPORT_{receipt["transfer_id"]}_{stamp}.zip'
        c.zip_paths(report,public,sorted(p for p in report.iterdir() if p.is_file()))
        inputs=c.load(root/'INPUT_MANIFEST.json')
        paths=[root/r['path'] for r in inputs['files']]+[root/'INPUT_MANIFEST.json',results/'RUN_CONFIG.json']
        for b in completed:
            r=c.load(b/'BATCH.json')
            paths.extend(b/x['path'] for x in r['files']); paths.append(b/'BATCH.json')
        paths.extend(p for p in report.iterdir() if p.is_file())
        # Export a snapshot with a separate manifest; no live logs/partials or credentials.
        audit=root/f'RETURN_MANIFEST_{stamp}.json'
        m=c.manifest(root,audit.name,dict(transfer_id=receipt['transfer_id'],
            input_manifest_sha256=c.sha(root/'INPUT_MANIFEST.json'),summary=summary),paths=paths)
        paths.append(audit)
        needed=sum(p.stat().st_size for p in paths)
        if shutil.disk_usage(desktop).free<needed+1024**3: raise RuntimeError('Insufficient free space for return ZIP')
        dest=desktop/f'CHOOSER_COMPARISON_HOME_RETURN_{receipt["transfer_id"]}_{stamp}_PRIVATE.zip'
        digest=c.zip_paths(root,dest,paths)
        c.log(f'PRIVATE RETURN ZIP: {dest}')
        c.log(f'SHA256: {digest}')
        c.log(f'AGGREGATE REPORT FOR UPLOAD: {public}')
        c.log('HOME_RETURN_PACKAGE_READY')
        return dest

def import_archive(archive,project,workers):
    archive=archive.expanduser().resolve(); side=archive.with_name(archive.name+'.sha256')
    if not side.is_file(): raise RuntimeError('Place the return ZIP checksum sidecar next to the ZIP')
    digest=side.read_text().split()[0]
    if not c.re.fullmatch('[0-9a-f]{64}',digest): raise RuntimeError('Invalid checksum sidecar')
    c.checked(archive,digest)
    project=project.expanduser().resolve()
    old=project/'derived/replication/chooser_leniency_validity_local_v100_PRIVATE'/c.VALIDITY_ID
    frame,ledger=prepare.authenticate(old)
    with zipfile.ZipFile(archive) as z:
        total=archive_members(z)
        names=z.namelist()
        candidates=[n for n in names if c.re.fullmatch(r'RETURN_MANIFEST_[A-Za-z0-9_]+\.json',n)]
        if len(candidates)!=1: raise RuntimeError('Expected exactly one return manifest')
        m=json.loads(z.read(candidates[0]))
        expected={r['path'] for r in m['files']}|{candidates[0]}
        if len(expected)!=len(names) or expected!=set(names): raise RuntimeError('Return contains missing or unlisted files')
        tid=m['transfer_id']
        if not c.re.fullmatch('[A-Za-z0-9_]+',tid): raise RuntimeError('Invalid transfer ID')
        receipt=json.loads(z.read('TRANSFER.json'))
        if receipt['transfer_id']!=tid or receipt['original_frame_sha256']!=c.sha(frame) or receipt['original_ledger_sha256']!=c.sha(ledger):
            raise RuntimeError('Return belongs to a different original frame/ledger')
        base=project/'derived/replication/comparison_api_home_v100_PRIVATE'
        base.mkdir(parents=True,exist_ok=True)
        if shutil.disk_usage(base).free<total+1024**3: raise RuntimeError('Insufficient space to import return')
        final=base/(tid+'_'+digest[:12])
        if final.exists():
            previous=c.load(final/'IMPORT_RECEIPT.json')
            if previous['archive_sha256']!=digest: raise RuntimeError('Existing import differs')
            c.verify_records(final,m['files'],workers)
            c.log(f'ALREADY_IMPORTED_AND_VERIFIED: {final}'); return final
        stage=base/('_partial_'+tid+'_'+c.uuid.uuid4().hex)
        stage.mkdir(exist_ok=False)
        z.extractall(stage)
    c.verify_records(stage,m['files'],workers)
    c.verify_input(stage,workers)
    if c.sha(stage/'INPUT_MANIFEST.json')!=m['input_manifest_sha256']: raise RuntimeError('Returned input manifest changed')
    summary,_,_,_=enrich.result_summary(stage,c.read_table(stage/'inputs/targets.parquet'),tid,workers)
    if summary!=m['summary']: raise RuntimeError('Return summary does not reproduce from the exported rows')
    c.atomic_json(stage/'IMPORT_RECEIPT.json',dict(status='FULL_COMPARISON_HOME_RETURN_IMPORTED',
        archive_sha256=digest,transfer_id=tid,original_frame_sha256=c.sha(frame),
        original_ledger_sha256=c.sha(ledger),row_level_merge_into_certified_inputs=False,summary=summary))
    os.replace(stage,final)
    c.log(f'FULL_COMPARISON_HOME_RETURN_IMPORTED: {final}')
    c.log('Certified inputs were not modified. Imported API records are ready for the comparison-frame reconciliation stage.')
    return final

def main():
    p=argparse.ArgumentParser(description=__doc__); sp=p.add_subparsers(dest='action',required=True)
    packp=sp.add_parser('pack'); packp.add_argument('--package',type=Path,default=c.CODE_ROOT)
    packp.add_argument('--desktop',type=Path,default=Path.home()/'Desktop/Lichess_Desktop')
    packp.add_argument('--workers',type=int,default=4)
    ip=sp.add_parser('import'); ip.add_argument('archive',type=Path)
    ip.add_argument('--project-root',type=Path,default=Path('/Volumes/XT_Pro/lichess_kindness'))
    ip.add_argument('--workers',type=int,default=4)
    a=p.parse_args()
    if not 1<=a.workers<=10: p.error('Use 1-10 local workers')
    os.umask(0o077)
    if a.action=='pack': pack(a.package.resolve(),a.desktop.expanduser().resolve(),a.workers)
    else: import_archive(a.archive,a.project_root,a.workers)

if __name__=='__main__': main()
