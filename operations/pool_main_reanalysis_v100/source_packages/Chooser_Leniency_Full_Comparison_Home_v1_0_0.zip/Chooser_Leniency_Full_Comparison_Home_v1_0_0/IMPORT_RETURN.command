#!/bin/bash
set -euo pipefail
task_here="$(cd "$(dirname "$0")" && pwd)"
if [[ "$#" -ne 1 ]]; then
  echo 'Usage: /bin/bash IMPORT_RETURN.command /absolute/path/to/PRIVATE-return.zip'
  exit 2
fi
exec /usr/bin/caffeinate -dimsu /bin/bash "$task_here/launch.command" import "$1"
