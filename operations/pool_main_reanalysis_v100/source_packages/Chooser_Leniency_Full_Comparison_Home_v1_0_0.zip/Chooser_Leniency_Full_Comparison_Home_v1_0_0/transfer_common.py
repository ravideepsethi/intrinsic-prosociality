"""Private, append-only transfer and enrichment helpers. Python >=3.10."""
from __future__ import annotations
import concurrent.futures as cf
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import time
import uuid
import zipfile
import pyarrow as pa
import pyarrow.parquet as pq
import preliminary_core as core

VERSION = '1.0.0'
VALIDITY_ID = '20260906T052017Z_46893'
VALIDITY_SHA = 'ff14f791073667bb57324c5c80ca727bcdc2fb72e6d802a9d482386c12de9e7d'
VALIDITY_CONFIG = 'f472f94e84149d4ee75626b87977a46457bdb41ea69a29e44c82ab33f83cd46b'
FRAME_N = 1912023
PENDING_N = 1764603
CODE_ROOT = Path(__file__).resolve().parent
ENDPOINT = 'https://lichess.org/api/games/export/_ids?moves=false&clocks=false&evals=false&opening=false&literate=false&pgnInJson=false&tags=true'

def log(message):
    print(f'[{dt.datetime.now(dt.timezone.utc):%Y-%m-%d %H:%M:%SZ}] {message}', flush=True)

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(8 * 1024**2), b''): h.update(b)
    return h.hexdigest()

def load(path):
    return json.loads(Path(path).read_text())

def atomic_json(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.partial.' + uuid.uuid4().hex)
    with tmp.open('w') as f:
        json.dump(value, f, indent=2, sort_keys=True, allow_nan=False)
        f.write('\n'); f.flush(); os.fsync(f.fileno())
    os.replace(tmp, path)

def checked(path, expected):
    path = Path(path)
    if not path.is_file() or sha(path) != expected:
        raise RuntimeError(f'Hash mismatch or missing file: {path}')
    return path

def relative_safe(value):
    p = Path(value)
    if p.is_absolute() or '..' in p.parts or '\\' in value or not p.parts:
        raise RuntimeError('Unsafe relative path')
    return p

def read_table(path, columns=None):
    return pq.ParquetFile(path).read(columns=columns, use_threads=False)

def write_table(path, table):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists(): raise RuntimeError(f'Refusing to overwrite {path}')
    tmp = path.with_name(path.name + '.partial.' + uuid.uuid4().hex)
    pq.write_table(table, tmp, compression='zstd', row_group_size=65536)
    with tmp.open('rb') as f: os.fsync(f.fileno())
    os.replace(tmp, path)

def file_record(root, path):
    path = Path(path)
    return dict(path=path.relative_to(root).as_posix(), bytes=path.stat().st_size, sha256=sha(path))

def verify_records(root, records, workers=4):
    paths = [r['path'] for r in records]
    if len(paths) != len(set(paths)): raise RuntimeError('Duplicate manifest paths')
    def one(r):
        p = Path(root) / relative_safe(r['path'])
        if p.is_symlink() or not p.is_file() or p.stat().st_size != int(r['bytes']):
            raise RuntimeError(f'Manifest size/type mismatch: {p}')
        checked(p, r['sha256'])
    with cf.ThreadPoolExecutor(max_workers=max(1, min(workers, 10))) as ex:
        for _ in ex.map(one, records): pass

def manifest(root, name, extra=None, paths=None):
    root = Path(root)
    paths = paths if paths is not None else sorted(p for p in root.rglob('*') if p.is_file() and p.name != name)
    value = dict(extra or {}, files=[file_record(root, p) for p in paths])
    atomic_json(root / name, value)
    return value

def verify_input(root, workers=4):
    root = Path(root); m = load(root / 'INPUT_MANIFEST.json')
    verify_records(root, m['files'], workers)
    receipt = load(root / 'TRANSFER.json')
    if m['transfer_id'] != receipt['transfer_id']: raise RuntimeError('Transfer identity mismatch')
    if receipt['frame_rows'] != FRAME_N: raise RuntimeError('Unexpected original frame size')
    return receipt

def checkpoint_file(root, filename, config=VALIDITY_CONFIG):
    root = Path(root); receipt = load(root / '_COMPLETE.json')
    if receipt.get('config_sha256') != config: raise RuntimeError('Source checkpoint configuration mismatch')
    hits = [r for r in receipt['files'] if r['path'] == filename]
    if len(hits) != 1: raise RuntimeError(f'Expected one authenticated {filename} in {root}')
    verify_records(root, hits)
    return root / relative_safe(filename), receipt

def metadata_schema():
    fields = [('game_id', pa.string()), ('source', pa.string()), ('status', pa.string()),
              ('api_start_ms', pa.int64()), ('anchor_ms', pa.int64()), ('rated', pa.bool_()),
              ('variant', pa.string()), ('speed', pa.string()), ('winner', pa.string()),
              ('tc_base_s', pa.int64()), ('tc_inc_s', pa.int64())]
    for side in ('white', 'black'):
        fields += [(side + '_username', pa.string()), (side + '_rating', pa.float64()),
                   (side + '_provisional', pa.bool_())]
    return pa.schema(fields + [('month', pa.string()), ('metadata_valid', pa.bool_()),
                 ('error_codes', pa.string()), ('metadata_json', pa.string()), ('origin', pa.string())])

def validate_record(r, frame, ledger, errors):
    ledger = dict(ledger)
    # No earlier export is absence of evidence, not an unresolved time conflict.
    # Preserve all disagreements when any usable earlier metadata existed.
    if not ledger.get('metadata_usable_records',0) and ledger.get('created_at_ms') is None:
        ledger.pop('created_at_ms',None)
    errors = set(core.validate_metadata(r, frame, ledger, errors))
    # This job enriches the whole frame. Also flag incomplete exports for non-pool
    # games, while retaining their explicit source and all returned bytes.
    for field in ('status','api_start_ms','anchor_ms','rated','variant','speed',
                  'tc_base_s','tc_inc_s','white_username','black_username','white_rating','black_rating'):
        if r.get(field) is None: errors.add('MISSING_'+field.upper())
    if r.get('status') not in core.TERMINAL: errors.add('NOT_RECOGNIZED_FINISHED_GAME')
    if r.get('api_start_ms') is not None and r['api_start_ms']//1000!=frame['utc_ms']//1000:
        errors.add('CREATED_TIME_FRAME_DISAGREEMENT')
    if r.get('speed')!=frame['speed_partition']: errors.add('SPEED_FRAME_DISAGREEMENT')
    return sorted(errors)

def normalize(obj, frame, ledger, origin):
    r, errors = core.normalize_export(obj, frame['game_id'])
    errors = validate_record(r, frame, ledger, errors)
    r.update(month=frame['month'], metadata_valid=not errors, error_codes=';'.join(errors),
             metadata_json=json.dumps(obj, separators=(',', ':'), ensure_ascii=False), origin=origin)
    return {f.name: r.get(f.name) for f in metadata_schema()}

def zip_paths(root, destination, paths):
    destination = Path(destination)
    if destination.exists(): raise RuntimeError(f'Archive already exists: {destination}')
    tmp = destination.with_name(destination.name + '.partial.' + uuid.uuid4().hex)
    with zipfile.ZipFile(tmp, 'w', compression=zipfile.ZIP_STORED, allowZip64=True) as z:
        for p in paths:
            p = Path(p); z.write(p, p.relative_to(root).as_posix())
    with zipfile.ZipFile(tmp) as z:
        if z.testzip() is not None: raise RuntimeError('Archive CRC failure')
    os.replace(tmp, destination)
    checksum = sha(destination)
    destination.with_name(destination.name + '.sha256').write_text(checksum + '  ' + destination.name + '\n')
    return checksum

def pause(seconds):
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        remaining = deadline - time.monotonic()
        if remaining > 20: log(f'API cooldown: {remaining:.0f} seconds remaining')
        time.sleep(min(20, max(0, remaining)))

def enough_disk(root, gib):
    if shutil.disk_usage(root).free < gib * 1024**3:
        raise RuntimeError(f'Need at least {gib} GiB free on {root}')
