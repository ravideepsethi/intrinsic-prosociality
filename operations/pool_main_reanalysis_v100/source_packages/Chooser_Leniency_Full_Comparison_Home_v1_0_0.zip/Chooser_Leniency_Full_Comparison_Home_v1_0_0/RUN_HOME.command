#!/bin/bash
set -euo pipefail
task_here="$(cd "$(dirname "$0")" && pwd)"
exec /usr/bin/caffeinate -dimsu /bin/bash "$task_here/launch.command" download "$@"
