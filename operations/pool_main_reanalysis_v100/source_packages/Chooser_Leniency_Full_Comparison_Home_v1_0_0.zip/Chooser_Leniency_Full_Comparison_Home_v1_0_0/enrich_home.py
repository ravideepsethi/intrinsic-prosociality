#!/usr/bin/env python3
"""Sequential, resumable Lichess export for the frozen full comparison targets."""
from __future__ import annotations
import argparse
from collections import Counter
import datetime as dt
import email.utils
import fcntl
import gzip
import http.client
import json
import os
from pathlib import Path
import socket
import time
import urllib.error
import urllib.request
import pyarrow as pa
import pyarrow.compute as pc
import transfer_common as c

BATCH_SIZE = 300
MAX_RESPONSE_BYTES = 64*1024**2

def retry_delay(headers, attempt):
    value = headers.get('Retry-After', '') if headers else ''
    try: advertised = max(0, float(value))
    except (ValueError, TypeError):
        try: advertised = max(0, email.utils.parsedate_to_datetime(value).timestamp()-time.time())
        except (ValueError, TypeError, AttributeError): advertised = 0
    return max(advertised, min(900, 60*(2**attempt)))

def request_once(ids, destination, timeout):
    headers = {'Accept':'application/x-ndjson','Content-Type':'text/plain',
               'User-Agent':'LichessKindnessResearch/1.0 (sequential academic game export)'}
    token = os.environ.get('LICHESS_API_TOKEN')
    if token: headers['Authorization']='Bearer '+token
    req = urllib.request.Request(c.ENDPOINT, data=','.join(ids).encode('ascii'), headers=headers, method='POST')
    total=0
    # Partial bytes stay on disk on a broken connection and are not certified as a batch.
    with urllib.request.urlopen(req, timeout=timeout) as response, Path(destination).open('xb') as f:
        if response.status != 200: raise RuntimeError(f'Unexpected HTTP status {response.status}')
        content_type=response.headers.get('Content-Type','').lower()
        if 'ndjson' not in content_type: raise RuntimeError('Expected NDJSON, received a different content type')
        while True:
            block=response.read(65536)
            if not block: break
            total += len(block)
            if total > MAX_RESPONSE_BYTES: raise RuntimeError('Response exceeds 64 MiB batch safety bound')
            f.write(block)
        f.flush(); os.fsync(f.fileno())
    return total

def parse_response(data, requested):
    allowed=set(requested); found={}
    for line in data.splitlines():
        if not line.strip(): continue
        obj=json.loads(line)
        if not isinstance(obj,dict): raise RuntimeError('Non-object in NDJSON response')
        gid=obj.get('id')
        if not isinstance(gid,str) or gid not in allowed: raise RuntimeError('Wrong-case or unrequested game ID returned')
        if gid in found: raise RuntimeError('Duplicate ID in response; batch not certified')
        found[gid]=obj
    return found

def batch_binding(ids):
    return c.hashlib.sha256('\n'.join(ids).encode('ascii')).hexdigest()

def verify_batch(path, ids, transfer_id, workers=1):
    r=c.load(path/'BATCH.json')
    if r['transfer_id']!=transfer_id or r['requested_sha256']!=batch_binding(ids):
        raise RuntimeError('Resume batch does not match the frozen target list')
    c.verify_records(path,r['files'],workers)
    if c.load(path/'requested.json')!=ids: raise RuntimeError('Saved request differs from the expected batch')
    t=c.read_table(path/'metadata.parquet',['game_id']); returned=t['game_id'].to_pylist()
    missing=c.read_table(path/'missing.parquet',['game_id'])['game_id'].to_pylist()
    if len(returned)!=len(set(returned)) or len(missing)!=len(set(missing)):
        raise RuntimeError('Duplicate ID in saved batch')
    if set(returned)&set(missing) or set(returned)|set(missing)!=set(ids):
        raise RuntimeError('Saved batch fails requested = returned + missing accounting')
    if len(returned)!=r['returned'] or len(missing)!=r['missing'] or len(ids)!=r['requested']:
        raise RuntimeError('Batch count receipt disagreement')
    return r, missing

def process_batch(path, rows, transfer_id, pass_no, timeout, governor,
                  transport=request_once, sleeper=c.pause):
    ids=[r['game_id'] for r in rows]
    if path.exists(): return verify_batch(path,ids,transfer_id)
    stage=path.parent/('_partial_'+path.name+'_'+c.uuid.uuid4().hex)
    stage.mkdir(parents=True,exist_ok=False)
    c.atomic_json(stage/'requested.json',ids)
    raw=None
    for attempt in range(8):
        delay=governor.get('until',0)-time.time()
        if delay>0: sleeper(delay)
        candidate=stage/f'attempt_{attempt:02d}.ndjson.partial'
        try:
            transport(ids,candidate,timeout)
            raw=candidate; break
        except urllib.error.HTTPError as e:
            code=e.code
            c.atomic_json(stage/f'http_{attempt:02d}.json',dict(status=code,time_utc=dt.datetime.now(dt.timezone.utc).isoformat()))
            headers=e.headers; e.close()
            if code not in (408,425,429,500,502,503,504):
                raise RuntimeError(f'HTTP {code}; stopped without advancing this batch') from None
            wait=retry_delay(headers,attempt)
        except (urllib.error.URLError,TimeoutError,socket.timeout,ConnectionError,http.client.HTTPException) as e:
            wait=min(300,10*(2**attempt))
            c.atomic_json(stage/f'network_{attempt:02d}.json',dict(error_type=type(e).__name__))
        governor['until']=time.time()+wait
        c.atomic_json(Path(governor['path']),dict(until=governor['until']))
        c.log(f'API retry {attempt+1}/8; waiting {wait:.0f} seconds')
    if raw is None: raise RuntimeError('Eight transient request failures; resume later from this batch')
    found=parse_response(raw.read_bytes(),ids)
    # Detect the common HTML/schema failure before committing thousands of unusable responses.
    if len(found)>=min(10,len(ids)) and all(not isinstance(x.get('source'),str) for x in found.values()):
        raise RuntimeError('API exports lack explicit source in this batch; bytes preserved, enrichment stopped')
    metadata=[]
    for row in rows:
        if row['game_id'] in found:
            ledger=json.loads(row['baseline_ledger_json'])
            metadata.append(c.normalize(found[row['game_id']],row,ledger,f'home_API_pass{pass_no}'))
    c.write_table(stage/'metadata.parquet',pa.Table.from_pylist(metadata,schema=c.metadata_schema()))
    missing=[g for g in ids if g not in found]
    c.write_table(stage/'missing.parquet',pa.table({'game_id':pa.array(missing,type=pa.string())}))
    with raw.open('rb') as src,gzip.open(stage/'response.ndjson.gz','wb',compresslevel=3) as dst:
        c.shutil.copyfileobj(src,dst)
    # Preserve prior failed-attempt bytes as well, compressed, if any.
    for p in stage.glob('*.ndjson.partial'):
        if p!=raw:
            with p.open('rb') as src,gzip.open(p.with_suffix('.gz'),'wb',compresslevel=3) as dst: c.shutil.copyfileobj(src,dst)
        p.unlink()  # Only our temporary file; successful bytes are now retained in gzip.
    r=c.manifest(stage,'BATCH.json',dict(transfer_id=transfer_id,pass_no=pass_no,
        requested_sha256=batch_binding(ids),requested=len(ids),returned=len(found),missing=len(missing),
        metadata_valid=sum(bool(r['metadata_valid']) for r in metadata),
        months=sorted(set(r['month'] for r in rows)),http_success=True))
    os.replace(stage,path)
    return r,missing

def result_summary(root,targets,transfer_id,workers=4):
    counts=Counter(); bymonth=Counter(); seen=set(); invalid=[]; completed=[]
    for batch in sorted((root/'results').glob('pass_*/batch_*')):
        if not (batch/'BATCH.json').is_file(): raise RuntimeError('Uncertified batch directory')
        r=c.load(batch/'BATCH.json')
        ids=c.load(batch/'requested.json')
        verify_batch(batch,ids,transfer_id,workers)
        completed.append(batch)
        for row in c.read_table(batch/'metadata.parquet').to_pylist():
            gid=row['game_id']
            if gid in seen: raise RuntimeError('A returned game was fetched again; inspect batch lineage')
            seen.add(gid)
            counts[(row['source'] or 'MISSING',row['status'] or 'MISSING')]+=1
            bymonth[(row['month'],bool(row['metadata_valid']))]+=1
            if not row['metadata_valid']: invalid.append(dict(game_id=gid,month=row['month'],reason=row['error_codes']))
    target_ids=set(targets['game_id'].to_pylist())
    if not seen.issubset(target_ids): raise RuntimeError('Result outside frozen API target set')
    pending=targets.filter(pc.invert(pc.is_in(targets['game_id'],value_set=pa.array(sorted(seen),type=pa.string()))))
    summary=dict(transfer_id=transfer_id,original_comparison_frame=c.FRAME_N,target_games=len(targets),
        returned_unique=len(seen),not_returned=len(pending),returned_with_metadata_flags=len(invalid),
        complete_metadata=(len(pending)==0 and len(invalid)==0),
        status='ENRICHMENT_RETRIEVAL_COMPLETE' if len(pending)==0 and len(invalid)==0 else 'ENRICHMENT_FINISHED_WITH_GAPS',
        status_composition=[dict(source=s,status=t,games=n) for (s,t),n in sorted(counts.items())],
        by_month=[dict(month=m,metadata_valid=v,games=n) for (m,v),n in sorted(bymonth.items())],
        no_missing_values_coded_as_zero=True,causal_tests_estimated=False)
    return summary,pending,invalid,completed

def run(a):
    root=a.package.resolve(); receipt=c.verify_input(root,a.workers)
    c.enough_disk(root,8)
    targets=c.read_table(root/'inputs/targets.parquet')
    if len(targets)!=receipt['api_targets']: raise RuntimeError('API target count changed')
    if len(set(targets['game_id'].to_pylist()))!=len(targets): raise RuntimeError('Duplicate targets')
    results=root/'results'; results.mkdir(exist_ok=True)
    # Local flock protects two copies of this downloader; it cannot see jobs on other machines.
    lockdir=Path.home()/'.cache/lichess_research_api'; lockdir.mkdir(parents=True,exist_ok=True)
    with (lockdir/'one_request.lock').open('a+') as lock, (results/'RUN.lock').open('a+') as runlock:
        try: fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError: raise RuntimeError('Another copy of this API downloader is running on this laptop')
        try: fcntl.flock(runlock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError: raise RuntimeError('This transfer is being downloaded or packaged by another process')
        gp=lockdir/'cooldown.json'; governor=c.load(gp) if gp.exists() else {'until':0}
        governor['path']=str(gp)
        config=dict(version=c.VERSION,transfer_id=receipt['transfer_id'],input_manifest_sha256=c.sha(root/'INPUT_MANIFEST.json'),
                    endpoint=c.ENDPOINT,batch_size=BATCH_SIZE,passes=a.passes,minimum_pause_seconds=a.pause)
        configpath=results/'RUN_CONFIG.json'
        if configpath.exists() and c.load(configpath)!=config: raise RuntimeError('Resume settings differ from the existing run')
        if not configpath.exists(): c.atomic_json(configpath,config)
        remaining=targets; active_start=time.monotonic(); fetched_this_run=0
        for pass_no in range(a.passes):
            missing_all=[]; number=(len(remaining)+BATCH_SIZE-1)//BATCH_SIZE
            c.log(f'Pass {pass_no+1}/{a.passes}: {len(remaining):,} pending IDs, {number:,} batches')
            for k in range(number):
                rows=remaining.slice(k*BATCH_SIZE,BATCH_SIZE).to_pylist()
                path=results/f'pass_{pass_no:02d}'/f'batch_{k:06d}'
                path.parent.mkdir(parents=True,exist_ok=True)
                cached=path.exists()
                r,missing=process_batch(path,rows,receipt['transfer_id'],pass_no,a.timeout,governor)
                missing_all.extend(missing)
                if not cached:
                    fetched_this_run+=r['returned']
                    governor['until']=time.time()+a.pause
                    c.atomic_json(gp,dict(until=governor['until']))
                if not cached or (k+1)%100==0 or k+1==number:
                    elapsed=max(1,time.monotonic()-active_start); rate=fetched_this_run/elapsed
                    approx_remaining=max(0,len(remaining)-(k+1)*BATCH_SIZE)
                    eta=f'; current-pass ETA {approx_remaining/rate/3600:.1f} h' if rate>0 else ''
                    c.log(f'Pass {pass_no+1} batch {k+1:,}/{number:,}; returned {r["returned"]}/{r["requested"]}; {rate:.2f} games/s{eta}'+(' [verified cached]' if cached else ''))
            remaining=remaining.filter(pc.is_in(remaining['game_id'],value_set=pa.array(missing_all,type=pa.string())))
            if not len(remaining): break
        c.log('All planned request passes finished; verifying and preparing aggregate report')
        s,pending,invalid,_=result_summary(root,targets,receipt['transfer_id'],a.workers)
        stamp=dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'_'+c.uuid.uuid4().hex[:6]
        snapshot=results/'summaries'/stamp; snapshot.mkdir(parents=True)
        c.write_table(snapshot/'not_returned.parquet',pending)
        c.write_table(snapshot/'metadata_flagged.parquet',pa.Table.from_pylist(invalid,schema=pa.schema([('game_id',pa.string()),('month',pa.string()),('reason',pa.string())])))
        c.atomic_json(snapshot/'SUMMARY.json',s)
        c.atomic_json(results/'LATEST.json',dict(summary=str((snapshot/'SUMMARY.json').relative_to(root))))
        c.log(s['status'])
        c.log(f'Returned {s["returned_unique"]:,}; nonreturns {s["not_returned"]:,}; returned metadata flags {s["returned_with_metadata_flags"]:,}')
        c.log('Run PACK_RETURN.command to create the private return archive and small aggregate report.')

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--package',type=Path,default=c.CODE_ROOT)
    p.add_argument('--workers',type=int,default=4,help='Local hashing only; API concurrency is always one')
    p.add_argument('--passes',type=int,default=3)
    p.add_argument('--pause',type=float,default=1.0)
    p.add_argument('--timeout',type=float,default=180.0)
    a=p.parse_args()
    if not 1<=a.workers<=10 or not 1<=a.passes<=3 or a.pause<1 or a.timeout<30: p.error('Require 1-10 workers, 1-3 passes, pause >=1s, timeout >=30s')
    os.umask(0o077)
    try: run(a)
    except KeyboardInterrupt: c.log('STOPPED. Completed batches are retained. Run the same command to resume.'); raise SystemExit(130)

if __name__=='__main__': main()
