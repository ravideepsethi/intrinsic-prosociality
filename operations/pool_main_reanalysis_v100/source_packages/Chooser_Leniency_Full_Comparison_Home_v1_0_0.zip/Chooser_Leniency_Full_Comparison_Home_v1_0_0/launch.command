#!/bin/bash
set -euo pipefail
umask 077
task_here="$(cd "$(dirname "$0")" && pwd)"
cd "$task_here"
task_action="${1:-}"
if [[ -z "$task_action" ]]; then
  echo 'Use PREPARE_TRANSFER.command on the data Mac or RUN_HOME.command on the home laptop.'
  exit 2
fi
shift
/usr/bin/shasum -a 256 -c PACKAGE_MANIFEST.sha256
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export VECLIB_MAXIMUM_THREADS=1 NUMEXPR_NUM_THREADS=1
export PYTHONUNBUFFERED=1 PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1
task_python="${COMP_HOME_PYTHON:-}"
if [[ -z "$task_python" ]]; then
  for task_candidate in \
    "$HOME/.venvs/lichess-comparison-home/bin/python" \
    "$(command -v python3 || true)" "$(command -v python || true)" \
    "$HOME/miniconda3/bin/python" "$HOME/anaconda3/bin/python" \
    /opt/anaconda3/bin/python /opt/miniconda3/bin/python; do
    [[ -x "$task_candidate" ]] || continue
    if "$task_candidate" -c 'import sys,numpy,pyarrow; assert sys.version_info >= (3,10)' >/dev/null 2>&1; then
      task_python="$task_candidate"
      break
    fi
  done
fi
if [[ -z "$task_python" || ! -x "$task_python" ]]; then
  echo 'No Python 3.10+ with NumPy and PyArrow was found.'
  echo 'Run SETUP_HOME_PYTHON.command once, or set COMP_HOME_PYTHON to an existing interpreter.'
  exit 2
fi
task_desktop="${COMP_HOME_DESKTOP:-$HOME/Desktop/Lichess_Desktop}"
mkdir -p "$task_desktop"
task_log="$task_desktop/comparison_home_${task_action}_$(date -u +%Y%m%dT%H%M%SZ)_$$.log"
echo "Log: $task_log"
task_run() {
  "$task_python" -c 'import sys,numpy,pyarrow; print("Python",sys.version.split()[0],"NumPy",numpy.__version__,"PyArrow",pyarrow.__version__)' || return $?
  "$task_python" -u "$task_here/test_transfer.py" --require-io || return $?
  case "$task_action" in
    prepare)
      echo 'Preparing full comparison transfer; estimated 5-20 minutes. No API requests.'
      "$task_python" -u "$task_here/prepare_transfer.py" --project-root "${COMP_HOME_PROJECT_ROOT:-/Volumes/XT_Pro/lichess_kindness}" --desktop "$task_desktop" --workers "${COMP_HOME_WORKERS:-6}" "$@" || return $?
      ;;
    download)
      echo 'Home enrichment: roughly 12-30 hours, depending on API speed. API concurrency is ONE.'
      echo 'Run only one Lichess API retrieval job at a time. Coordinate with any job on the data Mac.'
      "$task_python" -u "$task_here/enrich_home.py" --package "$task_here" --workers "${COMP_HOME_WORKERS:-4}" "$@" || return $?
      ;;
    pack)
      "$task_python" -u "$task_here/return_transfer.py" pack --package "$task_here" --desktop "$task_desktop" --workers "${COMP_HOME_WORKERS:-4}" "$@" || return $?
      ;;
    import)
      "$task_python" -u "$task_here/return_transfer.py" import --project-root "${COMP_HOME_PROJECT_ROOT:-/Volumes/XT_Pro/lichess_kindness}" --workers "${COMP_HOME_WORKERS:-4}" "$@" || return $?
      ;;
    *) echo "Unknown action: $task_action"; return 2 ;;
  esac
}
set +e
task_run "$@" 2>&1 | /usr/bin/tee "$task_log"
task_status=${PIPESTATUS[0]}
set -e
if [[ "$task_status" -ne 0 ]]; then
  echo "Stopped with exit $task_status. Preserve the log: $task_log"
  exit "$task_status"
fi
echo "Finished. Log: $task_log"
