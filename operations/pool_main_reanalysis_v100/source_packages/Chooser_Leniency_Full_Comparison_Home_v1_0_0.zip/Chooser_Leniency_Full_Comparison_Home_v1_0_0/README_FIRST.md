# Full comparison-game API enrichment on the home laptop

Version 1.0.0 — 2026-09-06.

This prepares the **full 1,764,603-game pending comparison list**, within the original **1,912,023-game comparison frame** for November 2023–July 2025. It does not depend on running the 200,000-game pilot. It does not include the separate 5,810,797 Stage07 source gaps for August–October 2025.

## 1. On the Mac with XT_Pro

Put this code ZIP in `~/Desktop/Lichess_Desktop`, verify the published checksum, and extract it. Run:

```bash
/bin/bash PREPARE_TRANSFER.command
```

Run that command inside the extracted code folder, or use its full path. The accompanying ChatGPT command does the extraction and launch for you.

The preparation step:

- Authenticates completed validity run `20260906T052017Z_46893`, its exact frame and source ledger, and the embedded verified report.
- Reproduces 1,912,023 frame rows and 1,764,603 originally pending IDs. It reconciles the existing API-target Parquet when that file is listed in the source receipt.
- Reads the already-extracted metadata Parquets: 189,452 records in 5,877 nonempty files. It does not reopen the 46-GiB raw archive or scan the all-game chronology.
- Reuses compatible, authenticated preliminary-run metadata caches. The outgoing API count can be smaller if some of the original pending games have since been recovered. Source/status/timestamp conflicts do not count as cache hits.
- Copies the **whole original frame and recipient orientation**, the original source ledger, original extracted JSON, normalized cached metadata, pending targets, code, and hash manifests into a self-contained transfer. No Stockfish, rating histories, full chronology, or API credentials are required on the home laptop.
- Makes **zero API requests** on this Mac and does not stop other work.

Outputs are printed on completion:

```text
~/Desktop/Lichess_Desktop/
    CHOOSER_COMPARISON_HOME_INPUT_<transfer_id>_PRIVATE.zip
    CHOOSER_COMPARISON_HOME_INPUT_<transfer_id>_PRIVATE.zip.sha256
```

Transfer **both files** to the home laptop. These contain game/account identifiers; keep them private. You can copy them by external drive or your usual private file transfer. Keep the originals until the return import is verified.

Preparation estimate: **5–20 minutes**, depending on external-drive speed and other jobs. Up to six local metadata workers; one numerical-library thread per worker. Allow roughly 6–8 GiB memory and at least 4 GiB free on the project drive plus 2 GiB on the Desktop drive. These are planning budgets, not measured benchmarks or OS limits. An input transfer should be on the order of tens to hundreds of MB; the script prints the actual output path and checksum.

The source root defaults to `/Volumes/XT_Pro/lichess_kindness`. Override only if needed:

```bash
COMP_HOME_PROJECT_ROOT="/your/project/root" /bin/bash PREPARE_TRANSFER.command
```

Automatic cache reuse covers the authenticated validity-local extracted records and completed preliminary audited-metadata checkpoints. Other recent caches are not guessed from arbitrary directories. A separate normalized cache can be supplied with `--cache-manifest /absolute/path/manifest.json`; its manifest must contain `files` entries with `path`, `bytes`, and `sha256`, and every Parquet must have the normalized metadata fields. Do not point this option at a raw Stage04 cache. The pending comparison window and the ongoing August–October Stage07 source window are disjoint.

## 2. On the home laptop

Put the transferred ZIP and sidecar in `~/Desktop/Lichess_Desktop`. Verify the sidecar from that folder:

```bash
/usr/bin/shasum -a 256 -c CHOOSER_COMPARISON_HOME_INPUT_<transfer_id>_PRIVATE.zip.sha256
```

Replace `<transfer_id>` with the actual printed value. Extract into a **new empty folder** using Finder, or `ditto -x -k ZIP NEW_FOLDER`. Inside that extracted folder run:

```bash
/bin/bash RUN_HOME.command
```

The home laptop needs **Python 3.10+ with NumPy and PyArrow**. The launcher looks for existing Conda/Python installations and a dedicated environment. If none is available, it stops before API requests. Run this once to create the dedicated environment, then retry:

```bash
/bin/bash SETUP_HOME_PYTHON.command
```

That optional setup installs NumPy and PyArrow only into `~/.venvs/lichess-comparison-home`. It requires an existing Python 3.10+. Alternatively set `COMP_HOME_PYTHON` to an existing suitable interpreter. Python environments are not copied between Macs.

Keep the laptop plugged in, connected, and its lid open. The launcher uses `caffeinate`. Its output and log show progress, observed games/second, and the current-pass ETA.

**Download estimate:** roughly **12–30 hours** for 1.765 million IDs. At 30 games/second the estimate is 16.3 hours. Throttling, outages, validation, or a slow connection can extend this. Allow at least **8 GiB free** in the extracted package's drive, including space to create the return ZIP. No external XT_Pro drive is needed at home.

## API behavior and resume

- Official endpoint: `POST https://lichess.org/api/games/export/_ids`.
- Maximum 300 exact, case-sensitive IDs per request; one request at a time; at least one second after each successful request.
- Requests omit moves, clocks arrays, engine annotations, and embedded PGN. Top-level source, terminal status, timestamps, players, pregame ratings, and clock settings are retained. Full returned JSON is saved as gzip NDJSON as well as Parquet.
- HTTP 429 waits at least 60 seconds and honors a longer `Retry-After`. Repeated throttles increase the wait. Transient failures have bounded retries. Cooldown survives restarting the downloader.
- Each successful 300-ID batch has its own checksum manifest, exact requested list, metadata Parquet, raw gzip response, and nonreturn list. A network interruption leaves an uncertified partial folder; it does not advance the checkpoint.
- Up to three passes retry only **IDs not returned**. A returned game with missing/conflicting metadata is retained and flagged; it is not silently accepted or replaced. Entire batches lacking the required explicit source field stop the run for inspection.
- To stop, use Control-C. To resume, run the **same `RUN_HOME.command` in the same extracted folder**. Completed batches are hash-verified and not refetched. Do not extract a fresh copy to resume.
- A local lock prevents two copies of this downloader on the same laptop. It cannot detect unrelated scripts or another computer. Coordinate with other Lichess API retrievals so requests do not overlap; the home laptop is not a mechanism for bypassing throttling.
- No login is needed for public game export. If you already use an authorized `LICHESS_API_TOKEN`, the downloader can read it from the environment. Never put it in the ZIP or a command you share; it is not saved in manifests or logs.

The official [Lichess API tips](https://lichess.org/page/api-tips) require one request at a time and a pause of at least a minute after a 429. The endpoint is listed in the official [API specification](https://github.com/lichess-org/api/blob/master/doc/specs/lichess-api.yaml).

Local hashing can use 1–10 workers with `COMP_HOME_WORKERS`; network concurrency always stays one. All scripts record actual dependency versions in the log. The core metadata normalization is reused from the attached preliminary package, with an explicit extension distinguishing no earlier export from an actual timestamp conflict.

## 3. Return the results

After completion, or after stopping at a convenient checkpoint, run inside the home transfer folder:

```bash
/bin/bash PACK_RETURN.command
```

It verifies the completed batches and writes two archives on the Desktop:

1. `CHOOSER_COMPARISON_HOME_RETURN_..._PRIVATE.zip` and sidecar: **transfer back to the data Mac**, not to chat. It contains the full inputs and completed raw/Parquet batches. Estimated packaging time 5–20 minutes, depending on disk speed and result size.
2. `CHOOSER_COMPARISON_HOME_REPORT_....zip` and sidecar: small aggregate report suitable for upload here. It reports returns, nonreturns, metadata flags, and source/status counts without game/account identifiers.

Back on the data Mac, with XT_Pro mounted, run the included importer from the original code folder:

```bash
/bin/bash IMPORT_RETURN.command "/absolute/path/to/CHOOSER_COMPARISON_HOME_RETURN_..._PRIVATE.zip"
```

Keep the checksum sidecar next to the return ZIP. The importer authenticates the ZIP and all manifests, checks the original frame/ledger hashes against the data Mac, reproduces batch accounting, and extracts into a new directory:

```text
/Volumes/XT_Pro/lichess_kindness/derived/replication/
    comparison_api_home_v100_PRIVATE/<transfer_id>_<archive_hash_prefix>/
```

Rerunning import of the same archive verifies and reuses that directory. It never overwrites the certified validity run, Stage07 panel, A1, or IV pilot. Import estimate: 5–20 minutes. The downloaded metadata still needs to be reconciled with the original caches and attached to the analysis frame before estimating the ordinary-game placebo and active-resolution selection models.

## Scientific accounting

All source categories and terminal statuses remain in the master frame, including `timeout` and `outoftime`. There is no sample replacement, no restriction to future recipients, and no outcome-based sampling. The ordinary-ending eligibility restrictions belong in later analysis, not in this downloader.

`ENRICHMENT_RETRIEVAL_COMPLETE` means every outgoing target returned with the required metadata checks passed. `ENRICHMENT_FINISHED_WITH_GAPS` means request passes finished with nonreturns or flagged metadata. Neither certifies assignment, exclusion, monotonicity, complete historical chat/takeback data, or the numeric-ID-to-username mapping for all newly returned players. Those later reconciliations remain separate.

Missing source is never treated as non-pool; nonreturn is never coded as a normal game or zero disconnect. `lastMoveAt` remains the API anchor, not an observed terminal click. Missing chat/takeback fields do not establish absence of interpersonal interaction. No regression is run by this package.

## Validation and recovery boundaries

The launcher requires all offline tests, including actual Parquet I/O, to pass before opening production inputs. Tests cover preparation and cache reuse, exact-case IDs, reordered ledgers, preserved orientation, corrupted manifests, partial responses, duplicate/unrequested returns, 429 handling, crash/resume, retrying only nonreturns, full-denominator reporting, archive traversal rejection, and private-return/import round trips.

The package was tested on synthetic fixtures; the XT_Pro data and the home laptop are not mounted in the assistant environment. No live bulk API test was performed. Actual dataset/schema/count disagreement stops preparation with a diagnostic; upload that log rather than editing out an integrity check.

A failed preparation preserves its partial output and can be rerun into a fresh transfer directory. Preparation is short and is not checkpoint-resumed. Home downloading is checkpoint-resumed. If metadata flags or nonreturns remain after three passes, send the aggregate report so a targeted repair can be scoped. Do not reset the run to refetch all games.
