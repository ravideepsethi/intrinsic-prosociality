# Source lineage and validation

This is a new code package for exporting the **full** comparison-frame enrichment to a home Mac. The user requested a transfer package for the 1.7–1.8 million pending API games. No private production inputs were available in the assistant environment, and no bulk API requests were made there.

The attached verified validity-local report is the source authority:

- Run: `20260906T052017Z_46893`.
- Report SHA-256: `ff14f791073667bb57324c5c80ca727bcdc2fb72e6d802a9d482386c12de9e7d`.
- Configuration SHA-256: `f472f94e84149d4ee75626b87977a46457bdb41ea69a29e44c82ab33f83cd46b`.
- Original comparison frame: 1,912,023 games.
- Metadata-known subset: 147,420 games.
- Original pending comparison IDs: 1,764,603 games.
- Extracted comparison metadata: 189,452 records in 5,877 nonempty files.

Exact input paths, checkpoint formats, and field names come from the attached `Chooser_Leniency_Preliminary_Placebo_v1_0_0_20260906` code. Its ZIP checksum was `1c8f10fd2e7daa480f1ae27147769f772c1abc06c7b431c5388ef182bdb80340`.

Two source files are retained unchanged from that attachment:

- `preliminary_core.py`: `468d1b1f603aee97799f90a187bdd81552f5fbf6752b196115f41357a39a911b`.
- `iv_numerics.py`: `ef709b4ff6b37e410ecb4ad549f5bfdc0b798a4627dcfdd6cc4a757f982d2066`.

They supply the established metadata parsing and validation logic. No score or regression is estimated by this package. New `transfer_common.validate_record` explicitly distinguishes absent earlier metadata from unresolved earlier evidence, and requires the core metadata fields for non-pool exports as well as pool exports.

The new preparation, downloading, packing, and importing code has synthetic tests with actual PyArrow Parquet I/O. These include a preparation fixture with a newly cached pending game, a full three-pass mocked-HTTP run followed by a second launch that makes no new requests, a broken-response restart, and a return ZIP/import round trip. All 21 tests passed with no skips. Python and Bash syntax checks passed. Runtime details are recorded in `VALIDATION.json`; the launchers also rerun the offline tests locally before production use.

The downloader's endpoint and 300-ID batch size agree with the project's supplied API-enrichment contract. The endpoint's continued presence was checked in the official Lichess API specification, and the current one-request-at-a-time and 429 waiting guidance was checked at https://lichess.org/page/api-tips on 2026-09-06. No live export response was available to certify the current schema; the first-batch source/schema guard stops if exports lack explicit source.

The private import is a verified acquisition result, not a replacement for the certified comparison ledger. It preserves raw responses and typed metadata so subsequent analysis can reconcile identities, conflicts, nonreturns, and original caches without changing the sampled denominator.
