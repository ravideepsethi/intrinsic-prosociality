# Kindness Reference-Demand Closure v1.0.4

This authenticated, append-only package closes the remaining high-value checks
around **zero chooser rating payoff**. It is separate from the already
certified Equality/FEN Audit, which studied zero engine evaluation.

The package does four things:

1. separates costly, literal exact-zero, and strictly favorable draws in five
   symmetric payoff windows;
2. reconstructs and reports every displayed integer rating gap from -30 to
   +30 (plus tails), with exact pairwise adjusted comparisons to `g=-1`;
3. estimates the prospectively frozen E1-E5 sign/scale/expected-score-distance
   and rating-deviation decomposition; and
4. reproduces the certified Stage 08 and v1.0.3 reference-demand results before
   allowing any new interpretation.

The detailed prospective definitions are in
`docs/REFERENCE_DEMAND_AMENDMENT_v1_0_4.md`. In particular, exact-zero rows are
never assigned an arbitrary logarithmic floor, and sign is omitted from E3 and
E4 because exact displayed-gap fixed effects absorb it.

## Safety and provenance

- Reads the immutable private v1.0.2 model cache only after full authentication.
- Writes checkpoints only under a new v1.0.4 private run root.
- Produces aggregate CSV/JSON/Markdown only.
- Performs no API call, PGN download, dependency installation, Git mutation,
  certified-input write, or row-level transfer.
- Uses exactly 8 workers and the frozen 16 GB numerical memory ceiling.
- Runs component tests, a complete synthetic end-to-end execution, an
  independent aggregate verifier, and a final package-source recheck.
- Is resumable by rerunning the same outer terminal block.

## Runtime and output

Expected runtime is approximately 45-120 minutes, most likely 60-90 minutes.
The 120 pairwise displayed-gap models are intentionally memory-bounded and
checkpointed individually.

Production aggregates are written below:

```text
/Volumes/XT_Pro/lichess_kindness/output/KINDNESS_REFERENCE_DEMAND_CLOSURE_V104
```

Private resumable checkpoints are written below:

```text
/Volumes/XT_Pro/lichess_kindness/derived/private/KINDNESS_REFERENCE_DEMAND_CLOSURE_V104
```

The authenticated result ZIP and `.sha256` sidecar are written to:

```text
/Users/u6025368/Desktop/Lichess_Desktop
```

Interpretation remains exploratory and associational. The package cannot
identify structural loss aversion, a causal discontinuity, or a uniquely
causal zero kink because rating-payoff sign and relative displayed rating are
mechanically linked in this authority.
