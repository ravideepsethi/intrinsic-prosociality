#!/usr/bin/env python3
"""Create an end-to-end synthetic private model cache for v1.0.4."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import kindness_price_elasticity_common_v102 as numerical
import reference_demand_v104_common as audit
import run_kindness_price_elasticity_v102 as legacy


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--rows", type=int, default=48_000)
    parser.add_argument("--self-test", action="store_true")
    return parser.parse_args()


def build(root: Path, rows: int) -> dict[str, object]:
    _, np, pa, pq = numerical.import_dependencies()
    if rows < 24_000 or rows % 1_200 != 0:
        raise RuntimeError("Synthetic rows must be at least 24,000 and divisible by 1,200")
    rng = np.random.default_rng(20260827)
    row = np.arange(rows, dtype=np.int64)
    chooser = row % 1_200
    observation = row // 1_200
    gap = ((observation + 7 * chooser) % 61) - 30
    chooser_elo = (1_200 + chooser % 1_000 + (observation % 3)).astype(np.int64)
    opponent_elo = chooser_elo + gap
    chooser_rd = 45.0 + ((11 * observation + 3 * chooser) % 115)
    opponent_rd = 45.0 + ((17 * observation + 5 * chooser) % 115)
    price = 3.0 + ((13 * observation + 7 * chooser) % 100) / 8.0
    scale = 2.0 * price
    magnitude = np.clip(
        0.006 + np.abs(gap) / 110.0 + (opponent_rd % 13.0) / 2_000.0,
        0.006,
        0.45,
    )
    draw = np.sign(gap).astype(np.float64) * scale * magnitude
    engine = ((19 * observation + 23 * chooser) % 601 - 300).astype(np.float64)
    month = ((observation + chooser // 47) % 24).astype(np.int64)
    speed = ((observation // 2 + chooser // 71) % 5).astype(np.int64)
    price_bin20 = ((5 * observation + chooser) % 20).astype(np.int64)
    draw_bin20 = np.floor((gap + 30) * 20 / 61).astype(np.int64)
    draw_bin50 = np.floor((gap + 30) * 50 / 61).astype(np.int64)
    log_chooser_clock = np.log1p(1.0 + ((31 * observation + chooser) % 400)).astype(np.float64)
    log_opponent_clock = np.log1p(1.0 + ((37 * observation + 3 * chooser) % 500)).astype(np.float64)
    log_chooser_clock[(row % 97) == 0] = np.nan
    log_opponent_clock[(row % 89) == 0] = np.nan
    nonzero = gap != 0
    log_m = np.zeros(rows, dtype=np.float64)
    log_m[nonzero] = np.log(magnitude[nonzero])
    probability = (
        0.035
        + 0.005 * (draw > 0)
        + 0.003 * (draw == 0)
        - 0.0012 * np.log(scale)
        - 0.0008 * log_m
        + 0.000002 * engine
        + ((chooser % 17) - 8) * 0.00025
    )
    kind = rng.random(rows) < np.clip(probability, 0.004, 0.25)
    fields = {
        "row_id": row,
        "chooser_index": chooser.astype(np.int64),
        "kind": kind.astype(np.bool_),
        "price": price.astype(np.float64),
        "log_price": np.log(price).astype(np.float64),
        "draw_payoff": draw.astype(np.float64),
        "engine_eval_cp": engine,
        "chooser_elo": chooser_elo,
        "opponent_elo": opponent_elo.astype(np.int64),
        "chooser_rd": chooser_rd.astype(np.float64),
        "opponent_rd": opponent_rd.astype(np.float64),
        "log_chooser_clock": log_chooser_clock,
        "log_opponent_clock": log_opponent_clock,
        "tournament": ((3 * observation + chooser) % 11 == 0),
        "month_code": month,
        "speed_code": speed,
        "rating_band": np.minimum(3, chooser_elo // 500).astype(np.int64),
        "eval_band": np.digitize(engine, [-100.0, 0.0, 100.0, 300.0]).astype(np.int64),
        "hour_of_week": ((7 * observation + chooser) % 168).astype(np.int64),
        "both_rd_le_110": ((chooser_rd <= 110) & (opponent_rd <= 110)),
        "activity_quartile": ((observation + chooser) % 4).astype(np.int64),
        "prior_kind_stratum": ((observation + chooser // 13) % 3).astype(np.int64),
        "price_bin20": price_bin20,
        "draw_bin20": draw_bin20,
        "draw_bin50": draw_bin50,
        "row_hash": (row * 1_000_003 + 20260827).astype(np.int64),
    }
    if tuple(fields) != legacy.MODEL_COLUMNS:
        raise RuntimeError(f"Synthetic model-cache schema order changed: {tuple(fields)}")
    table = pa.table(fields)
    root.mkdir(parents=True, exist_ok=True)
    destination = root / "fair_price_model_private.parquet"
    temporary = root / ".fair_price_model_private.parquet.tmp"
    pq.write_table(table, temporary, compression="zstd", compression_level=9)
    temporary.replace(destination)
    receipt: dict[str, object] = {
        "status": "REFERENCE_DEMAND_V104_SYNTHETIC_CACHE_OK",
        "created_utc": audit.utc_now(),
        "rows": rows,
        "kind_draws": int(kind.sum()),
        "choosers": int(np.unique(chooser).size),
        "exact_zero_rows": int(np.count_nonzero(draw == 0.0)),
        "strict_negative_rows": int(np.count_nonzero(draw < 0)),
        "strict_positive_rows": int(np.count_nonzero(draw > 0)),
        "output": str(destination),
        "output_bytes": destination.stat().st_size,
        "output_sha256": audit.sha256_file(destination),
        "privacy": "entirely synthetic; no physical account or game data",
    }
    audit.atomic_json(root / "synthetic_cache_receipt.json", receipt)
    print("KINDNESS_REFERENCE_DEMAND_V104_SYNTHETIC_CACHE_OK", flush=True)
    print(f"Rows: {rows:,}", flush=True)
    print(f"Kind draws: {int(kind.sum()):,}", flush=True)
    return receipt


def self_test() -> None:
    import numpy as np  # type: ignore
    gap = np.arange(-30, 31)
    price = 5.0 + (gap + 30) / 20.0
    magnitude = 0.01 + np.abs(gap) / 100.0
    draw = np.sign(gap) * (2.0 * price) * magnitude
    if not np.all((draw == 0) == (gap == 0)):
        raise RuntimeError("Synthetic-fixture zero policy self-test failed")
    if np.max(np.abs(np.log(np.abs(draw[gap != 0])) - np.log(2.0 * price[gap != 0]) - np.log(magnitude[gap != 0]))) > 1e-12:
        raise RuntimeError("Synthetic-fixture algebra self-test failed")
    print("KINDNESS_REFERENCE_DEMAND_V104_SYNTHETIC_FIXTURE_SELFTEST_OK", flush=True)


def main() -> int:
    args = parse_args()
    if args.self_test:
        self_test()
        return 0
    build(args.root.resolve(), args.rows)
    return 0


if __name__ == "__main__":
    sys.exit(main())

