#!/usr/bin/env python3
"""Verify exact package inventory, hashes, and cleanliness."""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

import reference_demand_v104_common as audit


EXPECTED_FILES = {
    "README.md",
    "RUN_KINDNESS_REFERENCE_DEMAND_CLOSURE_V104.command",
    "requirements.txt",
    "code/00_run_reference_demand_v104.py",
    "code/01_verify_reference_demand_v104.py",
    "code/02_make_synthetic_fixture.py",
    "code/03_package_results.py",
    "code/99_verify_package_contents.py",
    "code/reference_demand_v104_common.py",
    "code/kindness_price_elasticity_common_v102.py",
    "code/run_kindness_price_elasticity_v102.py",
    "code/run_kindness_reference_demand_v103.py",
    "docs/REFERENCE_DEMAND_AMENDMENT_v1_0_4.md",
    "frozen_authorities/reference_demand_v104_contract.json",
    "frozen_authorities/v103/_SUCCESS.json",
    "frozen_authorities/v103/primary_interpretation.json",
    "frozen_authorities/v103/stage08_replication_audit.json",
    "frozen_authorities/v103/report_file_hashes.tsv",
    "frozen_authorities/v103/kindness_reference_demand_exploratory_plan_v1_0_3_2026-08-25.md",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--package-root", type=Path, required=True)
    parser.add_argument("--self-test", action="store_true")
    return parser.parse_args()


def verify(root: Path) -> dict[str, object]:
    actual = {
        str(path.relative_to(root)) for path in root.rglob("*")
        if path.is_file() and path.name != "PACKAGE_MANIFEST.sha256"
        and "__pycache__" not in path.parts and path.suffix != ".pyc"
    }
    if actual != EXPECTED_FILES:
        raise RuntimeError(f"Exact package inventory changed; missing={sorted(EXPECTED_FILES-actual)}; extra={sorted(actual-EXPECTED_FILES)}")
    debris = [path for path in root.rglob("*") if path.name in {".DS_Store", "__pycache__"} or path.suffix in {".pyc", ".pyo"}]
    if debris:
        raise RuntimeError(f"Generated debris is present: {debris}")
    receipt = audit.verify_package_manifest(root)
    launcher = (root / "RUN_KINDNESS_REFERENCE_DEMAND_CLOSURE_V104.command").read_text(encoding="utf-8")
    for pattern in (
        r"\bpip\s+install\b", r"\bconda\s+install\b",
        r"\bgit\s+(add|commit|push|pull|reset|checkout)\b",
        r"lichess\.org/api", r"database\.lichess\.org",
    ):
        if re.search(pattern, launcher, re.IGNORECASE):
            raise RuntimeError(f"Launcher contains prohibited operation: {pattern}")
    forbidden_types = {".parquet", ".pgn", ".zst", ".duckdb", ".db", ".jsonl", ".ndjson"}
    bad = [str(path) for path in root.rglob("*") if path.is_file() and path.suffix.lower() in forbidden_types]
    if bad:
        raise RuntimeError(f"Package contains forbidden row-level/private files: {bad}")
    print("PACKAGE_EXACT_INVENTORY_AND_HASHES_OK", flush=True)
    print(f"Files: {receipt['files']}", flush=True)
    return {"status": "PACKAGE_EXACT_INVENTORY_AND_HASHES_OK", "files": receipt["files"]}


def main() -> int:
    args = parse_args()
    if args.self_test:
        if len(EXPECTED_FILES) != 19:
            raise RuntimeError("Expected package inventory self-test changed")
        print("KINDNESS_REFERENCE_DEMAND_V104_PACKAGE_VERIFIER_SELFTEST_OK")
        return 0
    verify(args.package_root.resolve())
    return 0


if __name__ == "__main__":
    sys.exit(main())

