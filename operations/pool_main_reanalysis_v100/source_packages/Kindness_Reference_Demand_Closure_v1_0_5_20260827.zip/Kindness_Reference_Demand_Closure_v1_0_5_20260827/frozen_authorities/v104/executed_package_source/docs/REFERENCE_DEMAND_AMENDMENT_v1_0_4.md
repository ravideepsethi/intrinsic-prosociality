# Kindness reference-demand closure amendment v1.0.4

**Frozen:** 2026-08-27, after certification of the Equality/FEN Audit v1.0.1
and before executing any v1.0.4 model on physical data.

**Status:** secondary/exploratory closure of the already published v1.0.3
reference-demand lineage. This is not a new unrestricted specification search.

## 1. Scope and authority

This package addresses the zero of `chooser_draw_payoff_v2`, the rating
consequence of granting a draw relative to the chooser's pre-game rating. It
does not address zero engine evaluation, which is covered by the separate
Equality/FEN Audit v1.0.1.

The package must first authenticate:

1. the certified 24-month Stage 07 authority;
2. the immutable v1.0.2 private model cache reused by v1.0.3;
3. the published v1.0.3 aggregate authority; and
4. exact numerical reproductions of the certified Stage 08 piecewise model and
   the three v1.0.3 primary companion models.

The terse prior execution memo referred to a standalone file named
`reference_price_demand_schedule_spec_v1_0_0.md`. That standalone file was not
present in the inspected public repository, attached source set, or Library
inventory. The named requirements preserved in the execution memos were:
exact-zero separation, a displayed integer-gap schedule, separate `log K` and
`log|0.5-E|` terms, a K-driven slope within gap bins, own- versus opponent-RD
components, and own/opponent/both-RD support restrictions. This amendment
states the complete operational definitions prospectively, before physical
v1.0.4 outcomes are read.

## 2. Population, outcome, and uncertainty

- Population: all 17,328,130 certified Stage 07 fair-state opportunities,
  November 2023 through October 2025.
- Outcome: `kind`, an indicator for a kind draw.
- Chooser fixed effect and cluster: the lossless `chooser_index` already frozen
  in the authenticated private cache.
- All reported uncertainty is chooser-clustered.
- All new estimates carry epistemic label `X` and remain outside the Campaign 1
  Holm family.

## 3. Algebraic objects

Let:

- `D = chooser_draw_payoff_v2`;
- `P = chooser_win_premium_v2`;
- `K = 2P`;
- `M = |0.5-E| = |D|/K` for `D != 0`; and
- `g = opponent_elo - chooser_elo`, the displayed integer rating gap from the
  chooser's perspective.

The single-game Glicko update is affine in score, so the win-versus-draw
premium is one half of the score-step scale. The package must verify, before
estimation, that `P > 0`, `K > 0`, `0 < M < 0.5` for every nonzero row, and

```text
log|D| = log K + log M
```

to numerical tolerance. This is a decomposition identity, not an identifying
assumption.

## 4. Exact-zero policy

Production exact zero is the literal stored value `D == 0.0`. The package must
also verify that applying tolerance `|D| <= 1e-12` yields the same 244,300 rows.

Every boundary table and zero-window model separates:

1. costly: `D < 0`;
2. exact zero: `D == 0`; and
3. strictly favorable: `D > 0`.

For each symmetric window `|D| <= w`, with `w` in `{0.5,1,2,4,6}`, two
equivalent parameterizations are estimated with chooser and premium-20-bin
fixed effects:

- negative omitted: exact-zero and strictly-positive indicators;
- exact-zero omitted: negative and strictly-positive indicators.

These directly report exact-minus-negative, positive-minus-negative, and
positive-minus-exact contrasts with clustered standard errors. Exact-zero rows
are excluded from logarithmic magnitude models because `log M` and `log|D|`
are undefined at zero; they are not assigned an arbitrary floor or offset.

The first favorable boundary display uses the three mutually exclusive bins
`[-0.1,0)`, `{0}`, and `(0,0.1]`.

## 5. Displayed integer-gap schedule

The displayed gap is reconstructed as `g = opponent_elo - chooser_elo` after
requiring both ratings and their difference to be exact integers. The package
reports raw rows, kind draws, rates, and standard errors for every integer
`g` from -30 through +30, plus two tail categories.

The primary adjusted schedule uses `g=-1` as the reference. To keep the
17.3-million-row computation inside the frozen 16 GB memory ceiling, every
integer gap from -30 through +30 (except -1) is estimated in its own exact
two-category comparison against `g=-1`. Each comparison uses only those two
gap categories and includes:

- chooser and month fixed effects;
- linear and quadratic engine evaluation;
- standardized chooser and opponent clock controls and missingness flags;
- tournament status; and
- speed indicators.

A single declared sensitivity repeats every comparison after adding `log K`.
The resulting coefficients are pair-specific conditional contrasts rather
than coefficients from one joint 61-category regression. This implementation
is prospectively fixed because a joint dense design would require more than
the canonical memory allowance. These are descriptive conditional gap
schedules, not causal rating-gap effects. The package reports sign alignment
between `g` and `D`, exact-gap heaping, and support by gap.

## 6. Frozen E1-E5 sign-versus-magnitude family

All E models exclude exact-zero rows, use chooser and month fixed effects,
cluster by chooser, and include the common current-state controls listed in
Section 5. Neither `D`, `P`, nor a premium-bin fixed effect is included as a
control when `log K` is itself an estimand.

### E1: sign plus total magnitude

```text
kind = chooser FE + month FE + tau 1[D>0] + beta_D log|D|
       + current-state controls + error
```

This separates a sign association from the overall magnitude of the signed
draw payoff but does not decompose that magnitude.

### E2: scale versus expected-score distance

```text
kind = chooser FE + month FE + tau 1[D>0]
       + beta_K log K + beta_M log|0.5-E|
       + current-state controls + error
```

Because `log|D| = log K + log|0.5-E|`, `beta_K` and `beta_M` distinguish the
two observed sources of payoff magnitude. They do not identify structural
mechanisms.

### E3: K-driven variation within displayed gap

E2 is repeated on `|g| <= 30` while absorbing exact displayed-integer-gap
fixed effects in addition to chooser fixed effects. Speed enters as indicator
controls, while month enters as the established standardized linear and
quadratic trends used by the v1.0.2 adjusted-control lineage. This avoids a
large dense month-dummy matrix while retaining the frozen 16 GB execution
boundary. The sign indicator is necessarily omitted because it is an exact
function of the absorbed displayed gap. The
coefficient on `log K` is then identified only from K variation within the
same displayed gap and chooser support.

### E4: own- versus opponent-uncertainty components

On the E3 sample and fixed-effect structure, `log K` is replaced by
`log(chooser_rd)` and `log(opponent_rd)`, while retaining
`log|0.5-E|` and current-state controls. Sign remains absorbed by exact gap.
This is a descriptive
component association. It does not claim that either RD is exogenous or that
the two coefficients sum to the E3 K coefficient.

### E5: rating-certainty restrictions

E2 is repeated on three prospectively named nonzero-row samples:

- E5a: chooser RD <= 110;
- E5b: opponent RD <= 110; and
- E5c: both chooser and opponent RD <= 110.

No E1-E5 specification is elevated or selected after seeing results. The
family is interpreted jointly.

## 7. Replication gates

Before writing any new interpretation, the package must reproduce within
`5e-10` percentage points:

- Stage 08 full-range piecewise slopes and nonnegative term;
- v1.0.3 primary premium-bin piecewise slopes and nonnegative term;
- v1.0.3 primary `|D| <= 0.5` nonnegative contrast; and
- v1.0.3 primary loss-side log-magnitude coefficient and mean-scaled
  elasticity.

Any failed replication stops interpretation and final certification.

## 8. Permitted and prohibited interpretation

Permitted language:

- reduced-form reference-dependent schedule;
- association with crossing from a costly to a nonnegative or strictly
  favorable draw;
- distinct descriptive contributions of K and expected-score distance;
- stronger or weaker local loss-side response in named windows; and
- robustness or non-robustness to displayed-gap and RD restrictions.

Prohibited language:

- structural loss aversion;
- causal regression discontinuity;
- causal price or demand elasticity;
- proof that rating consequences rather than relational comparison cause the
  response; or
- proof of a unique zero kink.

Before the November 2025 color-advantage change, payoff sign and visible
relative rating remain mechanically linked. This package can sharpen the
within-sample decomposition but cannot break that observational equivalence.

## 9. Privacy and mutation boundary

The package may read the authenticated private cache but never modifies it.
All checkpoints go to a new v1.0.4 private root. Public output is aggregate
CSV/JSON/Markdown only. No usernames, game IDs, account identifiers, row-level
Parquets, private caches, logs containing row values, API calls, PGN downloads,
dependency installations, Git mutations, or certified-input writes are
permitted.
