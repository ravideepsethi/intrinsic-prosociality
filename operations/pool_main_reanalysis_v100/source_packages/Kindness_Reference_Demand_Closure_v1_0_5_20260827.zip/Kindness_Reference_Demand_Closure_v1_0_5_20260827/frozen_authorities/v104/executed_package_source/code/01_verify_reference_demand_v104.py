#!/usr/bin/env python3
"""Independently verify v1.0.4 aggregates and finalize certification."""

from __future__ import annotations

import argparse
import csv
import math
import sys
import tempfile
from pathlib import Path
from typing import Any

import reference_demand_v104_common as audit


REQUIRED_FILES = (
    "analysis_complete.json",
    "interpretation.json",
    "receipts/input_authorities.json",
    "receipts/private_cache_authentication.json",
    "receipts/input_no_mutation.json",
    "receipts/replication_gates.json",
    "tables/exact_zero_boundary_rates.csv",
    "tables/exact_zero_contrasts.csv",
    "tables/displayed_integer_gap_raw_schedule.csv",
    "tables/displayed_integer_gap_adjusted_schedule.csv",
    "tables/decomposition_models.csv",
    "tables/all_model_terms.csv",
    "tables/model_attempts.csv",
    "tables/model_results.json",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--package-root", type=Path, required=True)
    parser.add_argument("--public-root", type=Path, required=True)
    parser.add_argument("--synthetic", action="store_true")
    parser.add_argument("--self-test", action="store_true")
    return parser.parse_args()


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as stream:
        return list(csv.DictReader(stream))


def finite_number(value: str, label: str) -> float:
    result = float(value)
    if not math.isfinite(result):
        raise RuntimeError(f"Nonfinite aggregate estimate: {label}")
    return result


def verify(args: argparse.Namespace) -> dict[str, Any]:
    package_root = args.package_root.resolve()
    root = args.public_root.resolve()
    contract = audit.load_contract(package_root)
    audit.verify_package_manifest(package_root)
    for relative in REQUIRED_FILES:
        if not (root / relative).is_file():
            raise RuntimeError(f"Required aggregate result is missing: {relative}")
    analysis = audit.load_json(root / "analysis_complete.json")
    interpretation = audit.load_json(root / "interpretation.json")
    replication = audit.load_json(root / "receipts/replication_gates.json")
    cache = audit.load_json(root / "receipts/private_cache_authentication.json")
    no_mutation = audit.load_json(root / "receipts/input_no_mutation.json")
    if analysis.get("status") != audit.ANALYSIS_STATUS or bool(analysis.get("synthetic")) != bool(args.synthetic):
        raise RuntimeError("Analysis-stage status changed")
    if interpretation.get("status") != "REFERENCE_DEMAND_V104_INTERPRETATION_COMPLETE":
        raise RuntimeError("Interpretation status changed")
    if replication.get("status") != "REFERENCE_DEMAND_V104_REPLICATION_GATES_OK":
        raise RuntimeError("Replication gate is absent or failed")
    if no_mutation.get("status") != "AUTHENTICATED_INPUT_UNCHANGED_AFTER_ANALYSIS":
        raise RuntimeError("No-mutation receipt is absent or failed")
    support = cache["support"]
    if not args.synthetic:
        expected = contract["private_cache"]
        for field in ("rows", "kind_draws", "choosers", "exact_zero_rows"):
            if int(support[field]) != int(expected[field]):
                raise RuntimeError(f"Frozen support changed: {field}")
        if replication.get("differences") is None or any(abs(float(value)) > float(contract["replication_tolerance_pp"]) for value in replication["differences"].values()):
            raise RuntimeError("A production replication difference exceeds tolerance")
    if support.get("literal_equals_tolerance_zero") is not True:
        raise RuntimeError("Exact-zero definitions do not coincide")
    if support.get("payoff_sign_matches_displayed_gap_rows") != support.get("rows"):
        raise RuntimeError("Payoff sign and displayed gap are not fully aligned")
    if float(support["log_identity_maximum_absolute_error"]) > 5e-12:
        raise RuntimeError("K/M decomposition identity exceeds tolerance")

    boundary = read_csv(root / "tables/exact_zero_boundary_rates.csv")
    if {row["boundary_bin"] for row in boundary} != {"costly_m0p1_to_0", "exact_zero", "favorable_0_to_0p1"}:
        raise RuntimeError("Three-bin exact-zero boundary display changed")
    exact_row = next(row for row in boundary if row["boundary_bin"] == "exact_zero")
    if int(exact_row["rows"]) != int(support["exact_zero_rows"]):
        raise RuntimeError("Boundary table exact-zero rows do not conserve")
    zero = read_csv(root / "tables/exact_zero_contrasts.csv")
    if {float(row["window_abs_draw_payoff_le"]) for row in zero} != {float(value) for value in contract["zero_windows"]}:
        raise RuntimeError("Exact-zero window grid changed")
    for row in zero:
        if int(row["negative_rows"]) + int(row["exact_zero_rows"]) + int(row["positive_rows"]) != int(row["rows"]):
            raise RuntimeError("Tri-state zero-window counts do not conserve")
        for name in ("exact_minus_negative_pp", "positive_minus_negative_pp", "positive_minus_exact_pp"):
            finite_number(row[name], name)

    raw_gap = read_csv(root / "tables/displayed_integer_gap_raw_schedule.csv")
    expected_labels = {"gap_lt_m30", "gap_gt_30"} | {str(value) for value in range(-30, 31)}
    if {row["displayed_gap"] for row in raw_gap} != expected_labels:
        raise RuntimeError("Raw displayed-gap schedule changed")
    if sum(int(row["rows"]) for row in raw_gap) != int(support["rows"]):
        raise RuntimeError("Raw displayed-gap rows do not conserve")
    if sum(int(row["kind_draws"]) for row in raw_gap) != int(support["kind_draws"]):
        raise RuntimeError("Raw displayed-gap outcomes do not conserve")
    adjusted = read_csv(root / "tables/displayed_integer_gap_adjusted_schedule.csv")
    if len(adjusted) != 122:
        raise RuntimeError(f"Adjusted gap schedule row count changed: {len(adjusted)}")
    if {row["variant"] for row in adjusted} != {"primary", "plus_log_K_sensitivity"}:
        raise RuntimeError("Adjusted gap schedule variants changed")
    for variant in ("primary", "plus_log_K_sensitivity"):
        rows = [row for row in adjusted if row["variant"] == variant]
        if {int(row["displayed_gap"]) for row in rows} != set(range(-30, 31)):
            raise RuntimeError(f"Adjusted gap support changed: {variant}")
        for row in rows:
            if int(row["displayed_gap"]) == int(contract["displayed_gap_reference"]):
                continue
            if int(row["target_rows"]) + int(row["reference_rows"]) != int(row["rows"]):
                raise RuntimeError("Pairwise displayed-gap rows do not conserve")
            if int(row["identifying_choosers_with_both_gaps"]) < 100:
                raise RuntimeError("Pairwise displayed-gap comparison has fewer than 100 identifying choosers")

    models = read_csv(root / "tables/decomposition_models.csv")
    required_models = {
        "E1_sign_plus_log_abs_draw",
        "E2_sign_logK_logM",
        "E3_logK_logM_within_exact_gap",
        "E4_own_opponent_RD_within_exact_gap",
        "E5a_chooser_rd_le_110",
        "E5b_opponent_rd_le_110",
        "E5c_both_rd_le_110",
    }
    if not required_models <= {row["model"] for row in models}:
        raise RuntimeError("E1-E5 decomposition family is incomplete")
    if any(float(row["absorption_max_scaled_group_mean"]) > 1.01e-9 for row in models):
        raise RuntimeError("Decomposition fixed-effect orthogonality exceeds tolerance")
    attempts = read_csv(root / "tables/model_attempts.csv")
    if len(attempts) != 141 or any(row["status"] != "ESTIMATED" for row in attempts):
        raise RuntimeError(f"Required model-attempt inventory changed: {len(attempts)}")
    if int(analysis["required_models"]) != len(attempts):
        raise RuntimeError("Analysis model count disagrees with attempt inventory")
    if interpretation.get("claim_boundary", "").lower().find("no causal") < 0:
        raise RuntimeError("Interpretation claim boundary is missing")
    if analysis.get("causal_claims_authorized") is not False or analysis.get("structural_loss_aversion_claim_authorized") is not False:
        raise RuntimeError("Analysis improperly authorizes causal or structural claims")

    privacy = audit.privacy_scan_public_output(root)
    verification = {
        "status": audit.VERIFY_STATUS,
        "verified_at_utc": audit.utc_now(),
        "synthetic": bool(args.synthetic),
        "required_files": len(REQUIRED_FILES),
        "required_models": len(attempts),
        "exact_zero_rows": int(support["exact_zero_rows"]),
        "zero_windows": len(zero),
        "displayed_gap_raw_categories": len(raw_gap),
        "displayed_gap_adjusted_rows": len(adjusted),
        "replication_gate_required": not args.synthetic,
        "replication_gate_ok": True,
        "input_no_mutation": True,
        "privacy": privacy,
        "causal_claims_authorized": False,
        "structural_loss_aversion_claim_authorized": False,
    }
    audit.atomic_json(root / "independent_verification.json", verification)
    success = {
        "status": audit.PUBLIC_STATUS,
        "certified_at_utc": audit.utc_now(),
        "synthetic": bool(args.synthetic),
        "support": support,
        "replication": replication,
        "primary_exact_zero_window_0p5": interpretation["exact_zero_primary_window_0p5"],
        "E2": interpretation["E2"],
        "E3_within_gap": interpretation["E3_within_gap"],
        "E4_RD_components": interpretation["E4_RD_components"],
        "required_models": len(attempts),
        "independent_verification": audit.VERIFY_STATUS,
        "input_no_mutation": True,
        "aggregate_only": True,
        "causal_claims_authorized": False,
        "structural_loss_aversion_claim_authorized": False,
    }
    audit.atomic_json(root / "_SUCCESS.json", success)
    audit.privacy_scan_public_output(root)
    audit.write_report_manifest(root)
    print("KINDNESS_REFERENCE_DEMAND_CLOSURE_V104_INDEPENDENTLY_VERIFIED_OK", flush=True)
    print(f"Files authenticated: {len(audit.report_rows(root))}", flush=True)
    return verification


def self_test() -> None:
    with tempfile.TemporaryDirectory(prefix="reference_demand_v104_verifier_") as temp:
        root = Path(temp)
        rows = [
            {"displayed_gap": str(value), "rows": 10, "kind_draws": value % 2}
            for value in range(-30, 31)
        ]
        audit.write_csv(root / "sample.csv", rows)
        loaded = read_csv(root / "sample.csv")
        if len(loaded) != 61 or sum(int(row["rows"]) for row in loaded) != 610:
            raise RuntimeError("Verifier conservation self-test failed")
    print("KINDNESS_REFERENCE_DEMAND_V104_VERIFIER_SELFTEST_OK", flush=True)


def main() -> int:
    args = parse_args()
    if args.self_test:
        self_test()
        return 0
    verify(args)
    return 0


if __name__ == "__main__":
    sys.exit(main())
