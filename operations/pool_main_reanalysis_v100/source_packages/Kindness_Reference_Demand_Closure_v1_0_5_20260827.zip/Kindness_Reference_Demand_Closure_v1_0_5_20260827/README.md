# Kindness Reference-Demand Closure v1.0.5

This is the append-only game-stage closure of the certified v1.0.4
reference-demand audit.

The package never rewrites v1.0.4. It builds a new private fair-state cache
that attaches certified Stage 07 `ply_count`, reproduces all 141 v1.0.4 models
from that augmented cache, and then estimates 194 prospectively enumerated
ply-adjusted and long-game models.

## Scientific scope

The package tests whether the signed rating-payoff schedule, exact-zero
contrasts, local slopes, displayed-gap schedule, and E1-E5 decomposition survive
explicit game-stage adjustment and restriction to games with more than ten
plies. It also reports post-v1.0.4 side-specific `K` versus expected-score
distance decompositions.

All estimates are exploratory reduced-form associations. The design does not
identify causal price effects, structural loss aversion, a unique zero kink, or
a causal effect of game length. Before November 2025, payoff sign remains an
exact function of displayed relative rating.

The complete frozen specification is in
`docs/REFERENCE_DEMAND_STAGE_AMENDMENT_v1_0_5.md`.

## Authenticated inputs

- certified Stage 07, 24 months and 47,587,020 rows;
- immutable v1.0.2 fair-state private cache, 17,328,130 rows;
- complete certified v1.0.4 aggregate transfer authority;
- canonical numerical environment:
  DuckDB 1.5.2, NumPy 2.4.4, Pandas 3.0.3, PyArrow 24.0.0.

## New private cache

The builder reconstructs the exact v1.0.2 row order from the physical chooser
key, decision timestamp, archive ordinal, and game ID. Before attaching ply it
requires row-by-row equality with the immutable cache on chooser index,
chooser sequence, month, premium, draw payoff, engine evaluation, and both
ratings. All certified inputs remain read-only.

Private outputs are written only under:

`/Volumes/XT_Pro/lichess_kindness/derived/private/KINDNESS_REFERENCE_DEMAND_CLOSURE_V105`

## Model inventory

- 141 exact v1.0.4 replications;
- 20 stage-adjusted exact-zero models;
- 10 stage-adjusted local-piecewise models;
- 14 stage-adjusted E1-E5 models;
- 4 side-specific `K`/distance models;
- 4 side-specific total-magnitude models;
- 120 full displayed-gap models;
- 20 long-game near-zero displayed-gap models; and
- 2 joint adjacent-gap models.

Total: 335 required, checkpointed models.

## Execution

Run only `RUN_KINDNESS_REFERENCE_DEMAND_CLOSURE_V105.command` through the
authenticated outer launcher supplied with the package. The launcher uses
eight DuckDB workers, the unchanged canonical environment, and macOS
`caffeinate` from the outer shell.

Expected production runtime is approximately 60-150 minutes, most likely
75-110 minutes. Rerunning the exact launcher resumes authenticated model
checkpoints and reuses the authenticated augmented cache.

## Mutation and privacy boundary

The package performs no API call, PGN download, dependency installation, Git
operation, or write to a certified input. The transfer ZIP contains aggregate
CSV/JSON reports, receipts, and executed source only. It excludes Parquet,
usernames, game IDs, account identifiers, row IDs, and private caches.
