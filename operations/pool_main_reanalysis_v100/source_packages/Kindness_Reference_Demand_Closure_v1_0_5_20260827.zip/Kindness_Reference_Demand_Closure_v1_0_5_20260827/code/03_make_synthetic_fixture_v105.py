#!/usr/bin/env python3
"""Create aligned synthetic Stage 07 and v1.0.2-cache inputs for v1.0.5."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import kindness_price_elasticity_common_v102 as numerical
import reference_demand_v105_common as audit


MONTHS = (
    "2023-11", "2023-12", "2024-01", "2024-02", "2024-03", "2024-04",
    "2024-05", "2024-06", "2024-07", "2024-08", "2024-09", "2024-10",
    "2024-11", "2024-12", "2025-01", "2025-02", "2025-03", "2025-04",
    "2025-05", "2025-06", "2025-07", "2025-08", "2025-09", "2025-10",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--rows", type=int, default=48_000)
    parser.add_argument("--self-test", action="store_true")
    return parser.parse_args()


def write_table(table: object, destination: Path) -> None:
    _, _, _, pq = numerical.import_dependencies()
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name("." + destination.name + ".tmp")
    pq.write_table(table, temporary, compression="zstd", compression_level=9)
    temporary.replace(destination)


def build(root: Path, rows: int) -> dict[str, object]:
    _, np, pa, _ = numerical.import_dependencies()
    choosers = 1_200
    if rows < 24_000 or rows % choosers != 0:
        raise RuntimeError("Synthetic rows must be at least 24,000 and divisible by 1,200")
    observations = rows // choosers
    rng = np.random.default_rng(20260827)
    chooser = np.repeat(np.arange(choosers, dtype=np.int64), observations)
    observation = np.tile(np.arange(observations, dtype=np.int64), choosers)
    row = np.arange(rows, dtype=np.int64)
    gap = ((observation + 7 * chooser) % 61) - 30
    chooser_elo = (1_200 + chooser % 1_000 + observation % 3).astype(np.int64)
    opponent_elo = chooser_elo + gap
    chooser_rd = 45.0 + ((11 * observation + 3 * chooser) % 115)
    opponent_rd = 45.0 + ((17 * observation + 5 * chooser) % 115)
    price = 3.0 + ((13 * observation + 7 * chooser) % 100) / 8.0
    scale = 2.0 * price
    magnitude = np.clip(
        0.006 + np.abs(gap) / 110.0 + (opponent_rd % 13.0) / 2_000.0,
        0.006,
        0.45,
    )
    draw = np.sign(gap).astype(np.float64) * scale * magnitude
    engine = ((19 * observation + 23 * chooser) % 601 - 300).astype(np.float64)
    month = ((observation + chooser // 47) % 24).astype(np.int64)
    speed = ((observation // 2 + chooser // 71) % 5).astype(np.int64)
    ply = ((3 * observation + 11 * chooser) % 121).astype(np.int64)
    price_bin20 = ((5 * observation + chooser) % 20).astype(np.int64)
    draw_bin20 = np.floor((gap + 30) * 20 / 61).astype(np.int64)
    draw_bin50 = np.floor((gap + 30) * 50 / 61).astype(np.int64)
    log_chooser_clock = np.log1p(1.0 + ((31 * observation + chooser) % 400)).astype(np.float64)
    log_opponent_clock = np.log1p(1.0 + ((37 * observation + 3 * chooser) % 500)).astype(np.float64)
    log_chooser_clock[(row % 97) == 0] = np.nan
    log_opponent_clock[(row % 89) == 0] = np.nan
    nonzero = gap != 0
    log_m = np.zeros(rows, dtype=np.float64)
    log_m[nonzero] = np.log(magnitude[nonzero])
    probability = (
        0.045
        + 0.005 * (draw > 0)
        + 0.003 * (draw == 0)
        - 0.00010 * ply
        - 0.0012 * np.log(scale)
        - 0.0008 * log_m
        + 0.000002 * engine
        + ((chooser % 17) - 8) * 0.00025
    )
    kind = rng.random(rows) < np.clip(probability, 0.004, 0.25)
    chooser_sequence = observation.copy()
    chooser_total = np.full(rows, observations, dtype=np.int64)
    chooser_kind_totals = np.repeat(
        np.bincount(chooser, weights=kind.astype(np.int64), minlength=choosers).astype(np.int64),
        observations,
    )
    original_fields = {
        "row_id": row,
        "chooser_index": chooser,
        "chooser_sequence": chooser_sequence,
        "activity_quartile": ((observation + chooser) % 4).astype(np.int64),
        "chooser_total_fair_opportunities": chooser_total,
        "chooser_total_fair_kind_draws": chooser_kind_totals,
        "prior_kind_stratum": ((observation + chooser // 13) % 3).astype(np.int64),
        "kind": kind.astype(np.int8),
        "price": price.astype(np.float64),
        "log_price": np.log(price).astype(np.float64),
        "draw_payoff": draw.astype(np.float64),
        "engine_eval_cp": engine.astype(np.float32),
        "chooser_elo": chooser_elo.astype(np.float32),
        "opponent_elo": opponent_elo.astype(np.float32),
        "chooser_rd": chooser_rd.astype(np.float32),
        "opponent_rd": opponent_rd.astype(np.float32),
        "log_chooser_clock": log_chooser_clock.astype(np.float32),
        "log_opponent_clock": log_opponent_clock.astype(np.float32),
        "tournament": ((3 * observation + chooser) % 11 == 0).astype(np.int8),
        "month_code": month.astype(np.int8),
        "speed_code": speed.astype(np.int8),
        "rating_band": np.minimum(3, chooser_elo // 500).astype(np.int8),
        "eval_band": np.digitize(engine, [-100.0, 0.0, 100.0, 300.0]).astype(np.int8),
        "hour_of_week": ((7 * observation + chooser) % 168).astype(np.int16),
        "both_rd_le_110": ((chooser_rd <= 110) & (opponent_rd <= 110)).astype(np.int8),
        "row_hash": (row * 1_000_003 + 20260827).astype(np.int64),
        "price_bin20": price_bin20.astype(np.int8),
        "draw_bin20": draw_bin20.astype(np.int8),
        "draw_bin50": draw_bin50.astype(np.int8),
    }
    stage_fields = {
        "game_id": [f"synthetic_{value:012d}" for value in row],
        "chooser_username_norm": [f"synthetic_chooser_{value:06d}" for value in chooser],
        "api_last_move_at_ms": (1_700_000_000_000 + chooser * 1_000_000 + observation * 1_000).astype(np.int64),
        "utc_ms": (1_700_000_000_000 + chooser * 1_000_000 + observation * 1_000).astype(np.int64),
        "archive_ordinal": observation.astype(np.int64),
        "month": [MONTHS[int(value)] for value in month],
        "ply_count": ply.astype(np.int32),
        "fair_competitive": np.ones(rows, dtype=np.bool_),
        "kind_draw": kind.astype(np.bool_),
        "chooser_win_premium_v2": price.astype(np.float64),
        "chooser_draw_payoff_v2": draw.astype(np.float64),
        "engine_eval_cp_disconnected": engine.astype(np.float32),
        "chooser_elo": chooser_elo.astype(np.float32),
        "disconnected_elo": opponent_elo.astype(np.float32),
    }
    root.mkdir(parents=True, exist_ok=True)
    prior_cache = root / "fair_price_model_private.parquet"
    stage_source = root / "synthetic_stage07.parquet"
    write_table(pa.table(original_fields), prior_cache)
    write_table(pa.table(stage_fields), stage_source)
    receipt: dict[str, object] = {
        "status": "REFERENCE_DEMAND_V105_SYNTHETIC_FIXTURE_OK",
        "created_utc": audit.utc_now(),
        "rows": rows,
        "kind_draws": int(kind.sum()),
        "choosers": choosers,
        "exact_zero_rows": int(np.count_nonzero(draw == 0.0)),
        "short_rows": int(np.count_nonzero(ply <= 10)),
        "long_rows": int(np.count_nonzero(ply > 10)),
        "prior_cache": str(prior_cache),
        "prior_cache_sha256": audit.sha256_file(prior_cache),
        "stage_source": str(stage_source),
        "stage_source_sha256": audit.sha256_file(stage_source),
        "privacy": "entirely synthetic; no physical account or game data",
    }
    audit.atomic_json(root / "synthetic_fixture_receipt.json", receipt)
    print("REFERENCE_DEMAND_V105_SYNTHETIC_FIXTURE_OK", flush=True)
    print(f"Rows: {rows:,}", flush=True)
    print(f"Kind draws: {int(kind.sum()):,}", flush=True)
    return receipt


def self_test() -> None:
    import numpy as np  # type: ignore
    values = np.array([0, 4, 5, 6, 7, 8, 9, 10, 11, 20, 21, 40, 41, 80, 81])
    bands = np.select(
        [values <= 4, values <= 6, values <= 8, values <= 10,
         values <= 20, values <= 40, values <= 80],
        [0, 1, 2, 3, 4, 5, 6], default=7,
    )
    if bands.tolist() != [0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7]:
        raise RuntimeError("Synthetic fixture ply-band self-test failed")
    print("REFERENCE_DEMAND_V105_SYNTHETIC_FIXTURE_SELFTEST_OK", flush=True)


def main() -> int:
    args = parse_args()
    if args.self_test:
        self_test()
        return 0
    build(args.root.resolve(), args.rows)
    return 0


if __name__ == "__main__":
    sys.exit(main())
