#!/usr/bin/env python3
"""Shared authority, serialization, and privacy utilities for v1.0.4.

The module has no network or dependency-installation path. Physical analysis
writes are directed by callers to new v1.0.4 public and private roots.
"""

from __future__ import annotations

import csv
import hashlib
import json
import math
import os
import re
import tempfile
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import kindness_price_elasticity_common_v102 as numerical


PACKAGE_NAME = "Kindness_Reference_Demand_Closure_v1_0_4_20260827"
CONTRACT_RELATIVE = "frozen_authorities/reference_demand_v104_contract.json"
PUBLIC_STATUS = "KINDNESS_REFERENCE_DEMAND_CLOSURE_V104_OK"
ANALYSIS_STATUS = "KINDNESS_REFERENCE_DEMAND_CLOSURE_V104_ANALYSIS_COMPLETE"
VERIFY_STATUS = "KINDNESS_REFERENCE_DEMAND_CLOSURE_V104_INDEPENDENTLY_VERIFIED_OK"
TRANSFER_STATUS = "KINDNESS_REFERENCE_DEMAND_CLOSURE_V104_TRANSFER_CERTIFIED_OK"


def utc_now() -> str:
    return numerical.utc_now()


def canonical_json(value: Any) -> str:
    return json.dumps(json_ready(value), sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def json_ready(value: Any) -> Any:
    try:
        import numpy as np  # type: ignore
        if isinstance(value, np.ndarray):
            return [json_ready(item) for item in value.tolist()]
        if isinstance(value, np.generic):
            return json_ready(value.item())
    except ImportError:
        pass
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, Mapping):
        return {str(key): json_ready(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_ready(item) for item in value]
    if isinstance(value, float) and not math.isfinite(value):
        return None
    return value


def load_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as stream:
        return json.load(stream)


def atomic_text(path: Path, value: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".tmp", dir=path.parent
    )
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="") as stream:
            stream.write(value)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def atomic_json(path: Path, value: Any) -> None:
    atomic_text(path, json.dumps(json_ready(value), indent=2, sort_keys=True, allow_nan=False) + "\n")


def write_csv(path: Path, rows: Sequence[Mapping[str, Any]]) -> None:
    if not rows:
        raise RuntimeError(f"Refusing to write empty aggregate table: {path}")
    fields: list[str] = []
    seen: set[str] = set()
    for row in rows:
        for field in row:
            if field not in seen:
                fields.append(field)
                seen.add(field)
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".tmp", dir=path.parent
    )
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=fields, lineterminator="\n")
            writer.writeheader()
            for row in rows:
                writer.writerow({key: canonical_json(value) if isinstance(value, (dict, list, tuple)) else json_ready(value) for key, value in row.items()})
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def sha256_file(path: Path, chunk_bytes: int = 16 * 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while block := stream.read(chunk_bytes):
            digest.update(block)
    return digest.hexdigest()


def safe_relative(root: Path, relative: str) -> Path:
    candidate = (root / relative).resolve()
    try:
        candidate.relative_to(root.resolve())
    except ValueError as exc:
        raise RuntimeError(f"Path escapes required root: {relative}") from exc
    return candidate


def load_contract(package_root: Path) -> dict[str, Any]:
    contract = load_json(package_root / CONTRACT_RELATIVE)
    if contract.get("status") != "REFERENCE_DEMAND_V104_CONTRACT_FROZEN":
        raise RuntimeError("Frozen v1.0.4 contract status changed")
    return contract


def verify_environment(contract: Mapping[str, Any]) -> dict[str, Any]:
    duckdb, np, _, _ = numerical.import_dependencies()
    import pandas as pd  # type: ignore
    import pyarrow  # type: ignore
    observed = {
        "duckdb": str(duckdb.__version__),
        "numpy": str(np.__version__),
        "pandas": str(pd.__version__),
        "pyarrow": str(pyarrow.__version__),
    }
    expected = dict(contract["canonical_versions"])
    if observed != expected:
        raise RuntimeError(f"Canonical numerical environment changed: expected={expected}; observed={observed}")
    return {"status": "CANONICAL_ENVIRONMENT_OK", "expected": expected, "observed": observed}


def parse_manifest(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        match = re.fullmatch(r"([0-9a-f]{64})  (.+)", line)
        if not match:
            raise RuntimeError(f"Malformed manifest line: {line!r}")
        rows.append({"sha256": match.group(1), "path": match.group(2)})
    return rows


def verify_package_manifest(root: Path) -> dict[str, Any]:
    manifest = root / "PACKAGE_MANIFEST.sha256"
    if not manifest.is_file():
        raise RuntimeError("PACKAGE_MANIFEST.sha256 is missing")
    rows = parse_manifest(manifest)
    for row in rows:
        if row["path"] == "PACKAGE_MANIFEST.sha256":
            raise RuntimeError("Package manifest cannot hash itself")
        path = safe_relative(root, str(row["path"]))
        if not path.is_file() or sha256_file(path) != row["sha256"]:
            raise RuntimeError(f"Packaged source authentication failed: {row['path']}")
        row["bytes"] = path.stat().st_size
    actual = sorted(
        str(path.relative_to(root))
        for path in root.rglob("*")
        if path.is_file() and path.name != manifest.name
        and "__pycache__" not in path.parts and path.suffix != ".pyc"
    )
    expected = sorted(str(row["path"]) for row in rows)
    if actual != expected:
        raise RuntimeError(f"Package inventory changed; missing={sorted(set(expected)-set(actual))}; extra={sorted(set(actual)-set(expected))}")
    return {"status": "PACKAGE_CONTENTS_AUTHENTICATED_OK", "files": len(rows), "bytes": sum(int(row["bytes"]) for row in rows), "manifest_sha256": sha256_file(manifest)}


def authenticate_v103(repo: Path, package_root: Path) -> dict[str, Any]:
    frozen = package_root / "frozen_authorities/v103"
    public = repo / "results/exploratory_price/reference_demand_v103"
    if not public.is_dir():
        raise RuntimeError(f"Published v1.0.3 authority is missing: {public}")
    rows: list[dict[str, Any]] = []
    with (frozen / "report_file_hashes.tsv").open("r", encoding="utf-8", newline="") as stream:
        for row in csv.DictReader(stream, delimiter="\t"):
            source = safe_relative(public, str(row["file"]))
            if not source.is_file():
                raise RuntimeError(f"Published v1.0.3 file missing: {row['file']}")
            observed = sha256_file(source)
            if observed != row["sha256"] or source.stat().st_size != int(row["bytes"]):
                raise RuntimeError(f"Published v1.0.3 file changed: {row['file']}")
            rows.append({"file": row["file"], "bytes": int(row["bytes"]), "sha256": observed})
    for name in ("_SUCCESS.json", "primary_interpretation.json", "stage08_replication_audit.json"):
        if sha256_file(public / name) != sha256_file(frozen / name):
            raise RuntimeError(f"Frozen and published v1.0.3 authority differ: {name}")
    return {"status": "PUBLISHED_REFERENCE_DEMAND_V103_AUTHENTICATED_OK", "root": str(public), "files": len(rows), "report_manifest_sha256": sha256_file(frozen / "report_file_hashes.tsv")}


def report_rows(root: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for path in sorted(item for item in root.rglob("*") if item.is_file()):
        if path.name == "report_file_hashes.tsv":
            continue
        rows.append({"file": path.relative_to(root).as_posix(), "bytes": path.stat().st_size, "sha256": sha256_file(path)})
    return rows


def write_report_manifest(root: Path) -> None:
    rows = report_rows(root)
    lines = ["file\tbytes\tsha256"] + [f"{row['file']}\t{row['bytes']}\t{row['sha256']}" for row in rows]
    atomic_text(root / "report_file_hashes.tsv", "\n".join(lines) + "\n")


def verify_report_manifest(root: Path) -> dict[str, Any]:
    path = root / "report_file_hashes.tsv"
    if not path.is_file():
        raise RuntimeError("Public report manifest is missing")
    rows: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8", newline="") as stream:
        for row in csv.DictReader(stream, delimiter="\t"):
            source = safe_relative(root, str(row["file"]))
            if not source.is_file() or source.stat().st_size != int(row["bytes"]) or sha256_file(source) != row["sha256"]:
                raise RuntimeError(f"Public report file authentication failed: {row['file']}")
            rows.append(dict(row))
    actual = {item.relative_to(root).as_posix() for item in root.rglob("*") if item.is_file() and item.name != path.name}
    expected = {str(row["file"]) for row in rows}
    if actual != expected:
        raise RuntimeError(f"Public report inventory changed; missing={sorted(expected-actual)}; extra={sorted(actual-expected)}")
    return {"status": "REPORT_MANIFEST_AUTHENTICATED_OK", "files": len(rows), "manifest_sha256": sha256_file(path)}


def privacy_scan_public_output(root: Path) -> dict[str, Any]:
    forbidden_suffixes = {".parquet", ".pgn", ".zst", ".duckdb", ".db", ".jsonl", ".ndjson"}
    forbidden_names = {"game_id", "username", "chooser_index", "row_id", "row_hash"}
    files = [path for path in root.rglob("*") if path.is_file()]
    bad_types = [str(path) for path in files if path.suffix.lower() in forbidden_suffixes]
    if bad_types:
        raise RuntimeError(f"Public output contains forbidden row-level file type: {bad_types}")
    for path in files:
        if path.suffix.lower() not in {".json", ".csv", ".tsv", ".md", ".txt"}:
            continue
        text = path.read_text(encoding="utf-8", errors="strict").lower()
        for field in forbidden_names:
            if re.search(rf"(^|[,\t\"']){re.escape(field)}([,\t\"':]|$)", text):
                raise RuntimeError(f"Public output exposes forbidden row identifier field {field}: {path}")
    return {"status": "PUBLIC_OUTPUT_AGGREGATE_ONLY_OK", "files_scanned": len(files), "forbidden_row_level_files": 0, "row_identifier_fields": 0}


def path_snapshot(paths: Iterable[Path]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for path in sorted({item.resolve() for item in paths}, key=str):
        stat = path.stat()
        rows.append({"path": str(path), "bytes": stat.st_size, "mtime_ns": stat.st_mtime_ns, "inode": stat.st_ino, "mode": stat.st_mode})
    return rows


def assert_snapshot_unchanged(before: Sequence[Mapping[str, Any]], after: Sequence[Mapping[str, Any]]) -> None:
    if canonical_json(list(before)) != canonical_json(list(after)):
        raise RuntimeError("Authenticated input metadata changed during analysis")
