#!/usr/bin/env python3
"""Create an authenticated aggregate-only v1.0.5 transfer ZIP and sidecar."""

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import os
import sys
import tempfile
import zipfile
from pathlib import Path
from typing import Any

import reference_demand_v105_common as audit


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--package-root", type=Path, required=True)
    parser.add_argument("--public-root", type=Path, required=True)
    parser.add_argument("--transfer-root", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--synthetic", action="store_true")
    parser.add_argument("--self-test", action="store_true")
    return parser.parse_args()


def eligible_files(root: Path) -> list[Path]:
    return [
        path for path in sorted(root.rglob("*"))
        if path.is_file() and "__pycache__" not in path.parts
        and path.suffix != ".pyc" and not path.name.startswith(".")
    ]


def build_zip(
    package_root: Path, public_root: Path, transfer_root: Path,
    run_id: str, *, synthetic: bool,
) -> dict[str, Any]:
    audit.verify_package_manifest(package_root)
    success = audit.load_json(public_root / "_SUCCESS.json")
    if success.get("status") != audit.PUBLIC_STATUS or bool(success.get("synthetic")) != bool(synthetic):
        raise RuntimeError("Certified public success receipt is missing or mismatched")
    audit.verify_report_manifest(public_root)
    audit.privacy_scan_public_output(public_root)
    transfer_root.mkdir(parents=True, exist_ok=True)
    prefix = "SYNTHETIC_" if synthetic else ""
    filename = f"{prefix}KINDNESS_REFERENCE_DEMAND_CLOSURE_V105_RESULTS_{run_id}.zip"
    destination = transfer_root / filename
    temporary = transfer_root / f".{filename}.tmp"
    if temporary.exists():
        temporary.unlink()
    entries: list[dict[str, Any]] = []
    with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9, allowZip64=True) as archive:
        for source_root, archive_root in ((public_root, "public_results"), (package_root, "executed_package_source")):
            for path in eligible_files(source_root):
                archive_name = str(Path(archive_root) / path.relative_to(source_root))
                data = path.read_bytes()
                archive.writestr(archive_name, data)
                entries.append({"path": archive_name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
        stream = io.StringIO()
        writer = csv.DictWriter(stream, fieldnames=["path", "bytes", "sha256"], delimiter="\t", lineterminator="\n")
        writer.writeheader(); writer.writerows(entries)
        archive.writestr("TRANSFER_MANIFEST.tsv", stream.getvalue().encode("utf-8"))
    os.replace(temporary, destination)
    with zipfile.ZipFile(destination, "r") as archive:
        bad = archive.testzip()
        if bad is not None:
            raise RuntimeError(f"Transfer ZIP CRC failure: {bad}")
        if len(archive.namelist()) != len(set(archive.namelist())):
            raise RuntimeError("Transfer ZIP contains duplicate names")
        manifest = list(csv.DictReader(io.StringIO(archive.read("TRANSFER_MANIFEST.tsv").decode("utf-8")), delimiter="\t"))
        if len(manifest) != len(entries):
            raise RuntimeError("Transfer ZIP manifest length changed")
        for row in manifest:
            data = archive.read(row["path"])
            if len(data) != int(row["bytes"]) or hashlib.sha256(data).hexdigest() != row["sha256"]:
                raise RuntimeError(f"Transfer ZIP entry authentication failed: {row['path']}")
    digest = audit.sha256_file(destination)
    sidecar = destination.with_name(destination.name + ".sha256")
    audit.atomic_text(sidecar, f"{digest}  {destination.name}\n")
    return {"status": audit.TRANSFER_STATUS, "zip": str(destination), "sidecar": str(sidecar), "sha256": digest, "bytes": destination.stat().st_size, "entries": len(entries) + 1}


def self_test() -> None:
    with tempfile.TemporaryDirectory(prefix="reference_demand_v105_packager_") as temp:
        path = Path(temp) / "sample.zip"
        with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as archive:
            archive.writestr("aggregate.json", b'{"aggregate":true}\n')
        with zipfile.ZipFile(path, "r") as archive:
            if archive.testzip() is not None or archive.read("aggregate.json") != b'{"aggregate":true}\n':
                raise RuntimeError("Packager self-test failed")
    print("KINDNESS_REFERENCE_DEMAND_V105_PACKAGER_SELFTEST_OK", flush=True)


def main() -> int:
    args = parse_args()
    if args.self_test:
        self_test(); return 0
    result = build_zip(args.package_root.resolve(), args.public_root.resolve(), args.transfer_root.resolve(), args.run_id, synthetic=args.synthetic)
    print(result["status"])
    print(f"TRANSFER_ZIP={result['zip']}")
    print(f"TRANSFER_ZIP_SHA256={result['sha256']}")
    print(f"TRANSFER_SIDECAR={result['sidecar']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
