#!/usr/bin/env python3
"""Build and authenticate the append-only v1.0.5 fair-state ply cache."""

from __future__ import annotations

import argparse
import json
import math
import os
import shutil
import sys
import uuid
from pathlib import Path
from typing import Any, Mapping, Sequence

import kindness_price_elasticity_common_v102 as numerical
import reference_demand_v105_common as audit
import run_kindness_price_elasticity_v102 as legacy
import run_kindness_reference_demand_v103 as prior


PROJECT_AUTHORITY = Path("/Volumes/XT_Pro/lichess_kindness")
MAPPING_NAME = "stage07_fair_ply_mapping_private.parquet"
MAPPING_RECEIPT = "stage07_fair_ply_mapping_receipt.json"
AUGMENTED_NAME = "fair_price_model_with_ply_private.parquet"
AUGMENTED_RECEIPT = "fair_price_model_with_ply_receipt.json"


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package-root", type=Path, required=True)
    parser.add_argument("--project-root", type=Path, required=True)
    parser.add_argument("--cache-root", type=Path, required=True)
    parser.add_argument("--source-path", type=Path)
    parser.add_argument("--prior-cache", type=Path)
    parser.add_argument("--threads", type=int, default=8)
    parser.add_argument("--memory-limit", default="16GB")
    parser.add_argument("--synthetic", action="store_true")
    parser.add_argument("--self-test", action="store_true")
    return parser.parse_args(argv)


def sql_paths(paths: Sequence[Path]) -> str:
    return "[" + ",".join(numerical.sql_literal(str(path.resolve())) for path in paths) + "]"


def ply_band_sql(column: str) -> str:
    return f"""
      CASE
        WHEN {column} <= 4 THEN 0
        WHEN {column} <= 6 THEN 1
        WHEN {column} <= 8 THEN 2
        WHEN {column} <= 10 THEN 3
        WHEN {column} <= 20 THEN 4
        WHEN {column} <= 40 THEN 5
        WHEN {column} <= 80 THEN 6
        ELSE 7
      END
    """


def checkpoint_ok(
    output: Path, receipt_path: Path, config_sha256: str, expected_rows: int
) -> dict[str, Any] | None:
    _, _, _, pq = numerical.import_dependencies()
    if not output.exists() and not receipt_path.exists():
        return None
    if not output.is_file() or not receipt_path.is_file():
        raise RuntimeError(f"Partial private cache checkpoint: {output}")
    receipt = audit.load_json(receipt_path)
    if (
        receipt.get("config_sha256") != config_sha256
        or int(receipt.get("rows", -1)) != expected_rows
        or int(pq.ParquetFile(output).metadata.num_rows) != expected_rows
        or int(receipt.get("output_bytes", -1)) != output.stat().st_size
        or receipt.get("output_sha256") != audit.sha256_file(output)
    ):
        raise RuntimeError(f"Private cache checkpoint authentication failed: {output}")
    return dict(receipt)


def production_authorities(
    project: Path, cache_root: Path, contract: Mapping[str, Any],
    *, threads: int, memory_limit: str,
) -> tuple[list[Path], Path, dict[str, Any]]:
    if project.resolve() != PROJECT_AUTHORITY:
        raise RuntimeError(f"Production project authority changed: {project}")
    stage_root = project / numerical.STAGE07_RELATIVE
    stage = numerical.authenticate_stage07(stage_root)
    stage_paths = numerical.stage07_paths(stage_root)
    authenticated = prior.authenticate_prior_v102_cache(
        project=project,
        scratch_state=cache_root / "v102_authentication_scratch",
        threads=threads,
        memory_limit=memory_limit,
    )
    if authenticated is None:
        raise RuntimeError("Immutable v1.0.2 private model cache is absent")
    prior_cache, prior_receipt = authenticated
    expected = contract["original_private_cache"]
    expected_path = (project / expected["relative_path"]).resolve()
    if prior_cache.resolve() != expected_path:
        raise RuntimeError("Immutable v1.0.2 cache path changed")
    if (
        prior_cache.stat().st_size != int(expected["bytes"])
        or audit.sha256_file(prior_cache) != expected["sha256"]
    ):
        raise RuntimeError("Immutable v1.0.2 cache bytes changed")
    return stage_paths, prior_cache, {
        "status": "REFERENCE_DEMAND_V105_INPUT_AUTHORITIES_OK",
        "stage07": stage,
        "prior_cache_receipt": prior_receipt,
        "prior_cache_sha256": expected["sha256"],
    }


def synthetic_authorities(args: argparse.Namespace) -> tuple[list[Path], Path, dict[str, Any]]:
    if args.source_path is None or args.prior_cache is None:
        raise RuntimeError("Synthetic cache build requires --source-path and --prior-cache")
    source = args.source_path.resolve()
    cache = args.prior_cache.resolve()
    if not source.is_file() or not cache.is_file():
        raise RuntimeError("Synthetic source or prior cache is missing")
    return [source], cache, {
        "status": "REFERENCE_DEMAND_V105_SYNTHETIC_INPUT_AUTHORITIES_OK",
        "source_sha256": audit.sha256_file(source),
        "prior_cache_sha256": audit.sha256_file(cache),
    }


def build_mapping(
    *, stage_paths: Sequence[Path], prior_cache: Path, cache_root: Path,
    config_sha256: str, expected_rows: int, expected_choosers: int | None,
    threads: int, memory_limit: str,
) -> tuple[Path, dict[str, Any]]:
    duckdb, _, _, _ = numerical.import_dependencies()
    output = cache_root / MAPPING_NAME
    receipt_path = cache_root / MAPPING_RECEIPT
    saved = checkpoint_ok(output, receipt_path, config_sha256, expected_rows)
    if saved is not None:
        print("REFERENCE_DEMAND_V105_PLY_MAPPING_CHECKPOINT_AUTHENTICATED_OK", flush=True)
        return output, saved

    connection = duckdb.connect()
    temp_root = cache_root / "duckdb_temp/ply_mapping"
    numerical.configure_duckdb(
        connection, threads=threads, memory_limit=memory_limit,
        temp_directory=temp_root,
    )
    source = f"read_parquet({sql_paths(stage_paths)}, union_by_name=true)"
    source_qa = connection.execute(
        f"""
        SELECT
          COUNT(*)::BIGINT,
          COUNT(DISTINCT game_id)::BIGINT,
          COUNT(DISTINCT chooser_username_norm)::BIGINT,
          COUNT(*) FILTER (WHERE ply_count IS NULL)::BIGINT,
          COUNT(*) FILTER (
            WHERE CAST(ply_count AS DOUBLE) < 0
               OR CAST(ply_count AS DOUBLE) != FLOOR(CAST(ply_count AS DOUBLE))
          )::BIGINT,
          MIN(CAST(ply_count AS BIGINT))::BIGINT,
          MAX(CAST(ply_count AS BIGINT))::BIGINT
        FROM {source}
        WHERE CAST(fair_competitive AS BOOLEAN)
        """
    ).fetchone()
    if (
        int(source_qa[0]) != expected_rows
        or int(source_qa[1]) != expected_rows
        or (expected_choosers is not None and int(source_qa[2]) != expected_choosers)
        or int(source_qa[3]) != 0
        or int(source_qa[4]) != 0
        or int(source_qa[5]) < 0
    ):
        raise RuntimeError(f"Stage 07 fair-state ply support changed: {source_qa}")

    connection.execute(
        f"""
        CREATE TEMP TABLE chooser_dimension AS
        WITH keys AS (
          SELECT chooser_username_norm AS chooser_key
          FROM {source}
          WHERE CAST(fair_competitive AS BOOLEAN)
          GROUP BY chooser_username_norm
        )
        SELECT
          chooser_key,
          ROW_NUMBER() OVER (ORDER BY chooser_key)::BIGINT - 1 AS chooser_index
        FROM keys
        """
    )
    temporary = output.with_name(output.name + f".tmp.{uuid.uuid4().hex}")
    month = legacy.month_case("p.month")
    connection.execute(
        f"""
        COPY (
          WITH selected AS (
            SELECT
              d.chooser_index,
              CAST(p.game_id AS VARCHAR) AS game_id,
              COALESCE(CAST(p.api_last_move_at_ms AS BIGINT), CAST(p.utc_ms AS BIGINT))
                AS decision_ms,
              CAST(p.archive_ordinal AS BIGINT) AS archive_ordinal,
              CAST(p.ply_count AS INTEGER) AS ply_count,
              CAST({month} AS TINYINT) AS month_code,
              CAST(p.chooser_win_premium_v2 AS DOUBLE) AS price,
              CAST(p.chooser_draw_payoff_v2 AS DOUBLE) AS draw_payoff,
              CAST(p.engine_eval_cp_disconnected AS FLOAT) AS engine_eval_cp,
              CAST(p.chooser_elo AS FLOAT) AS chooser_elo,
              CAST(p.disconnected_elo AS FLOAT) AS opponent_elo
            FROM {source} p
            INNER JOIN chooser_dimension d
              ON p.chooser_username_norm = d.chooser_key
            WHERE CAST(p.fair_competitive AS BOOLEAN)
          ), ordered AS (
            SELECT
              *,
              ROW_NUMBER() OVER (
                PARTITION BY chooser_index
                ORDER BY decision_ms, archive_ordinal, game_id
              )::BIGINT - 1 AS chooser_sequence
            FROM selected
          )
          SELECT
            ROW_NUMBER() OVER (
              ORDER BY chooser_index, chooser_sequence
            )::BIGINT - 1 AS row_id,
            chooser_index,
            chooser_sequence,
            ply_count,
            month_code,
            price,
            draw_payoff,
            engine_eval_cp,
            chooser_elo,
            opponent_elo
          FROM ordered
          ORDER BY chooser_index, chooser_sequence
        ) TO {numerical.sql_literal(str(temporary))}
          (FORMAT PARQUET, COMPRESSION ZSTD, ROW_GROUP_SIZE 250000)
        """
    )
    mismatch = connection.execute(
        f"""
        SELECT
          COUNT(*)::BIGINT,
          COUNT(*) FILTER (WHERE m.row_id IS NULL OR c.row_id IS NULL)::BIGINT,
          COUNT(*) FILTER (
            WHERE m.chooser_index IS DISTINCT FROM c.chooser_index
               OR m.chooser_sequence IS DISTINCT FROM c.chooser_sequence
               OR m.month_code IS DISTINCT FROM c.month_code
               OR m.price IS DISTINCT FROM c.price
               OR m.draw_payoff IS DISTINCT FROM c.draw_payoff
               OR m.engine_eval_cp IS DISTINCT FROM c.engine_eval_cp
               OR m.chooser_elo IS DISTINCT FROM c.chooser_elo
               OR m.opponent_elo IS DISTINCT FROM c.opponent_elo
          )::BIGINT,
          MIN(m.row_id)::BIGINT,
          MAX(m.row_id)::BIGINT,
          COUNT(DISTINCT m.row_id)::BIGINT,
          COUNT(*) FILTER (WHERE m.ply_count <= 10)::BIGINT
        FROM read_parquet({numerical.sql_literal(str(temporary))}) m
        FULL OUTER JOIN read_parquet({numerical.sql_literal(str(prior_cache))}) c
          USING (row_id)
        """
    ).fetchone()
    connection.close()
    if mismatch[:6] != (
        expected_rows, 0, 0, 0, expected_rows - 1, expected_rows
    ):
        if temporary.exists():
            temporary.unlink()
        raise RuntimeError(f"Ply mapping does not align with immutable cache: {mismatch}")
    os.replace(temporary, output)
    receipt = {
        "status": "REFERENCE_DEMAND_V105_PLY_MAPPING_OK",
        "created_utc": audit.utc_now(),
        "config_sha256": config_sha256,
        "rows": expected_rows,
        "short_rows": int(mismatch[6]),
        "minimum_ply": int(source_qa[5]),
        "maximum_ply": int(source_qa[6]),
        "alignment_mismatch_rows": 0,
        "fingerprints": [
            "row_id", "chooser_index", "chooser_sequence", "month_code",
            "price", "draw_payoff", "engine_eval_cp", "chooser_elo",
            "opponent_elo",
        ],
        "output_bytes": output.stat().st_size,
        "output_sha256": audit.sha256_file(output),
        "privacy": "PRIVATE ROW-LEVEL CHECKPOINT; DO NOT PUBLISH",
    }
    audit.atomic_json(receipt_path, receipt)
    shutil.rmtree(temp_root, ignore_errors=True)
    print("REFERENCE_DEMAND_V105_PLY_MAPPING_OK", flush=True)
    print(f"Rows: {expected_rows:,}", flush=True)
    print(f"Short rows (ply<=10): {int(mismatch[6]):,}", flush=True)
    return output, receipt


def build_augmented(
    *, prior_cache: Path, mapping: Path, cache_root: Path,
    config_sha256: str, expected_rows: int, expected_kinds: int | None,
    expected_choosers: int | None, expected_exact: int | None,
    threads: int, memory_limit: str,
) -> tuple[Path, dict[str, Any]]:
    duckdb, _, _, pq = numerical.import_dependencies()
    output = cache_root / AUGMENTED_NAME
    receipt_path = cache_root / AUGMENTED_RECEIPT
    saved = checkpoint_ok(output, receipt_path, config_sha256, expected_rows)
    if saved is not None:
        print("REFERENCE_DEMAND_V105_AUGMENTED_CACHE_AUTHENTICATED_OK", flush=True)
        return output, saved
    original_columns = set(pq.ParquetFile(prior_cache).schema_arrow.names)
    if {"ply_count", "ply_band", "log_ply"} & original_columns:
        raise RuntimeError("Immutable prior cache unexpectedly already contains ply fields")
    connection = duckdb.connect()
    temp_root = cache_root / "duckdb_temp/augmented_cache"
    numerical.configure_duckdb(
        connection, threads=threads, memory_limit=memory_limit,
        temp_directory=temp_root,
    )
    temporary = output.with_name(output.name + f".tmp.{uuid.uuid4().hex}")
    band = ply_band_sql("m.ply_count")
    connection.execute(
        f"""
        COPY (
          SELECT
            c.*,
            CAST(m.ply_count AS INTEGER) AS ply_count,
            CAST({band} AS TINYINT) AS ply_band,
            LN(1.0 + CAST(m.ply_count AS DOUBLE))::DOUBLE AS log_ply
          FROM read_parquet({numerical.sql_literal(str(prior_cache))}) c
          INNER JOIN read_parquet({numerical.sql_literal(str(mapping))}) m
            USING (row_id)
          ORDER BY c.row_id
        ) TO {numerical.sql_literal(str(temporary))}
          (FORMAT PARQUET, COMPRESSION ZSTD, ROW_GROUP_SIZE 250000)
        """
    )
    qa = connection.execute(
        f"""
        SELECT
          COUNT(*)::BIGINT,
          SUM(CAST(kind AS BIGINT))::BIGINT,
          COUNT(DISTINCT chooser_index)::BIGINT,
          COUNT(*) FILTER (WHERE draw_payoff = 0.0)::BIGINT,
          MIN(row_id)::BIGINT,
          MAX(row_id)::BIGINT,
          COUNT(DISTINCT row_id)::BIGINT,
          COUNT(*) FILTER (
            WHERE ply_count IS NULL OR ply_count < 0
               OR ply_band NOT BETWEEN 0 AND 7
               OR log_ply IS NULL OR NOT isfinite(log_ply)
          )::BIGINT,
          MIN(ply_count)::BIGINT,
          MAX(ply_count)::BIGINT,
          COUNT(*) FILTER (WHERE ply_count <= 10)::BIGINT
        FROM read_parquet({numerical.sql_literal(str(temporary))})
        """
    ).fetchone()
    band_rows = connection.execute(
        f"""
        SELECT ply_band, COUNT(*)::BIGINT, SUM(CAST(kind AS BIGINT))::BIGINT
        FROM read_parquet({numerical.sql_literal(str(temporary))})
        GROUP BY ply_band ORDER BY ply_band
        """
    ).fetchall()
    connection.close()
    expected_prefix = (expected_rows,)
    if qa[0:1] != expected_prefix or qa[4:8] != (0, expected_rows - 1, expected_rows, 0):
        if temporary.exists():
            temporary.unlink()
        raise RuntimeError(f"Augmented cache conservation failed: {qa}")
    if expected_kinds is not None and int(qa[1]) != expected_kinds:
        raise RuntimeError("Augmented cache kind-draw count changed")
    if expected_choosers is not None and int(qa[2]) != expected_choosers:
        raise RuntimeError("Augmented cache chooser count changed")
    if expected_exact is not None and int(qa[3]) != expected_exact:
        raise RuntimeError("Augmented cache exact-zero count changed")
    if [int(row[0]) for row in band_rows] != list(range(8)):
        raise RuntimeError(f"Augmented cache ply-band support changed: {band_rows}")
    os.replace(temporary, output)
    receipt = {
        "status": "REFERENCE_DEMAND_V105_AUGMENTED_CACHE_OK",
        "created_utc": audit.utc_now(),
        "config_sha256": config_sha256,
        "rows": int(qa[0]),
        "kind_draws": int(qa[1]),
        "choosers": int(qa[2]),
        "exact_zero_rows": int(qa[3]),
        "minimum_ply": int(qa[8]),
        "maximum_ply": int(qa[9]),
        "short_rows": int(qa[10]),
        "long_rows": int(qa[0] - qa[10]),
        "ply_band_rows": [
            {"ply_band": int(row[0]), "rows": int(row[1]), "kind_draws": int(row[2])}
            for row in band_rows
        ],
        "source_cache_sha256": audit.sha256_file(prior_cache),
        "mapping_sha256": audit.sha256_file(mapping),
        "output_bytes": output.stat().st_size,
        "output_sha256": audit.sha256_file(output),
        "privacy": "PRIVATE ROW-LEVEL CHECKPOINT; DO NOT PUBLISH",
    }
    audit.atomic_json(receipt_path, receipt)
    shutil.rmtree(temp_root, ignore_errors=True)
    print("REFERENCE_DEMAND_V105_AUGMENTED_CACHE_OK", flush=True)
    print(f"Rows: {int(qa[0]):,}", flush=True)
    print(f"Long rows (ply>10): {int(qa[0] - qa[10]):,}", flush=True)
    return output, receipt


def execute(args: argparse.Namespace) -> dict[str, Any]:
    package_root = args.package_root.resolve()
    project = args.project_root.resolve()
    cache_root = args.cache_root.resolve()
    if args.threads != 8 or args.memory_limit != "16GB":
        raise RuntimeError("v1.0.5 requires exactly 8 DuckDB workers and 16GB")
    package_receipt = audit.verify_package_manifest(package_root)
    contract = audit.load_contract(package_root)
    cache_root.mkdir(parents=True, exist_ok=True)
    if args.synthetic:
        stage_paths, prior_cache, authorities = synthetic_authorities(args)
        _, _, _, pq = numerical.import_dependencies()
        expected_rows = int(pq.ParquetFile(prior_cache).metadata.num_rows)
        expected_kinds = expected_choosers = expected_exact = None
    else:
        audit.verify_environment(contract)
        stage_paths, prior_cache, authorities = production_authorities(
            project, cache_root, contract,
            threads=args.threads, memory_limit=args.memory_limit,
        )
        frozen = contract["original_private_cache"]
        expected_rows = int(frozen["rows"])
        expected_kinds = int(frozen["kind_draws"])
        expected_choosers = int(frozen["choosers"])
        expected_exact = int(frozen["exact_zero_rows"])
    input_paths = [prior_cache, *stage_paths]
    before = audit.path_snapshot(input_paths)
    config = {
        "status": "REFERENCE_DEMAND_V105_CACHE_CONFIGURATION",
        "synthetic": bool(args.synthetic),
        "package_manifest_sha256": package_receipt["manifest_sha256"],
        "contract_sha256": audit.sha256_file(package_root / audit.CONTRACT_RELATIVE),
        "builder_sha256": audit.sha256_file(Path(__file__)),
        "prior_cache_sha256": audit.sha256_file(prior_cache),
        "stage_source_sha256": [audit.sha256_file(path) for path in stage_paths] if args.synthetic else contract["stage07"]["success_sha256"],
        "ply_bands": contract["ply"]["bands"],
        "threads": args.threads,
        "memory_limit": args.memory_limit,
    }
    config_sha256 = numerical.sha256_json(config)
    config_path = cache_root / "cache_configuration.json"
    if config_path.is_file():
        saved = audit.load_json(config_path)
        if saved.get("config_sha256") != config_sha256:
            raise RuntimeError("Cache root belongs to a different v1.0.5 package")
    else:
        audit.atomic_json(config_path, {
            **config, "config_sha256": config_sha256,
            "created_utc": audit.utc_now(),
        })
    mapping, mapping_receipt = build_mapping(
        stage_paths=stage_paths,
        prior_cache=prior_cache,
        cache_root=cache_root,
        config_sha256=config_sha256,
        expected_rows=expected_rows,
        expected_choosers=expected_choosers,
        threads=args.threads,
        memory_limit=args.memory_limit,
    )
    augmented, augmented_receipt = build_augmented(
        prior_cache=prior_cache,
        mapping=mapping,
        cache_root=cache_root,
        config_sha256=config_sha256,
        expected_rows=expected_rows,
        expected_kinds=expected_kinds,
        expected_choosers=expected_choosers,
        expected_exact=expected_exact,
        threads=args.threads,
        memory_limit=args.memory_limit,
    )
    after = audit.path_snapshot(input_paths)
    audit.assert_snapshot_unchanged(before, after)
    completion = {
        "status": "REFERENCE_DEMAND_V105_CACHE_BUILD_COMPLETE",
        "synthetic": bool(args.synthetic),
        "authorities": authorities,
        "input_no_mutation": True,
        "mapping": mapping_receipt,
        "augmented_cache": augmented_receipt,
        "augmented_cache_path": str(augmented),
    }
    audit.atomic_json(cache_root / "_CACHE_SUCCESS.json", completion)
    print("REFERENCE_DEMAND_V105_CACHE_BUILD_COMPLETE", flush=True)
    print(f"Augmented cache: {augmented}", flush=True)
    return completion


def component_self_test() -> None:
    duckdb, _, _, _ = numerical.import_dependencies()
    connection = duckdb.connect()
    values = [0, 4, 5, 6, 7, 8, 9, 10, 11, 20, 21, 40, 41, 80, 81, 500]
    observed = [
        int(row[0]) for row in connection.execute(
            f"SELECT {ply_band_sql('x')} AS band FROM (SELECT UNNEST(?) AS x)",
            [values],
        ).fetchall()
    ]
    connection.close()
    expected = [0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7]
    if observed != expected:
        raise RuntimeError(f"Ply-band component self-test failed: {observed}")
    print("REFERENCE_DEMAND_V105_CACHE_BUILDER_SELFTEST_OK", flush=True)


def main() -> int:
    args = parse_args()
    if args.self_test:
        component_self_test()
        return 0
    execute(args)
    return 0


if __name__ == "__main__":
    sys.exit(main())
