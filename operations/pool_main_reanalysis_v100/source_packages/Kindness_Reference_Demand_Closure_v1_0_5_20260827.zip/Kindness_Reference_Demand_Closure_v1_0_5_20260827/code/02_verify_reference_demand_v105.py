#!/usr/bin/env python3
"""Independently verify v1.0.5 aggregates and finalize certification."""

from __future__ import annotations

import argparse
import csv
import json
import math
import sys
import tempfile
from pathlib import Path
from typing import Any, Sequence

import reference_demand_v105_common as audit


REQUIRED_BEFORE_VERIFICATION = (
    "analysis_complete.json",
    "interpretation.json",
    "receipts/input_authorities.json",
    "receipts/augmented_cache_authentication.json",
    "receipts/v104_exact_replication_gate.json",
    "receipts/input_no_mutation.json",
    "tables/ply_sign_by_band.csv",
    "tables/stage_adjusted_exact_zero_contrasts.csv",
    "tables/stage_adjusted_local_piecewise.csv",
    "tables/stage_adjusted_E1_E5_terms.csv",
    "tables/side_specific_K_M_terms.csv",
    "tables/side_specific_log_abs_D.csv",
    "tables/stage_adjusted_displayed_gap_schedule.csv",
    "tables/joint_adjacent_gap_models.csv",
    "tables/all_new_model_terms.csv",
    "tables/model_attempts.csv",
    "tables/all_model_results.json",
)


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package-root", type=Path, required=True)
    parser.add_argument("--public-root", type=Path, required=True)
    parser.add_argument("--synthetic", action="store_true")
    parser.add_argument("--self-test", action="store_true")
    return parser.parse_args(argv)


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as stream:
        return list(csv.DictReader(stream))


def finite(value: Any, label: str) -> float:
    result = float(value)
    if not math.isfinite(result):
        raise RuntimeError(f"Nonfinite aggregate: {label}")
    return result


def verify(args: argparse.Namespace) -> dict[str, Any]:
    package_root = args.package_root.resolve()
    root = args.public_root.resolve()
    contract = audit.load_contract(package_root)
    audit.verify_package_manifest(package_root)
    audit.authenticate_frozen_v104(package_root, contract)
    for relative in REQUIRED_BEFORE_VERIFICATION:
        if not (root / relative).is_file():
            raise RuntimeError(f"Required public aggregate is missing: {relative}")
    analysis = audit.load_json(root / "analysis_complete.json")
    interpretation = audit.load_json(root / "interpretation.json")
    gate = audit.load_json(root / "receipts/v104_exact_replication_gate.json")
    cache = audit.load_json(root / "receipts/augmented_cache_authentication.json")
    no_mutation = audit.load_json(root / "receipts/input_no_mutation.json")
    if analysis.get("status") != audit.ANALYSIS_STATUS:
        raise RuntimeError("Analysis-completion status changed")
    if interpretation.get("status") != "REFERENCE_DEMAND_V105_INTERPRETATION_COMPLETE":
        raise RuntimeError("Interpretation status changed")
    expected_gate = (
        "REFERENCE_DEMAND_V105_SYNTHETIC_V104_GATE_OK"
        if args.synthetic
        else "REFERENCE_DEMAND_V105_ALL_141_V104_MODELS_REPLICATED_OK"
    )
    if gate.get("status") != expected_gate or int(gate.get("models", -1)) != 141:
        raise RuntimeError("Complete v1.0.4 replication gate failed")
    if not args.synthetic:
        tolerance = float(contract["replication_tolerance_pp"])
        if (
            finite(gate.get("maximum_coefficient_difference_pp"), "v104 coefficient difference") > tolerance
            or finite(gate.get("maximum_se_difference_pp"), "v104 SE difference") > tolerance
        ):
            raise RuntimeError("A complete v1.0.4 replication difference exceeds tolerance")
    if cache.get("status") != "REFERENCE_DEMAND_V105_AUGMENTED_CACHE_AUTHENTICATED_OK":
        raise RuntimeError("Augmented cache receipt changed")
    if no_mutation.get("status") != "AUTHENTICATED_AUGMENTED_CACHE_UNCHANGED_AFTER_ANALYSIS":
        raise RuntimeError("Input no-mutation receipt changed")

    family = contract["new_model_family"]
    attempts = read_csv(root / "tables/model_attempts.csv")
    results = audit.load_json(root / "tables/all_model_results.json")
    if (
        len(attempts) != int(family["total_required_models"])
        or len(results) != int(family["total_required_models"])
        or any(row.get("status") != "ESTIMATED" for row in attempts)
    ):
        raise RuntimeError("Required model inventory or status changed")
    if (
        int(analysis.get("v104_models", -1)) != 141
        or int(analysis.get("new_models", -1)) != int(family["new_models"])
        or int(analysis.get("total_required_models", -1)) != int(family["total_required_models"])
    ):
        raise RuntimeError("Analysis model counts changed")
    names = [str(row.get("model")) for row in results]
    if len(set(names)) != len(names):
        raise RuntimeError("Model names are not unique")

    support = analysis["support"]
    total_rows = int(support["rows"])
    total_kinds = int(support["kind_draws"])
    if int(support["short_rows"]) + int(support["long_rows"]) != total_rows:
        raise RuntimeError("Short and long support do not conserve")
    ply_rows = read_csv(root / "tables/ply_sign_by_band.csv")
    if len(ply_rows) != 32:
        raise RuntimeError("Ply-by-sign table inventory changed")
    all_rows = [row for row in ply_rows if row["draw_sign"] == "all"]
    if sum(int(row["rows"]) for row in all_rows) != total_rows:
        raise RuntimeError("Ply-band rows do not conserve")
    if sum(int(row["kind_draws"]) for row in all_rows) != total_kinds:
        raise RuntimeError("Ply-band kind draws do not conserve")
    for band in {row["ply_band"] for row in all_rows}:
        total = next(row for row in all_rows if row["ply_band"] == band)
        pieces = [row for row in ply_rows if row["ply_band"] == band and row["draw_sign"] != "all"]
        if sum(int(row["rows"]) for row in pieces) != int(total["rows"]):
            raise RuntimeError(f"Draw-sign rows do not conserve within ply band {band}")

    zero = read_csv(root / "tables/stage_adjusted_exact_zero_contrasts.csv")
    piecewise = read_csv(root / "tables/stage_adjusted_local_piecewise.csv")
    if len(zero) != 10 or len(piecewise) != 10:
        raise RuntimeError("Zero or local-piecewise table inventory changed")
    for table, label in ((zero, "zero"), (piecewise, "piecewise")):
        scopes = {row["scope"] for row in table}
        windows = {finite(row["window_abs_draw_payoff_le"], label) for row in table}
        if scopes != {"all", "long_ply_gt_10"} or windows != set(float(value) for value in contract["zero_windows"]):
            raise RuntimeError(f"{label} scope or window inventory changed")
    for row in zero:
        if int(row["negative_rows"]) + int(row["exact_zero_rows"]) + int(row["positive_rows"]) != int(row["rows"]):
            raise RuntimeError("Exact-zero table categories do not conserve")
        for field in (
            "exact_minus_negative_pp", "exact_minus_negative_se_pp",
            "positive_minus_negative_pp", "positive_minus_negative_se_pp",
            "positive_minus_exact_pp", "positive_minus_exact_se_pp",
        ):
            finite(row[field], field)

    schedule = read_csv(root / "tables/stage_adjusted_displayed_gap_schedule.csv")
    if len(schedule) != 144:
        raise RuntimeError("Displayed-gap schedule inventory changed")
    if len([row for row in schedule if row["scope"] == "all"]) != 122:
        raise RuntimeError("Full displayed-gap schedule inventory changed")
    if len([row for row in schedule if row["scope"] == "long_ply_gt_10"]) != 22:
        raise RuntimeError("Long displayed-gap schedule inventory changed")

    privacy = audit.privacy_scan_public_output(root)
    verification = {
        "status": audit.VERIFY_STATUS,
        "verified_at_utc": audit.utc_now(),
        "synthetic": bool(args.synthetic),
        "v104_replication_gate_ok": True,
        "v104_models": 141,
        "new_models": int(family["new_models"]),
        "total_models": int(family["total_required_models"]),
        "rows": total_rows,
        "kind_draws": total_kinds,
        "short_rows": int(support["short_rows"]),
        "long_rows": int(support["long_rows"]),
        "zero_windows": len(contract["zero_windows"]),
        "privacy": privacy,
        "input_no_mutation": True,
        "causal_claims_authorized": False,
        "unique_zero_claim_authorized": False,
        "structural_loss_aversion_claim_authorized": False,
    }
    audit.atomic_json(root / "independent_verification.json", verification)
    audit.write_report_manifest(root)
    report = audit.verify_report_manifest(root)
    success = {
        **analysis,
        "status": audit.PUBLIC_STATUS,
        "certified_at_utc": audit.utc_now(),
        "independent_verification": audit.VERIFY_STATUS,
        "report_files_authenticated": int(report["files"]),
        "pre_success_report_manifest_sha256": report["manifest_sha256"],
        "primary_zero_window_0p5_all": interpretation["primary_zero_window_0p5_all"],
        "primary_zero_window_0p5_long": interpretation["primary_zero_window_0p5_long"],
        "E2_ply_adjusted_all": interpretation["E2_ply_adjusted_all"],
        "E2_ply_adjusted_long": interpretation["E2_ply_adjusted_long"],
        "adjacent_gap_all": interpretation["adjacent_gap_all"],
        "adjacent_gap_long": interpretation["adjacent_gap_long"],
        "costly_K_M_all": interpretation["costly_K_M_all"],
        "costly_K_M_long": interpretation["costly_K_M_long"],
        "aggregate_only": True,
    }
    audit.atomic_json(root / "_SUCCESS.json", success)
    audit.write_report_manifest(root)
    audit.verify_report_manifest(root)
    print(audit.VERIFY_STATUS, flush=True)
    print(f"Files authenticated: {len(REQUIRED_BEFORE_VERIFICATION) + 2}", flush=True)
    return success


def self_test() -> None:
    with tempfile.TemporaryDirectory(prefix="reference_demand_v105_verifier_") as temp:
        path = Path(temp) / "test.csv"
        path.write_text("x,y\n1,2\n", encoding="utf-8")
        rows = read_csv(path)
        if rows != [{"x": "1", "y": "2"}] or finite("2", "test") != 2.0:
            raise RuntimeError("Verifier component self-test failed")
    print("REFERENCE_DEMAND_V105_VERIFIER_SELFTEST_OK", flush=True)


def main() -> int:
    args = parse_args()
    if args.self_test:
        self_test()
        return 0
    verify(args)
    return 0


if __name__ == "__main__":
    sys.exit(main())
