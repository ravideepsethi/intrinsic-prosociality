#!/bin/bash

# macOS Bash 3.2-compatible authenticated, resumable launcher.

set -euo pipefail
umask 077

task_package_root="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
task_project_root="/Volumes/XT_Pro/lichess_kindness"
task_repo_root="${task_project_root}/replication_package"
task_desktop="/Users/u6025368/Desktop/Lichess_Desktop"
task_python="${task_project_root}/venv/bin/python"
task_public_parent="${task_project_root}/output/KINDNESS_REFERENCE_DEMAND_CLOSURE_V105"
task_private_parent="${task_project_root}/derived/private/KINDNESS_REFERENCE_DEMAND_CLOSURE_V105"
task_cache_root="${task_private_parent}/CACHE_V100"
task_augmented_cache="${task_cache_root}/fair_price_model_with_ply_private.parquet"
task_active_pointer="${task_private_parent}/ACTIVE_RUN_ID.txt"

printf '%s\n' '============================================================'
printf '%s\n' 'KINDNESS REFERENCE-DEMAND GAME-STAGE CLOSURE v1.0.5'
printf '%s\n' '============================================================'
printf 'Expected runtime: approximately 60-150 minutes; most likely 75-110.\n'
printf 'Package: %s\n' "$task_package_root"
printf 'Project: %s\n' "$task_project_root"
printf 'Repository: %s\n' "$task_repo_root"
printf 'Transfers: %s\n\n' "$task_desktop"
printf '%s\n' 'This is append-only. Certified v1.0.4 is authenticated and never modified.'
printf '%s\n' 'No API call, PGN download, dependency installation, Git mutation,'
printf '%s\n' 'certified-input write, or row-level transfer occurs.'
printf '%s\n\n' 'Eight DuckDB workers are used; all 335 models are checkpointed.'

[[ -d "$task_project_root" ]] || { printf 'ERROR: Project root missing: %s\n' "$task_project_root" >&2; exit 21; }
[[ -d "$task_repo_root/.git" ]] || { printf 'ERROR: Repository missing: %s\n' "$task_repo_root" >&2; exit 22; }
[[ -x "$task_python" ]] || { printf 'ERROR: Canonical Python missing: %s\n' "$task_python" >&2; exit 23; }
[[ -f "$task_package_root/PACKAGE_MANIFEST.sha256" ]] || { printf 'ERROR: Package manifest missing.\n' >&2; exit 24; }

printf 'Authenticating every packaged source and frozen-authority file...\n'
(
    cd "$task_package_root"
    /usr/bin/shasum -a 256 -c PACKAGE_MANIFEST.sha256
)
printf 'PACKAGE_CONTENTS_AUTHENTICATED_OK\n'
PYTHONDONTWRITEBYTECODE=1 "$task_python" \
    "$task_package_root/code/99_verify_package_contents.py" \
    --package-root "$task_package_root"

task_symlink_count="$(/usr/bin/find "$task_package_root" -type l -print | /usr/bin/wc -l | /usr/bin/tr -d ' ')"
[[ "$task_symlink_count" == "0" ]] || { printf 'ERROR: Package contains symbolic links.\n' >&2; exit 25; }
task_forbidden_count="$(/usr/bin/find "$task_package_root" -type f \( -name '*.parquet' -o -name '*.pgn' -o -name '*.zst' -o -name '*.jsonl' -o -name '*.ndjson' -o -name '*.duckdb' \) -print | /usr/bin/wc -l | /usr/bin/tr -d ' ')"
[[ "$task_forbidden_count" == "0" ]] || { printf 'ERROR: Package contains a forbidden row-level/private file.\n' >&2; exit 26; }
printf 'PACKAGE_CLEANLINESS_OK\n\n'

printf 'Verifying the unchanged canonical numerical environment...\n'
PYTHONDONTWRITEBYTECODE=1 "$task_python" - <<'PY'
import duckdb, numpy, pandas, pyarrow
observed = {
    "duckdb": duckdb.__version__, "numpy": numpy.__version__,
    "pandas": pandas.__version__, "pyarrow": pyarrow.__version__,
}
expected = {"duckdb":"1.5.2","numpy":"2.4.4","pandas":"3.0.3","pyarrow":"24.0.0"}
print("Observed:", observed)
print("Expected:", expected)
if observed != expected:
    raise SystemExit("Canonical numerical environment changed")
print("CANONICAL_ENVIRONMENT_OK")
PY

printf '\nRunning numerical and component self-tests...\n'
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 "$task_python" "$task_package_root/code/kindness_price_elasticity_common_v102.py"
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 "$task_python" "$task_package_root/code/00_build_ply_augmented_cache_v105.py" --package-root "$task_package_root" --project-root "$task_project_root" --cache-root "$task_cache_root" --self-test
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 "$task_python" "$task_package_root/code/01_run_reference_demand_v105.py" --package-root "$task_package_root" --project-root "$task_project_root" --private-root "$task_private_parent" --public-root "$task_public_parent" --cache-path "$task_augmented_cache" --self-test
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 "$task_python" "$task_package_root/code/02_verify_reference_demand_v105.py" --package-root "$task_package_root" --public-root "$task_public_parent" --self-test
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 "$task_python" "$task_package_root/code/03_make_synthetic_fixture_v105.py" --root "$task_private_parent" --self-test
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 "$task_python" "$task_package_root/code/04_package_results.py" --package-root "$task_package_root" --public-root "$task_public_parent" --transfer-root "$task_desktop" --run-id SELFTEST --self-test
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 "$task_python" "$task_package_root/code/99_verify_package_contents.py" --package-root "$task_package_root" --self-test

/bin/mkdir -p "$task_public_parent" "$task_private_parent" "$task_cache_root" "$task_desktop"
task_selftest_id="$(/bin/date -u +%Y%m%dT%H%M%SZ)"
task_selftest_root="${task_project_root}/output/KINDNESS_REFERENCE_DEMAND_CLOSURE_V105_SELFTEST.${task_selftest_id}.$$"
task_selftest_fixture="${task_selftest_root}/fixture"
task_selftest_cache="${task_selftest_root}/cache"
task_selftest_private="${task_selftest_root}/private"
task_selftest_public="${task_selftest_root}/public"
task_selftest_transfer="${task_selftest_root}/transfer"
/bin/mkdir -p "$task_selftest_fixture" "$task_selftest_cache" "$task_selftest_private" "$task_selftest_public" "$task_selftest_transfer"

printf '\nRunning complete end-to-end synthetic cache and model self-test...\n'
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 "$task_python" "$task_package_root/code/03_make_synthetic_fixture_v105.py" --root "$task_selftest_fixture"
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 "$task_python" "$task_package_root/code/00_build_ply_augmented_cache_v105.py" \
    --package-root "$task_package_root" --project-root "$task_selftest_fixture" \
    --cache-root "$task_selftest_cache" \
    --source-path "$task_selftest_fixture/synthetic_stage07.parquet" \
    --prior-cache "$task_selftest_fixture/fair_price_model_private.parquet" \
    --threads 8 --memory-limit 16GB --synthetic
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 "$task_python" "$task_package_root/code/01_run_reference_demand_v105.py" \
    --package-root "$task_package_root" --project-root "$task_selftest_fixture" \
    --private-root "$task_selftest_private" --public-root "$task_selftest_public" \
    --cache-path "$task_selftest_cache/fair_price_model_with_ply_private.parquet" \
    --threads 8 --memory-limit 16GB --synthetic
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 "$task_python" "$task_package_root/code/02_verify_reference_demand_v105.py" \
    --package-root "$task_package_root" --public-root "$task_selftest_public" --synthetic
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 "$task_python" "$task_package_root/code/04_package_results.py" \
    --package-root "$task_package_root" --public-root "$task_selftest_public" \
    --transfer-root "$task_selftest_transfer" --run-id "$task_selftest_id" --synthetic
printf 'REFERENCE_DEMAND_V105_END_TO_END_SYNTHETIC_SELFTEST_OK\n'
printf 'Synthetic self-test retained at: %s\n\n' "$task_selftest_root"

printf 'Building or authenticating the production ply-augmented private cache...\n'
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 "$task_python" "$task_package_root/code/00_build_ply_augmented_cache_v105.py" \
    --package-root "$task_package_root" --project-root "$task_project_root" \
    --cache-root "$task_cache_root" --threads 8 --memory-limit 16GB

task_run_id=""
if [[ -f "$task_active_pointer" ]]; then
    task_candidate="$(/usr/bin/sed -n '1p' "$task_active_pointer" | /usr/bin/tr -d '[:space:]')"
    if [[ "$task_candidate" =~ ^[0-9]{8}T[0-9]{6}Z$ ]]; then
        task_candidate_zip="${task_desktop}/KINDNESS_REFERENCE_DEMAND_CLOSURE_V105_RESULTS_${task_candidate}.zip"
        task_candidate_sidecar="${task_candidate_zip}.sha256"
        if [[ ! -f "${task_public_parent}/${task_candidate}/_SUCCESS.json" ]] || \
           [[ ! -f "$task_candidate_zip" ]] || \
           [[ ! -f "$task_candidate_sidecar" ]]; then
            task_run_id="$task_candidate"
            printf 'Resuming incomplete authenticated run: %s\n' "$task_run_id"
        fi
    else
        printf 'ERROR: Active-run pointer malformed: %s\n' "$task_active_pointer" >&2
        exit 27
    fi
fi
if [[ -z "$task_run_id" ]]; then
    task_run_id="$(/bin/date -u +%Y%m%dT%H%M%SZ)"
    task_pointer_tmp="${task_active_pointer}.tmp.$$"
    printf '%s\n' "$task_run_id" > "$task_pointer_tmp"
    /bin/mv "$task_pointer_tmp" "$task_active_pointer"
    printf 'Starting new authenticated run: %s\n' "$task_run_id"
fi

task_public_root="${task_public_parent}/${task_run_id}"
task_private_root="${task_private_parent}/${task_run_id}"
/bin/mkdir -p "$task_public_root" "$task_private_root"
printf 'Public aggregate root: %s\n' "$task_public_root"
printf 'Private resumable root: %s\n\n' "$task_private_root"

printf 'Running or resuming exact v1.0.4 replication and v1.0.5 closure...\n'
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 "$task_python" "$task_package_root/code/01_run_reference_demand_v105.py" \
    --package-root "$task_package_root" --project-root "$task_project_root" \
    --private-root "$task_private_root" --public-root "$task_public_root" \
    --cache-path "$task_augmented_cache" --threads 8 --memory-limit 16GB

printf '\nRunning independent aggregate verifier...\n'
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 "$task_python" "$task_package_root/code/02_verify_reference_demand_v105.py" \
    --package-root "$task_package_root" --public-root "$task_public_root"

printf '\nRechecking executed-source cleanliness before transfer...\n'
(
    cd "$task_package_root"
    /usr/bin/shasum -a 256 -c PACKAGE_MANIFEST.sha256
)
PYTHONDONTWRITEBYTECODE=1 "$task_python" "$task_package_root/code/99_verify_package_contents.py" --package-root "$task_package_root"

printf '\nBuilding aggregate-only transfer ZIP...\n'
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 "$task_python" "$task_package_root/code/04_package_results.py" \
    --package-root "$task_package_root" --public-root "$task_public_root" \
    --transfer-root "$task_desktop" --run-id "$task_run_id"

printf '\n%s\n' '============================================================'
printf '%s\n' 'KINDNESS REFERENCE-DEMAND GAME-STAGE CLOSURE CERTIFIED COMPLETE'
printf '%s\n' '============================================================'
PYTHONDONTWRITEBYTECODE=1 "$task_python" - "$task_public_root/_SUCCESS.json" <<'PY'
import json, sys
value = json.load(open(sys.argv[1], "r", encoding="utf-8"))
all_zero = value["primary_zero_window_0p5_all"]
long_zero = value["primary_zero_window_0p5_long"]
all_e2 = value["E2_ply_adjusted_all"]
long_e2 = value["E2_ply_adjusted_long"]
all_gap = value["adjacent_gap_all"]
long_gap = value["adjacent_gap_long"]
print("Status: " + value["status"])
print("v1.0.4 exact replication: " + value["v104_replication_gate"])
print("Total required models: " + str(value["total_required_models"]))
print("Fair rows: " + str(value["support"]["rows"]))
print("Long-game rows (ply>10): " + str(value["support"]["long_rows"]))
print("All-game |D|<=0.5 positive-minus-negative (pp): " + str(all_zero["positive_minus_negative_pp"]))
print("Long-game |D|<=0.5 positive-minus-negative (pp): " + str(long_zero["positive_minus_negative_pp"]))
print("All-game adjusted E2 sign coefficient (pp): " + str(all_e2["strictly_favorable"]["coefficient_percentage_points"]))
print("Long-game adjusted E2 sign coefficient (pp): " + str(long_e2["strictly_favorable"]["coefficient_percentage_points"]))
print("All-game displayed gap 0-minus--1 (pp): " + str(all_gap["gap_0_minus_gap_m1"]["coefficient_percentage_points"]))
print("Long-game displayed gap 0-minus--1 (pp): " + str(long_gap["gap_0_minus_gap_m1"]["coefficient_percentage_points"]))
print("Interpretation: exploratory reduced-form associations; not causal price, unique-zero, RD, or structural loss aversion.")
PY
printf 'Public aggregate root: %s\n' "$task_public_root"
printf 'Private resumable root: %s\n' "$task_private_root"
printf 'Synthetic self-test root: %s\n' "$task_selftest_root"
printf '\nREFERENCE_DEMAND_V105_LAUNCHER_COMPLETE\n'
printf 'Upload the generated result ZIP and sidecar and paste this complete final summary into ChatGPT.\n'
