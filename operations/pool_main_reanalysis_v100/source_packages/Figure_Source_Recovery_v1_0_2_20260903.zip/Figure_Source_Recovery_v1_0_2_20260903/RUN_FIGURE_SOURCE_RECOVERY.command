#!/bin/bash
set -euo pipefail
umask 077

PACKAGE_DIR="$(cd "$(dirname "$0")" && pwd)"
SOURCE_RUN="/Users/u6025368/Desktop/Lichess_Desktop/lichess_figure_runs/20260902T163456Z"
RUN_ROOT="/Users/u6025368/Desktop/Lichess_Desktop/lichess_figure_runs"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
RUN_DIR="${RUN_ROOT}/${STAMP}_SOURCE_RECOVERY"
PLOTDATA="${RUN_DIR}/plotdata"
OUTPUT="${RUN_DIR}/outputs/manuscript"
mkdir -p "$PLOTDATA" "$OUTPUT"

PYTHON_BIN=""
for CANDIDATE in /opt/anaconda3/bin/python python3; do
    if [ "$CANDIDATE" = python3 ]; then
        CANDIDATE="$(command -v python3 || true)"
    fi
    if [ -n "$CANDIDATE" ] && [ -x "$CANDIDATE" ] && \
       "$CANDIDATE" -c 'import numpy, pandas, matplotlib' >/dev/null 2>&1; then
        PYTHON_BIN="$CANDIDATE"
        break
    fi
done
if [ -z "$PYTHON_BIN" ]; then
    printf 'ERROR: no existing Python with NumPy, Pandas, and Matplotlib was found.\n' >&2
    exit 20
fi

printf 'FIGURE SOURCE RECOVERY v1.0.2\n'
printf 'Source figure run: %s\n' "$SOURCE_RUN"
printf 'Recovery run: %s\n' "$RUN_DIR"
printf 'ETA: 2–6 minutes; most likely 3–4 minutes.\n'
printf 'No regression, Stage 07 scan, API call, or package installation will run.\n\n'

"$PYTHON_BIN" "$PACKAGE_DIR/code/recover_sources.py" \
    --source-run "$SOURCE_RUN" \
    --output-dir "$PLOTDATA"

"$PYTHON_BIN" "$PACKAGE_DIR/code/render_figures.py" \
    --mode manuscript \
    --input-dir "$PLOTDATA" \
    --output "$OUTPUT" \
    --status "$RUN_DIR/STATUS.md"

"$PYTHON_BIN" "$PACKAGE_DIR/code/audit_outputs.py" \
    --input "$OUTPUT" \
    --output "$OUTPUT/audit"

if ! /usr/bin/grep -q '| Figure 2 | RENDERED |' "$RUN_DIR/STATUS.md" || \
   ! /usr/bin/grep -q '| Figure 4 | RENDERED |' "$RUN_DIR/STATUS.md" || \
   ! /usr/bin/grep -q '| Appendix A1 | RENDERED |' "$RUN_DIR/STATUS.md" || \
   ! /usr/bin/grep -q '| Appendix A2 | RENDERED |' "$RUN_DIR/STATUS.md" || \
   ! /usr/bin/grep -q '| Appendix A3 | RENDERED |' "$RUN_DIR/STATUS.md"; then
    printf 'ERROR: one or more required recovery exhibits remain blocked.\n' >&2
    sed -n '1,80p' "$RUN_DIR/STATUS.md" >&2
    exit 21
fi

RETURN_ZIP="${RUN_ROOT}/LICHESS_FIGURE_SOURCE_RECOVERY_${STAMP}.zip"
if command -v ditto >/dev/null 2>&1; then
    ditto -c -k --sequesterRsrc --keepParent "$RUN_DIR" "$RETURN_ZIP"
else
    (cd "$RUN_ROOT" && zip -qry "$RETURN_ZIP" "$(basename "$RUN_DIR")")
fi
RETURN_SHA="$(/usr/bin/shasum -a 256 "$RETURN_ZIP" | /usr/bin/awk '{print $1}')"
printf '%s  %s\n' "$RETURN_SHA" "$(basename "$RETURN_ZIP")" > "${RETURN_ZIP}.sha256"

printf '\nFIGURE_SOURCE_RECOVERY_COMPLETE\n'
printf 'Result ZIP: %s\n' "$RETURN_ZIP"
printf 'Sidecar: %s.sha256\n' "$RETURN_ZIP"
printf 'Status: %s\n' "$RUN_DIR/STATUS.md"
printf 'Upload the result ZIP and sidecar.\n'
if command -v open >/dev/null 2>&1; then
    open -R "$RETURN_ZIP" || true
fi
