#!/usr/bin/env python3
"""Recover blocked manuscript figures from authenticated aggregate authorities.

This script never reads a row-level chooser identifier except for the optional
source files already aggregated by the completed analyses.  It verifies every
source against a frozen SHA-256 before normalizing it to the figure contracts.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd


EXPECTED = {
    "f2_curve": (
        Path("/Volumes/XT_Pro/lichess_kindness/output/"
             "RATING_GAP_NONPARAMETRIC_CLOSURE_V101/fe_nonparametric_curves.csv"),
        "e7260acac22ba96fe19dcc89364682f5f2cf961bc412faaebd686cc29c1dc3eb",
    ),
    "f2_local": (
        Path("/Volumes/XT_Pro/lichess_kindness/output/"
             "KINDNESS_REFERENCE_DEMAND_CLOSURE_V105/20260827T193553Z/"
             "tables/stage_adjusted_displayed_gap_schedule.csv"),
        "bc386ac58a7eb183e7c0e0b1385d0173458cfbdfcce6640f43e7bbb9627d5829",
    ),
    "a1_year_engine": (
        Path("/Volumes/XT_Pro/lichess_kindness/output/SECTION4_REMAINING_PULLS_V101/"
             "tables/appendix_f_five_bin_gradient_replication.csv"),
        "eb5595047f18d5283f7e8666d402ba855c4d1cfefce150cfe6aa458f07ff63a6",
    ),
    "a2_krd_correlations": (
        Path("/Volumes/XT_Pro/lichess_kindness/output/"
             "rating_gap_krd_decomposition_20260831T183339Z/mechanical_validation.csv"),
        "f2e77327902b5ca2daadb7561726cd0817b54a2dfe74e8240c2d1afa988fa233",
    ),
    "f4_c7x": (
        Path("/Volumes/XT_Pro/lichess_kindness/output/"
             "dynamics_campaign1_c7x_fullpanel_v101/20260828T001831Z/"
             "c7x_descriptive_counts_rates.csv"),
        "585e818e0f2a0f89122ab1712ee8ee3c5e38dbab5bdff13cc70fbec0823acfd3",
    ),
    "f4_c7r": (
        Path("/Volumes/XT_Pro/lichess_kindness/output/"
             "dynamics_campaign1_c7r_closure_v102/20260828T181146Z/"
             "repeat_kindness_rates.csv"),
        "eb36d6c3efe73125175a0deae97fb79392fb040800dda7136d120240559396cf",
    ),
}

BOARD_LABELS = {
    "m100_p100": "−100 to +100 cp",
    "p100_p300": "+100 to +300 cp",
    "p300_p600": "+300 to +600 cp",
}
VARIANT_LABELS = {
    "primary_k20": "primary_k20",
    "k50": "k50",
    "stableRD_K95": "stable_rd_k95",
    "year1": "year_1",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def authenticate(name: str) -> Path:
    path, expected = EXPECTED[name]
    if not path.is_file():
        raise FileNotFoundError(f"Required authority missing: {path}")
    observed = sha256(path)
    if observed != expected:
        raise RuntimeError(
            f"SHA-256 mismatch for {name}: expected {expected}, observed {observed}"
        )
    return path


def write_table(frame: pd.DataFrame, stem: Path) -> Path:
    try:
        path = stem.with_suffix(".parquet")
        frame.to_parquet(path, index=False, compression="zstd")
    except (ImportError, ModuleNotFoundError):
        path = stem.with_suffix(".csv")
        frame.to_csv(path, index=False)
    return path


def write_provenance(
    target: Path, sources: list[Path], status: str, note: str, rows: int
) -> None:
    payload = {
        "status": status,
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "sources": [
            {"path": str(path), "sha256": sha256(path)} for path in sources
        ],
        "output": str(target),
        "output_sha256": sha256(target),
        "rows": int(rows),
        "private_row_level_data_written": False,
        "note": note,
    }
    target.with_suffix(".provenance.json").write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )


def copy_prior_plotdata(source_run: Path, out: Path) -> None:
    source = source_run / "plotdata"
    if not source.is_dir():
        raise FileNotFoundError(f"Prior normalized plotdata not found: {source}")
    for path in source.iterdir():
        if path.is_file() and not path.name.startswith("f2_"):
            shutil.copy2(path, out / path.name)


def normalize_f2(out: Path) -> None:
    local_path = authenticate("f2_local")
    local = pd.read_csv(local_path)
    required = {"scope", "displayed_gap", "coefficient_pp", "se_pp"}
    if not required.issubset(local.columns):
        raise RuntimeError(f"F2 local schema changed: {list(local.columns)}")
    local = local[
        (local["scope"].astype(str) == "all")
        & (local["variant"].astype(str) == "primary")
        & local["displayed_gap"].between(-12, 12)
    ].copy()
    local = local.rename(
        columns={"displayed_gap": "rating_gap", "coefficient_pp": "estimate_pp"}
    )
    local["sample"] = "all"
    local["contrast_label"] = "Displayed gap versus −1 Elo reference"
    local = local[["rating_gap", "estimate_pp", "se_pp", "sample", "contrast_label"]]
    if local["rating_gap"].nunique() != 25 or set(local["rating_gap"]) != set(range(-12, 13)):
        raise RuntimeError("F2 local schedule is not the complete −12…+12 support")
    target = write_table(local.sort_values("rating_gap"), out / "f2_local")
    write_provenance(
        target, [local_path], "submission_ready",
        "Ply-adjusted chooser/month-FE two-gap schedule; reference is displayed gap −1.",
        len(local),
    )

    curve_path = authenticate("f2_curve")
    curve = pd.read_csv(curve_path)
    required = {"model_id", "coef_pp", "se_pp", "identified", "gap_mid", "ci_lo_pp", "ci_hi_pp"}
    if not required.issubset(curve.columns):
        raise RuntimeError(f"F2 curve schema changed: {list(curve.columns)}")
    parsed = curve["model_id"].astype(str).str.split("__", expand=True)
    if parsed.shape[1] != 3:
        raise RuntimeError("Unexpected F2 model_id convention")
    curve["family"] = parsed[0]
    curve["sample"] = parsed[1]
    curve["board_code"] = parsed[2]
    curve = curve[
        (curve["sample"] == "ply_gt_10")
        & curve["board_code"].isin(BOARD_LABELS)
        & curve["family"].isin(VARIANT_LABELS)
    ].copy()
    curve["rating_gap"] = curve["gap_mid"].astype(float)
    curve["estimate_pp"] = curve["coef_pp"].astype(float)
    curve["ci_low_pp"] = curve["ci_lo_pp"].astype(float)
    curve["ci_high_pp"] = curve["ci_hi_pp"].astype(float)
    curve["board_band"] = curve["board_code"].map(BOARD_LABELS)
    curve["variant"] = curve["family"].map(VARIANT_LABELS)
    curve["plot_ok"] = curve["identified"].fillna(0).astype(int).eq(1)
    board_order = {name: order for order, name in enumerate(BOARD_LABELS)}
    variant_order = {name: order for order, name in enumerate(VARIANT_LABELS.values())}
    curve["_board_order"] = curve["board_code"].map(board_order)
    curve["_variant_order"] = curve["variant"].map(variant_order)
    curve = curve.sort_values(["_board_order", "_variant_order", "rating_gap"])
    keep = [
        "rating_gap", "estimate_pp", "se_pp", "ci_low_pp", "ci_high_pp",
        "board_band", "variant", "sample", "plot_ok",
    ]
    curve = curve[keep]
    expected_rows = 3 * 4 * 23
    if len(curve) != expected_rows:
        raise RuntimeError(f"Expected {expected_rows} normalized F2 curve rows; found {len(curve)}")
    target = write_table(curve, out / "f2_curve")
    write_provenance(
        target, [curve_path], "submission_ready",
        "Primary K20 plus K50, stable-RD/K95, and Year-1 variants; Year-2 excluded because its rebuild gate is not certified.",
        len(curve),
    )


def normalize_a1(out: Path) -> None:
    source = authenticate("a1_year_engine")
    frame = pd.read_csv(source)
    required = {
        "fairness_bin", "display_label", "old_N", "old_kind_draws",
        "old_kind_rate_pct", "new_N", "new_kind_draws", "new_kind_rate_pct",
    }
    if not required.issubset(frame.columns):
        raise RuntimeError(f"A1 schema changed: {list(frame.columns)}")
    def rate_from_counts(n: int, kind_draws: int, reported: float, label: str) -> float:
        if n <= 0 or kind_draws < 0 or kind_draws > n:
            raise RuntimeError(f"A1 invalid counts for {label}: n={n}, kind_draws={kind_draws}")
        computed = 100.0 * kind_draws / n
        # Some producer versions stored proportions in columns named *_pct.
        # Accept either unit only when it reconciles with the integer counts,
        # and always plot the count-derived percentage.
        percent_error = abs(reported - computed)
        proportion_error = abs(100.0 * reported - computed)
        if min(percent_error, proportion_error) > 0.002:
            raise RuntimeError(
                f"A1 reported rate does not reconcile with counts for {label}: "
                f"reported={reported}, computed_pct={computed}"
            )
        return computed

    rows = []
    for state_order, row in enumerate(frame.itertuples(index=False)):
        old_n = int(row.old_N)
        old_kind_draws = int(row.old_kind_draws)
        new_n = int(row.new_N)
        new_kind_draws = int(row.new_kind_draws)
        rows.extend([
            {
                "sample_order": 0, "sample": "12m / Stockfish 10k (historical)",
                "state_order": state_order, "state": row.display_label,
                "n": old_n, "kind_draws": old_kind_draws,
                "rate_pct": rate_from_counts(
                    old_n, old_kind_draws, float(row.old_kind_rate_pct),
                    f"historical/{row.display_label}",
                ),
            },
            {
                "sample_order": 1, "sample": "24m / Stockfish 100k",
                "state_order": state_order, "state": row.display_label,
                "n": new_n, "kind_draws": new_kind_draws,
                "rate_pct": rate_from_counts(
                    new_n, new_kind_draws, float(row.new_kind_rate_pct),
                    f"current/{row.display_label}",
                ),
            },
        ])
    normalized = pd.DataFrame(rows)
    if len(normalized) != 10:
        raise RuntimeError("A1 must contain two authenticated five-bin series")
    target = write_table(normalized, out / "a1_year_engine")
    write_provenance(
        target, [source], "submission_ready",
        "Rates are recomputed from authenticated integer counts after validating the source rate under percent/proportion unit detection. Endpoint comparison changes the sample window and engine effort jointly; it is not an engine-only effect.",
        len(normalized),
    )


def normalize_a2(out: Path) -> None:
    source = authenticate("a2_krd_correlations")
    raw = pd.read_csv(source)
    if len(raw) != 1:
        raise RuntimeError("A2 mechanical-validation authority must contain one aggregate row")
    row = raw.iloc[0]
    mapping = [
        ("|Draw payoff| × |rating gap|", "corr_abs_payoff_abs_gap"),
        ("|Draw payoff| × expected-score distance", "corr_abs_payoff_score_distance"),
        ("|Draw payoff| × log K", "corr_abs_payoff_log_k"),
        ("log K × chooser RD", "corr_logk_chooser_rd"),
        ("log K × opponent RD", "corr_logk_opp_rd"),
    ]
    if any(column not in raw.columns for _, column in mapping):
        raise RuntimeError(f"A2 correlation schema changed: {list(raw.columns)}")
    normalized = pd.DataFrame([
        {"measure_order": order, "measure": label, "value": float(row[column])}
        for order, (label, column) in enumerate(mapping)
    ])
    target = write_table(normalized, out / "a2_krd_correlations")
    write_provenance(
        target, [source], "submission_ready",
        "Mechanical K/RD decomposition diagnostic; all values are aggregate correlations and not causal estimates.",
        len(normalized),
    )


def normalize_f4(out: Path) -> None:
    c7x_path = authenticate("f4_c7x")
    c7r_path = authenticate("f4_c7r")
    c7x = pd.read_csv(c7x_path)
    c7r = pd.read_csv(c7r_path)
    primary = c7x[c7x["analysis"] == "latest_reversed_arm_all_gaps"]
    ordinary = c7r[(c7r["scope"] == "all_sampled") & (c7r["meeting"] == "repeat")]
    if len(primary) != 1 or len(ordinary) != 1:
        raise RuntimeError("F4 primary or ordinary re-encounter cell is not unique")
    p = primary.iloc[0]
    o = ordinary.iloc[0]
    raw = pd.DataFrame([
        {"relationship": "Ordinary re-encounter", "n": int(o["rows"]),
         "kind_draws": int(o["kind_draws"]), "rate_pct": float(o["kind_rate_pct"])},
        {"relationship": "Prior claimer", "n": int(p["claimer_rows"]),
         "kind_draws": int(p["claimer_kind_draws"]), "rate_pct": float(p["claimer_kind_rate_pct"])},
        {"relationship": "Prior benefactor", "n": int(p["benefactor_rows"]),
         "kind_draws": int(p["benefactor_kind_draws"]), "rate_pct": float(p["benefactor_kind_rate_pct"])},
    ])
    target = write_table(raw, out / "f4_raw")
    write_provenance(
        target, [c7x_path, c7r_path], "conditional",
        "Exploratory raw rates conditional on a later re-encounter; ordinary repeat rate comes from the C7R closure.",
        len(raw),
    )

    horizons = [
        (0, "0–7 days", "gap_0_7_days"),
        (1, "8–30 days", "gap_8_30_days"),
        (2, "31–180 days", "gap_31_180_days"),
        (3, ">180 days", "gap_over_180_days"),
    ]
    rows = []
    for order, label, analysis in horizons:
        cell = c7x[c7x["analysis"] == analysis]
        if len(cell) != 1:
            raise RuntimeError(f"F4 horizon cell not unique: {analysis}")
        row = cell.iloc[0]
        rows.extend([
            {"horizon_order": order, "horizon": label, "relationship": "Prior claimer",
             "n": int(row["claimer_rows"]), "kind_draws": int(row["claimer_kind_draws"]),
             "rate_pct": float(row["claimer_kind_rate_pct"])},
            {"horizon_order": order, "horizon": label, "relationship": "Prior benefactor",
             "n": int(row["benefactor_rows"]), "kind_draws": int(row["benefactor_kind_draws"]),
             "rate_pct": float(row["benefactor_kind_rate_pct"])},
        ])
    horizon = pd.DataFrame(rows)
    target = write_table(horizon, out / "f4_horizon")
    write_provenance(
        target, [c7x_path], "conditional",
        "C7X exploratory/outcome-informed/post-gate raw horizon rates, conditional on re-encounter.",
        len(horizon),
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-run", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    copy_prior_plotdata(args.source_run, args.output_dir)
    normalize_f2(args.output_dir)
    normalize_a1(args.output_dir)
    normalize_a2(args.output_dir)
    normalize_f4(args.output_dir)
    receipt = {
        "status": "FIGURE_SOURCE_RECOVERY_NORMALIZATION_OK",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "source_run": str(args.source_run),
        "output_dir": str(args.output_dir),
        "authorities": {
            key: {"path": str(path), "sha256": expected}
            for key, (path, expected) in EXPECTED.items()
        },
        "new_analysis_estimated": False,
        "private_row_level_data_written": False,
    }
    (args.output_dir / "RECOVERY_RECEIPT.json").write_text(
        json.dumps(receipt, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print("FIGURE_SOURCE_RECOVERY_NORMALIZATION_OK", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
