#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

from common import sha256_file


def pdf_pages(path: Path) -> int | None:
    pdfinfo = shutil.which("pdfinfo")
    if pdfinfo:
        result = subprocess.run([pdfinfo, str(path)], capture_output=True, text=True, check=False)
        if result.returncode == 0:
            for line in result.stdout.splitlines():
                if line.startswith("Pages:"):
                    return int(line.split(":", 1)[1].strip())
    try:
        from pypdf import PdfReader
        return len(PdfReader(str(path)).pages)
    except Exception:
        return None


def image_metadata(path: Path) -> tuple[int | None, int | None, str]:
    try:
        with Image.open(path) as image:
            return image.width, image.height, image.mode
    except Exception:
        return None, None, ""


def contact_sheet(pngs: list[Path], output: Path) -> Path | None:
    if not pngs:
        return None
    thumb_w, thumb_h = 720, 430
    label_h = 40
    cols = 2
    rows = (len(pngs) + cols - 1) // cols
    sheet = Image.new("RGB", (cols * thumb_w, rows * (thumb_h + label_h)), "white")
    draw = ImageDraw.Draw(sheet)
    font = ImageFont.load_default()
    for idx, path in enumerate(pngs):
        with Image.open(path) as image:
            image = image.convert("RGB")
            image.thumbnail((thumb_w - 20, thumb_h - 20), Image.Resampling.LANCZOS)
            x0 = (idx % cols) * thumb_w + (thumb_w - image.width) // 2
            y0 = (idx // cols) * (thumb_h + label_h) + 10
            sheet.paste(image, (x0, y0))
            label_y = (idx // cols) * (thumb_h + label_h) + thumb_h + 8
            draw.text(((idx % cols) * thumb_w + 12, label_y), path.name, fill="#202124", font=font)
    output.parent.mkdir(parents=True, exist_ok=True)
    sheet.save(output, dpi=(150, 150))
    return output


def main() -> int:
    parser = argparse.ArgumentParser(description="Audit rendered figure outputs and create a proof sheet.")
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    source = Path(args.input)
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    files = sorted(path for path in source.iterdir() if path.is_file() and path.suffix.lower() in {".png", ".pdf", ".svg"})
    rows = []
    failures = []
    for path in files:
        width = height = None
        mode = ""
        pages = None
        if path.suffix.lower() == ".png":
            width, height, mode = image_metadata(path)
            if width is None or height is None or width < 1200 or height < 600:
                failures.append(f"PNG dimension check failed: {path.name}: {width}×{height}")
        elif path.suffix.lower() == ".pdf":
            pages = pdf_pages(path)
            if pages is not None and pages != 1:
                failures.append(f"PDF page-count check failed: {path.name}: {pages}")
        rows.append({
            "file": path.name,
            "size_bytes": path.stat().st_size,
            "sha256": sha256_file(path),
            "width_px": width or "",
            "height_px": height or "",
            "image_mode": mode,
            "pdf_pages": pages if pages is not None else "",
        })

    manifest_csv = output / "figure_file_manifest.csv"
    fields = ["file", "size_bytes", "sha256", "width_px", "height_px", "image_mode", "pdf_pages"]
    with manifest_csv.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    payload = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "source_directory": str(source),
        "files": rows,
        "failures": failures,
        "status": "PASS" if not failures else "FAIL",
    }
    (output / "audit.json").write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    sheet = contact_sheet([path for path in files if path.suffix.lower() == ".png"], output / "contact_sheet.png")
    summary = [
        "# Figure output audit",
        "",
        f"Status: **{payload['status']}**",
        f"Files audited: **{len(files)}**",
        f"Contact sheet: `{sheet}`" if sheet else "Contact sheet: none (no PNG files)",
        "",
    ]
    if failures:
        summary.append("## Failures")
        summary.append("")
        summary.extend(f"- {failure}" for failure in failures)
        summary.append("")
    (output / "README.md").write_text("\n".join(summary), encoding="utf-8")
    print(f"Audit {payload['status']}: {len(files)} files")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())

