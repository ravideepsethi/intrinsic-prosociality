from __future__ import annotations

import hashlib
import json
import math
import re
from pathlib import Path
from typing import Iterable


def load_json(path: str | Path) -> dict:
    with Path(path).open("r", encoding="utf-8") as handle:
        return json.load(handle)


def write_json(path: str | Path, payload: object) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2, sort_keys=True, allow_nan=False)
        handle.write("\n")


def sha256_file(path: str | Path, chunk_size: int = 8 * 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        while True:
            chunk = handle.read(chunk_size)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def normalized_name(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", value.lower()).strip("_")


def choose_column(columns: Iterable[str], aliases: Iterable[str]) -> str | None:
    lookup = {normalized_name(col): col for col in columns}
    for alias in aliases:
        key = normalized_name(alias)
        if key in lookup:
            return lookup[key]
    return None


def wilson_interval(successes: int, total: int, z: float = 1.959963984540054) -> tuple[float, float]:
    if total <= 0:
        return math.nan, math.nan
    p = successes / total
    denom = 1 + z * z / total
    center = (p + z * z / (2 * total)) / denom
    half = z * math.sqrt(p * (1 - p) / total + z * z / (4 * total * total)) / denom
    return 100 * (center - half), 100 * (center + half)


def find_table(input_dir: str | Path, stem: str) -> Path | None:
    root = Path(input_dir)
    for suffix in (".parquet", ".csv", ".tsv"):
        candidate = root / f"{stem}{suffix}"
        if candidate.exists():
            return candidate
    return None


def read_table(path: str | Path):
    import pandas as pd

    source = Path(path)
    suffix = source.suffix.lower()
    if suffix == ".parquet":
        return pd.read_parquet(source)
    if suffix == ".csv":
        return pd.read_csv(source)
    if suffix == ".tsv":
        return pd.read_csv(source, sep="\t")
    raise ValueError(f"Unsupported table type: {source}")


def write_table(df, path: str | Path) -> Path:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.suffix.lower() == ".parquet":
        df.to_parquet(target, index=False, compression="zstd")
    elif target.suffix.lower() == ".csv":
        df.to_csv(target, index=False)
    else:
        raise ValueError(f"Unsupported output table type: {target}")
    return target

