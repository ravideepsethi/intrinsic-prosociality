#!/usr/bin/env python3
from __future__ import annotations

import argparse
import math
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.ticker import FuncFormatter

from common import find_table, read_table, wilson_interval


BLUE = "#2C6E9B"
ORANGE = "#D97732"
TEAL = "#3A8F81"
PURPLE = "#7857A6"
RED = "#B84A4A"
GRAY = "#6B7280"
LIGHT_GRAY = "#E5E7EB"
INK = "#202124"
STATE_COLORS = ["#2166AC", "#67A9CF", "#D1E5F0", "#EF8A62", "#B2182B"]


def set_style() -> None:
    plt.rcParams.update({
        "figure.facecolor": "white",
        "axes.facecolor": "white",
        "savefig.facecolor": "white",
        "font.family": "DejaVu Sans",
        "font.size": 8.5,
        "axes.titlesize": 9.5,
        "axes.labelsize": 8.5,
        "xtick.labelsize": 7.5,
        "ytick.labelsize": 7.5,
        "axes.edgecolor": "#555555",
        "axes.linewidth": 0.7,
        "axes.titlelocation": "left",
        "axes.titleweight": "bold",
        "legend.fontsize": 7.2,
        "legend.frameon": False,
        "grid.color": "#D7DCE1",
        "grid.linewidth": 0.5,
        "grid.alpha": 0.7,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "svg.fonttype": "none",
    })


def clean_axes(ax, grid: str = "y") -> None:
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    if grid:
        ax.grid(axis=grid, zorder=0)
    ax.set_axisbelow(True)


def panel_title(ax, letter: str, title: str) -> None:
    prefix = f"{letter}. " if letter else ""
    ax.set_title(f"{prefix}{title}", loc="left", pad=7)


def add_preview_mark(fig) -> None:
    fig.text(0.5, 0.993, "LAYOUT PREVIEW — NOT FOR SUBMISSION",
             ha="center", va="top", color=RED, fontsize=8, fontweight="bold")


def add_note(fig, text: str) -> None:
    fig.text(0.01, 0.005, text, ha="left", va="bottom", fontsize=5.8, color="#555555")


def save_figure(fig, output: Path, stem: str, preview: bool = False,
                wspace: float = 0.34, bottom: float = 0.19) -> list[Path]:
    output.mkdir(parents=True, exist_ok=True)
    if preview:
        add_preview_mark(fig)
    fig.subplots_adjust(top=0.88 if preview else 0.91, bottom=bottom, left=0.10, right=0.985, wspace=wspace)
    written = []
    for suffix, kwargs in (
        ("png", {"dpi": 300}),
        ("pdf", {}),
        ("svg", {}),
    ):
        target = output / f"{stem}.{suffix}"
        fig.savefig(target, bbox_inches="tight", pad_inches=0.04, **kwargs)
        written.append(target)
    plt.close(fig)
    return written


def pct_axis(ax, decimals: int = 1) -> None:
    ax.yaxis.set_major_formatter(FuncFormatter(lambda value, pos: f"{value:.{decimals}f}%"))


def pct_xaxis(ax, decimals: int = 1) -> None:
    ax.xaxis.set_major_formatter(FuncFormatter(lambda value, pos: f"{value:.{decimals}f}%"))


def error_bounds(frame: pd.DataFrame) -> tuple[np.ndarray, np.ndarray] | None:
    if {"ci_low_pp", "ci_high_pp"}.issubset(frame.columns):
        return frame["ci_low_pp"].to_numpy(float), frame["ci_high_pp"].to_numpy(float)
    if "se_pp" in frame.columns:
        estimate = frame["estimate_pp"].to_numpy(float)
        se = frame["se_pp"].to_numpy(float)
        return estimate - 1.96 * se, estimate + 1.96 * se
    return None


def render_preview_f1(output: Path) -> list[Path]:
    states = ["Clearly better", "Better", "Roughly equal", "Modestly worse", "Clearly worse"]
    rates = np.array([3.6465, 2.4282, 2.6526, 1.2352, 0.5015])
    counts = [3_517_357, 3_314_026, 10_496_747, 4_168_727, 26_090_163]
    ply = ["0–4", "5–6", "7–8", "9–10", "11–20", "21–40", "41–80", "81+"]
    ply_rates = [4.428, 3.518, 3.221, 2.979, 2.527, 1.839, 1.410, 1.961]

    fig, axes = plt.subplots(1, 2, figsize=(7.25, 3.25), gridspec_kw={"width_ratios": [1.05, 1.35]})
    y = np.arange(len(states))
    axes[0].barh(y, rates, color=STATE_COLORS, height=0.62, zorder=3)
    axes[0].set_yticks(y, states)
    axes[0].invert_yaxis()
    axes[0].set_xlabel("Kind-draw rate")
    pct_xaxis(axes[0], 1)
    clean_axes(axes[0], "x")
    panel_title(axes[0], "A", "Board merit")
    for yi, rate, count in zip(y, rates, counts):
        axes[0].text(rate + 0.07, yi, f"{rate:.2f}%\nN={count/1e6:.1f}m", va="center", fontsize=6.4)
    axes[0].set_xlim(0, 4.35)

    x = np.arange(len(ply))
    axes[1].plot(x, ply_rates, color=BLUE, marker="o", lw=1.8, ms=4)
    axes[1].fill_between(x, 0, ply_rates, color=BLUE, alpha=0.08)
    axes[1].set_xticks(x, ply, rotation=35, ha="right")
    axes[1].set_ylabel("Kind-draw rate")
    axes[1].set_xlabel("Final-position ply band")
    pct_axis(axes[1], 1)
    clean_axes(axes[1])
    panel_title(axes[1], "B", "Game stage in roughly equal positions")
    axes[1].annotate("Late drawn-endgame\ncomposition", xy=(7, 1.961), xytext=(5.7, 2.75),
                     arrowprops={"arrowstyle": "-", "color": GRAY, "lw": 0.7}, fontsize=6.5, color=GRAY)
    axes[1].set_ylim(0, 5.0)
    add_note(fig, "Preview inputs: current 24m/100k handoff. Final Panel B uses the complete authenticated 5×8 state-by-ply grid.")
    return save_figure(fig, output, "figure_1_structure_PREVIEW", preview=True, wspace=0.46)


def render_preview_f2(output: Path) -> list[Path]:
    fig, axes = plt.subplots(1, 2, figsize=(7.25, 3.3), gridspec_kw={"width_ratios": [0.85, 1.65]})
    labels = ["Tie vs −1", "+1 vs −1", "Tie vs −1\n(ply >10)"]
    estimates = np.array([0.019, -0.009, 0.061])
    y = np.arange(len(labels))
    axes[0].axvline(0, color=INK, lw=0.8)
    axes[0].scatter(estimates, y, color=BLUE, s=28, zorder=3)
    axes[0].set_yticks(y, labels)
    axes[0].invert_yaxis()
    axes[0].set_xlabel("Difference (percentage points)")
    axes[0].set_xlim(-0.15, 0.15)
    clean_axes(axes[0], "x")
    panel_title(axes[0], "A", "No local equality kink")

    gaps = np.array([-350, -300, -250, -200, -150, -100, -50, 0, 50, 100, 150, 200, 250, 300, 350])
    effects = np.array([-0.564, -0.451, -0.493, -0.388, -0.518, -0.440, -0.293, 0,
                        0.150, 0.278, 0.451, 0.492, 0.558, 0.700, 0.613])
    axes[1].axhline(0, color=INK, lw=0.8)
    axes[1].axvline(0, color=GRAY, lw=0.7, ls="--")
    axes[1].plot(gaps, effects, color=BLUE, marker="o", ms=3.5, lw=1.6, label="Roughly equal board")
    axes[1].set_xlabel("Disconnected player rating − chooser rating (Elo)")
    axes[1].set_ylabel("Adjusted kind-draw difference (pp)")
    axes[1].set_xlim(-380, 380)
    axes[1].set_ylim(-0.85, 0.95)
    clean_axes(axes[1])
    panel_title(axes[1], "B", "Broad relative-strength gradient, ply >10")
    axes[1].legend(loc="upper left")
    axes[1].text(-345, -0.75, "Weaker opponent", color=GRAY, fontsize=6.5)
    axes[1].text(190, -0.75, "Stronger opponent", color=GRAY, fontsize=6.5)
    add_note(fig, "Preview uses approximate Aug. 31 curve values and three reported local contrasts; all 24 local contrasts are within ±0.14 pp and none is significant. Final output requires exact coefficients/SEs and three board bands.")
    return save_figure(fig, output, "figure_2_relative_strength_PREVIEW", preview=True)


def render_preview_f3(output: Path) -> list[Path]:
    fig, axes = plt.subplots(1, 2, figsize=(7.25, 3.2), gridspec_kw={"width_ratios": [1.45, 0.8]})
    metrics = ["Raw", "Opportunity-weighted", "Harmonic-weighted"]
    hash_values = [0.5898, 0.6837, 0.6970]
    temporal_values = [0.5316, 0.6066, 0.6382]
    x = np.arange(len(metrics))
    width = 0.34
    axes[0].bar(x - width / 2, hash_values, width, color=BLUE, label="Hash split", zorder=3)
    axes[0].bar(x + width / 2, temporal_values, width, color=ORANGE, label="Temporal split", zorder=3)
    axes[0].set_xticks(x, metrics, rotation=15, ha="right")
    axes[0].set_ylim(0, 0.78)
    axes[0].set_ylabel("First-/second-half correlation")
    clean_axes(axes[0])
    panel_title(axes[0], "A", "Split-half persistence")
    axes[0].legend(loc="upper left", ncol=2)

    prior_labels = ["No prior\nkind draw", "Prior\nkind draw"]
    prior_rates = [1.0384, 14.9489]
    bars = axes[1].bar(prior_labels, prior_rates, color=["#AAB2BD", TEAL], width=0.62, zorder=3)
    axes[1].set_ylabel("Later kind-draw rate")
    pct_axis(axes[1], 1)
    axes[1].set_ylim(0, 17)
    clean_axes(axes[1])
    panel_title(axes[1], "B", "Forward prediction")
    for bar, value in zip(bars, prior_rates):
        axes[1].text(bar.get_x() + bar.get_width() / 2, value + 0.5, f"{value:.2f}%", ha="center", fontsize=7)
    axes[1].text(0.5, 0.78, "14.4×", transform=axes[1].transAxes, ha="center", fontsize=10, fontweight="bold", color=TEAL)
    add_note(fig, "Preview inputs: current 24m/100k handoff. A final chooser-effect histogram is added only from disclosure-safe authenticated bins.")
    return save_figure(fig, output, "figure_3_persistence_PREVIEW", preview=True)


def render_preview_f4(output: Path) -> list[Path]:
    fig, axes = plt.subplots(1, 2, figsize=(7.25, 3.3), gridspec_kw={"width_ratios": [0.9, 1.4]})
    labels = ["Ordinary\nre-encounter", "Prior\nclaimer", "Prior\nbenefactor"]
    rates = [2.9, 100 * 1247 / 25419, 100 * 915 / 2208]
    colors = ["#AAB2BD", ORANGE, TEAL]
    bars = axes[0].bar(labels, rates, color=colors, width=0.65, zorder=3)
    axes[0].set_ylabel("Kind-draw rate")
    pct_axis(axes[0], 0)
    axes[0].set_ylim(0, 48)
    clean_axes(axes[0])
    panel_title(axes[0], "A", "Targeted raw rates")
    for bar, value in zip(bars, rates):
        axes[0].text(bar.get_x() + bar.get_width() / 2, value + 1.0, f"{value:.1f}%", ha="center", fontsize=7)

    horizon = ["≤7d", "8–30d", "31–180d", ">180d"]
    benefactor = [43.9, 45.7, 41.4, 32.6]
    claimer = [5.7, 5.7, 4.9, 2.7]
    x = np.arange(len(horizon))
    axes[1].plot(x, benefactor, color=TEAL, marker="o", lw=1.8, label="Prior benefactor")
    axes[1].plot(x, claimer, color=ORANGE, marker="o", lw=1.8, label="Prior claimer")
    axes[1].set_xticks(x, horizon)
    axes[1].set_xlabel("Time since prior encounter")
    axes[1].set_ylabel("Kind-draw rate")
    axes[1].set_ylim(0, 52)
    pct_axis(axes[1], 0)
    clean_axes(axes[1])
    panel_title(axes[1], "B", "The targeted gap remains large")
    axes[1].legend(loc="upper right")
    axes[1].text(0.02, 0.03, "Exploratory / outcome-informed / post-gate",
                 transform=axes[1].transAxes, fontsize=6.3, color=RED, fontweight="bold",
                 bbox={"facecolor": "white", "edgecolor": "none", "alpha": 0.8, "pad": 1.5})
    add_note(fig, "Preview inputs: current C7X handoff. Final output requires authenticated horizon counts/uncertainty and preserves the failed prespecified support gate.")
    return save_figure(fig, output, "figure_4_targeted_memory_PREVIEW", preview=True)


def render_preview_a4(output: Path) -> list[Path]:
    fig, axes = plt.subplots(1, 2, figsize=(7.25, 3.25), gridspec_kw={"width_ratios": [1.1, 1.2]})
    specs = ["Primary", "State controls", "Common overlap", "Fine cells", "Very fine cells", "Exposure-chooser FE", "Next-event censoring"]
    estimates = np.array([1.0047, 1.0164, 0.9269, 0.9445, 0.9525, 1.2752, 1.2667])
    y = np.arange(len(specs))
    axes[0].axvline(0, color=INK, lw=0.8)
    axes[0].scatter(estimates, y, color=BLUE, s=24, zorder=3)
    axes[0].set_yticks(y, specs)
    axes[0].invert_yaxis()
    axes[0].set_xlim(0, 1.55)
    axes[0].set_xlabel("Mercy-minus-claim estimate (pp)")
    clean_axes(axes[0], "x")
    panel_title(axes[0], "A", "Next-opportunity estimates")

    horizon = ["≤6h", "6h–1d", "1–7d", "7–30d", "30–90d"]
    values = [1.6685, 0.8923, 1.2002, 0.7975, 0.4866]
    x = np.arange(len(horizon))
    axes[1].plot(x, values, color=BLUE, marker="o", lw=1.8)
    axes[1].axhline(0, color=INK, lw=0.8)
    axes[1].set_xticks(x, horizon, rotation=25, ha="right")
    axes[1].set_ylabel("Mercy-minus-claim estimate (pp)")
    axes[1].set_xlabel("Time to next opportunity")
    axes[1].set_ylim(0, 2.0)
    clean_axes(axes[1])
    panel_title(axes[1], "B", "Broad attenuation with time")
    add_note(fig, "Preview only. Final forest plot requires the authenticated A1 aggregate file and full confidence intervals.")
    return save_figure(fig, output, "appendix_A4_receipt_dynamics_PREVIEW", preview=True)


def render_preview_a5(output: Path) -> list[Path]:
    fig, axes = plt.subplots(1, 2, figsize=(7.25, 3.25))
    horizons = ["6h", "24h", "7d"]
    observed = [51.6923, 49.7415, 43.1967]
    benchmark = [33.8607, 33.1150, 31.6166]
    x = np.arange(3)
    axes[0].plot(x, observed, color=TEAL, marker="o", lw=1.8, label="Observed")
    axes[0].plot(x, benchmark, color=GRAY, marker="o", lw=1.5, ls="--", label="Randomization benchmark")
    axes[0].set_xticks(x, horizons)
    axes[0].set_ylabel("Probability of another grant")
    pct_axis(axes[0], 0)
    axes[0].set_ylim(25, 58)
    clean_axes(axes[0])
    panel_title(axes[0], "A", "B2: grants cluster in time")
    axes[0].legend()

    contrasts = ["Later session\n(7d)", "Same session", "Same pool\n(24h)", "Cross pool"]
    excess = [11.105, 19.181, 17.2, 10.2]
    bars = axes[1].bar(contrasts, excess, color=[BLUE, PURPLE, TEAL, ORANGE], zorder=3)
    axes[1].set_ylabel("Excess over randomization benchmark (pp)")
    axes[1].set_ylim(0, 22)
    clean_axes(axes[1])
    panel_title(axes[1], "B", "C9: episodes cross sessions")
    for bar, value in zip(bars, excess):
        axes[1].text(bar.get_x() + bar.get_width() / 2, value + 0.6, f"{value:.1f}", ha="center", fontsize=6.6)
    add_note(fig, "Preview inputs: certified B2 and corrected C9 values in the current handoff. Randomization designs reject exchangeability, not causal state formation.")
    return save_figure(fig, output, "appendix_A5_episode_dynamics_PREVIEW", preview=True)


def render_preview_a6(output: Path) -> list[Path]:
    fig, axes = plt.subplots(1, 3, figsize=(7.25, 3.15), gridspec_kw={"width_ratios": [0.8, 1.1, 1.35]})
    matched_labels = ["Matched\ncontrols", "Fair-kind\nchoosers"]
    matched_rates = [0.3279, 0.6335]
    bars = axes[0].bar(matched_labels, matched_rates, color=["#AAB2BD", TEAL], zorder=3)
    axes[0].set_ylim(0, 0.75)
    axes[0].set_ylabel("Current Patron rate")
    pct_axis(axes[0], 1)
    clean_axes(axes[0])
    panel_title(axes[0], "A", "Matched rates")
    for bar, value in zip(bars, matched_rates):
        axes[0].text(bar.get_x() + bar.get_width() / 2, value + 0.03, f"{value:.3f}%", ha="center", fontsize=6.3)

    groups = ["Losing only", "Neither", "Both", "Fair only"]
    group_rates = [0.2575, 0.4334, 0.5423, 0.8975]
    axes[1].barh(np.arange(4), group_rates, color=[RED, "#AAB2BD", BLUE, TEAL], zorder=3)
    axes[1].set_yticks(np.arange(4), groups)
    axes[1].set_xlabel("Current Patron rate")
    axes[1].xaxis.set_major_formatter(FuncFormatter(lambda value, pos: f"{value:.1f}%"))
    clean_axes(axes[1], "x")
    panel_title(axes[1], "B", "Diagnostic horse race")

    dose = ["0", "1", "2–4", "5–9", "10+"]
    dose_rates = [0.3141, 0.4783, 0.8492, 1.3561, 1.3002]
    x = np.arange(5)
    axes[2].plot(x, dose_rates, color=TEAL, marker="o", lw=1.8)
    axes[2].set_xticks(x, dose)
    axes[2].set_xlabel("Observed fair-state kind draws")
    axes[2].set_ylabel("Current Patron rate")
    pct_axis(axes[2], 1)
    axes[2].set_ylim(0, 1.55)
    clean_axes(axes[2])
    panel_title(axes[2], "C", "Dose and saturation")
    add_note(fig, "Preview inputs: Patron Stage 10 authority ledger. Current status is cross-sectional; the 10+ bin does not imply strict monotonicity.")
    return save_figure(fig, output, "appendix_A6_patron_bridge_PREVIEW", preview=True, wspace=0.58, bottom=0.22)


def render_preview_a7(output: Path) -> list[Path]:
    states = ["Clearly better", "Better", "Roughly equal", "Modestly worse", "Clearly worse"]
    estimates = np.array([0.2403, 0.3072, 0.1169, 0.0388, -0.2129])
    se = np.array([0.1033, 0.1334, 0.0952, 0.1550, 0.0715])
    y = np.arange(5)
    fig, ax = plt.subplots(figsize=(5.8, 3.35))
    ax.axvline(0, color=INK, lw=0.8)
    ax.errorbar(estimates, y, xerr=1.96 * se, fmt="o", color=BLUE, ecolor=BLUE,
                capsize=2.5, lw=1.1, ms=4.2)
    ax.set_yticks(y, states)
    ax.invert_yaxis()
    ax.set_xlabel("Association with current Patron status (pp)")
    ax.set_xlim(-0.43, 0.64)
    clean_axes(ax, "x")
    panel_title(ax, "", "Patron association by state")
    ax.text(0.98, 0.05, "Endpoint contrast: +0.453 pp\nHC1 p=.00048",
            transform=ax.transAxes, ha="right", va="bottom", fontsize=7, color=GRAY)
    add_note(fig, "Preview reproduces the authenticated addendum values. Final plot must be rebuilt from aggregate CSV/JSON, N=100,904; 518 Patrons; 16 cells.")
    return save_figure(fig, output, "appendix_A7_patron_five_bin_PREVIEW", preview=True)


def render_preview_set(output: Path) -> list[Path]:
    written = []
    for renderer in (render_preview_f1, render_preview_f2, render_preview_f3, render_preview_f4,
                     render_preview_a4, render_preview_a5, render_preview_a6, render_preview_a7):
        written.extend(renderer(output))
    return written


def render_f1(input_dir: Path, output: Path) -> tuple[bool, str]:
    source = find_table(input_dir, "f1_state_ply")
    if source is None:
        return False, "F1 missing f1_state_ply"
    frame = read_table(source)
    required = {"state_order", "state", "ply_order", "ply_band", "n", "kind_draws", "rate_pct"}
    if not required.issubset(frame.columns):
        return False, f"F1 schema missing {sorted(required - set(frame.columns))}"
    if len(frame) != 40 or int(frame["n"].sum()) != 47_587_020 or int(frame["kind_draws"].sum()) != 669_503:
        return False, "F1 failed 40-cell / Stage 07 total invariants"
    frame = frame.sort_values(["state_order", "ply_order"])
    state = (frame.groupby(["state_order", "state"], as_index=False)
             .agg(n=("n", "sum"), kind_draws=("kind_draws", "sum")))
    state["rate_pct"] = 100 * state["kind_draws"] / state["n"]
    pivot = frame.pivot(index="state", columns="ply_band", values="rate_pct")
    state_labels = state.sort_values("state_order")["state"].tolist()
    ply_labels = frame.sort_values("ply_order")["ply_band"].drop_duplicates().tolist()
    pivot = pivot.reindex(index=state_labels, columns=ply_labels)

    fig, axes = plt.subplots(1, 2, figsize=(7.25, 3.35), gridspec_kw={"width_ratios": [0.9, 1.6]})
    y = np.arange(len(state))
    axes[0].barh(y, state["rate_pct"], color=STATE_COLORS, height=0.62, zorder=3)
    axes[0].set_yticks(y, state["state"])
    axes[0].invert_yaxis()
    axes[0].set_xlabel("Kind-draw rate")
    axes[0].set_ylabel("Disconnected player's position")
    pct_xaxis(axes[0], 1)
    axes[0].set_xlim(0, 1.28 * state["rate_pct"].max())
    clean_axes(axes[0], "x")
    panel_title(axes[0], "A", "Board merit")
    for yi, row in state.reset_index(drop=True).iterrows():
        axes[0].text(row["rate_pct"] + 0.05, yi, f"{row['rate_pct']:.2f}%", va="center", fontsize=6.6)

    matrix = pivot.to_numpy(float)
    im = axes[1].imshow(matrix, aspect="auto", cmap="Blues", vmin=0, vmax=np.nanmax(matrix))
    axes[1].set_xticks(np.arange(len(ply_labels)), ply_labels, rotation=35, ha="right")
    axes[1].set_yticks(np.arange(len(state_labels)), state_labels)
    axes[1].set_xlabel("Final-position ply band")
    axes[1].set_ylabel("Disconnected player's position")
    panel_title(axes[1], "B", "Board merit × game stage")
    for i in range(matrix.shape[0]):
        for j in range(matrix.shape[1]):
            color = "white" if matrix[i, j] > 0.58 * np.nanmax(matrix) else INK
            axes[1].text(j, i, f"{matrix[i, j]:.1f}", ha="center", va="center", fontsize=5.8, color=color)
    colorbar = fig.colorbar(im, ax=axes[1], fraction=0.035, pad=0.025)
    colorbar.set_label("Kind-draw rate (%)", fontsize=7)
    add_note(fig, "Source: certified Stage 07, Nov. 2023–Oct. 2025, Stockfish 18 at 100,000 nodes. Cells show raw percentages.")
    save_figure(fig, output, "figure_1_structure", wspace=0.48)
    return True, f"F1 rendered from {source}"


def render_f2(input_dir: Path, output: Path) -> tuple[bool, str]:
    local_path = find_table(input_dir, "f2_local")
    curve_path = find_table(input_dir, "f2_curve")
    if local_path is None or curve_path is None:
        missing = [name for name, path in (("f2_local", local_path), ("f2_curve", curve_path)) if path is None]
        return False, "F2 missing " + ", ".join(missing)
    local = read_table(local_path)
    curve = read_table(curve_path)
    if not {"rating_gap", "estimate_pp"}.issubset(local.columns):
        return False, "F2 local schema missing rating_gap/estimate_pp"
    if not {"rating_gap", "estimate_pp", "board_band"}.issubset(curve.columns):
        return False, "F2 curve schema missing rating_gap/estimate_pp/board_band"
    if local["rating_gap"].nunique() < 20:
        return False, "F2 local panel has fewer than 20 unique local gaps"
    if "variant" in curve.columns:
        preferred = curve[curve["variant"].astype(str).str.lower().isin({"primary_k20", "k20", "primary"})]
        if not preferred.empty:
            curve = preferred
    if "sample" in curve.columns:
        preferred = curve[curve["sample"].astype(str).str.lower().str.contains("gt_10|>10|plygt10", regex=True)]
        if not preferred.empty:
            curve = preferred
    if "plot_ok" in curve.columns:
        curve = curve[curve["plot_ok"].astype(bool)]

    fig, axes = plt.subplots(1, 2, figsize=(7.25, 3.35), gridspec_kw={"width_ratios": [0.8, 1.7]})
    local = local.sort_values("rating_gap")
    axes[0].axhline(0, color=INK, lw=0.8)
    bounds = error_bounds(local)
    if bounds:
        low, high = bounds
        axes[0].errorbar(local["rating_gap"], local["estimate_pp"],
                         yerr=[local["estimate_pp"] - low, high - local["estimate_pp"]],
                         fmt="o", color=BLUE, ecolor=BLUE, ms=3, lw=0.8, capsize=1.5)
    else:
        axes[0].scatter(local["rating_gap"], local["estimate_pp"], color=BLUE, s=12)
    axes[0].set_xlabel("Disconnected player − chooser\n(exact Elo gap)")
    axes[0].set_ylabel("Difference (pp)")
    clean_axes(axes[0])
    panel_title(axes[0], "A", "Locally flat around equality")

    axes[1].axhline(0, color=INK, lw=0.8)
    axes[1].axvline(0, color=GRAY, lw=0.7, ls="--")
    ordered_bands = list(dict.fromkeys(curve["board_band"].astype(str).tolist()))
    colors = [BLUE, TEAL, ORANGE]
    for color, band in zip(colors, ordered_bands[:3]):
        subset = curve[curve["board_band"].astype(str) == band].sort_values("rating_gap")
        axes[1].plot(subset["rating_gap"], subset["estimate_pp"], color=color, marker="o", ms=2.5, lw=1.3, label=band)
        bounds = error_bounds(subset)
        if bounds:
            axes[1].fill_between(subset["rating_gap"], bounds[0], bounds[1], color=color, alpha=0.13, linewidth=0)
    axes[1].set_xlim(-375, 375)
    axes[1].set_xlabel("Disconnected player rating − chooser rating (Elo)")
    axes[1].set_ylabel("Adjusted kind-draw difference (pp)")
    clean_axes(axes[1])
    panel_title(axes[1], "B", "Relative strength when accommodation is live")
    axes[1].legend(title="Final board evaluation", title_fontsize=7, loc="upper left")
    add_note(
        fig,
        "Panel A: all games; exact-gap estimates versus −1 Elo, with chooser/month FE and current-state + ply-band controls.\n"
        "Panel B: ply > 10; omitted −25 to +25 Elo bin; chooser-FE K20 model with month, speed, ply, within-band evaluation, and premium controls; chooser-clustered 95% CIs.",
    )
    save_figure(fig, output, "figure_2_relative_strength", bottom=0.24)
    return True, f"F2 rendered from {local_path} and {curve_path}"


def render_f3(input_dir: Path, output: Path) -> tuple[bool, str]:
    split_path = find_table(input_dir, "f3_split")
    forward_path = find_table(input_dir, "f3_forward")
    hist_path = find_table(input_dir, "f3_fe_hist")
    if split_path is None or forward_path is None:
        missing = [name for name, path in (("f3_split", split_path), ("f3_forward", forward_path)) if path is None]
        return False, "F3 missing " + ", ".join(missing)
    split = read_table(split_path)
    forward = read_table(forward_path)
    if not {"split", "metric", "value"}.issubset(split.columns) or not {"prior_group", "rate_pct"}.issubset(forward.columns):
        return False, "F3 schema failure"
    use_hist = hist_path is not None
    ncols = 3 if use_hist else 2
    widths = [1.35, 0.8, 1.1] if use_hist else [1.35, 0.8]
    fig, axes = plt.subplots(1, ncols, figsize=(7.25, 3.25), gridspec_kw={"width_ratios": widths})
    metrics = list(dict.fromkeys(split["metric"].astype(str).tolist()))
    x = np.arange(len(metrics))
    splits = list(dict.fromkeys(split["split"].astype(str).tolist()))
    width = 0.7 / max(1, len(splits))
    for idx, (label, color) in enumerate(zip(splits, [BLUE, ORANGE, TEAL])):
        values = []
        for metric in metrics:
            cell = split[(split["split"].astype(str) == label) & (split["metric"].astype(str) == metric)]
            values.append(float(cell.iloc[0]["value"]) if not cell.empty else np.nan)
        axes[0].bar(x + (idx - (len(splits) - 1) / 2) * width, values, width, color=color, label=label, zorder=3)
    axes[0].set_xticks(x, metrics, rotation=15, ha="right")
    axes[0].set_ylabel("First-/second-half correlation")
    axes[0].set_ylim(0, max(0.8, 1.1 * np.nanmax(split["value"])))
    clean_axes(axes[0])
    panel_title(axes[0], "A", "Split-half persistence")
    axes[0].legend()

    forward = forward.copy()
    bars = axes[1].bar(forward["prior_group"], forward["rate_pct"], color=["#AAB2BD", TEAL][:len(forward)], zorder=3)
    axes[1].tick_params(axis="x", rotation=15)
    axes[1].set_ylabel("Later kind-draw rate")
    pct_axis(axes[1], 1)
    clean_axes(axes[1])
    panel_title(axes[1], "B", "Forward prediction")
    for bar, value in zip(bars, forward["rate_pct"]):
        axes[1].text(bar.get_x() + bar.get_width() / 2, value + 0.03 * max(forward["rate_pct"]), f"{value:.2f}%", ha="center", fontsize=6.5)
    if len(forward) == 2 and float(forward["rate_pct"].min()) > 0:
        ratio = float(forward["rate_pct"].max() / forward["rate_pct"].min())
        axes[1].text(0.5, 0.78, f"{ratio:.1f}×", transform=axes[1].transAxes,
                     ha="center", fontsize=9.5, fontweight="bold", color=TEAL, zorder=6,
                     bbox={"facecolor": "white", "edgecolor": "none", "alpha": 0.88, "pad": 1.0})

    if use_hist:
        hist = read_table(hist_path)
        if {"bin_left", "bin_right"}.issubset(hist.columns) and ("share_pct" in hist.columns or "count" in hist.columns):
            values = hist["share_pct"] if "share_pct" in hist.columns else 100 * hist["count"] / hist["count"].sum()
            centers = (hist["bin_left"] + hist["bin_right"]) / 2
            widths_hist = hist["bin_right"] - hist["bin_left"]
            axes[2].bar(centers, values, width=widths_hist, color=PURPLE, zorder=3)
            axes[2].set_xlabel("Estimated chooser effect")
            axes[2].set_ylabel("Share of choosers")
            pct_axis(axes[2], 0)
            clean_axes(axes[2])
            panel_title(axes[2], "C", "Zero-inflated chooser effects")
    add_note(fig, "Fair/competitive timeout opportunities. Persistence is descriptive stable heterogeneity, not a recovered moral type or a causal effect of prior kindness.")
    save_figure(fig, output, "figure_3_persistence")
    return True, f"F3 rendered from {split_path}, {forward_path}" + (f", {hist_path}" if hist_path else "")


def render_a1(input_dir: Path, output: Path) -> tuple[bool, str]:
    support_path = find_table(input_dir, "f1_state_ply")
    comparison_path = find_table(input_dir, "a1_year_engine")
    if support_path is None or comparison_path is None:
        missing = [name for name, path in (("f1_state_ply", support_path),
                                           ("a1_year_engine", comparison_path)) if path is None]
        return False, "A1 missing " + ", ".join(missing)
    support = read_table(support_path)
    comparison = read_table(comparison_path)
    support_required = {"state_order", "state", "ply_order", "ply_band", "n"}
    comparison_required = {"sample_order", "sample", "state_order", "state", "n", "kind_draws", "rate_pct"}
    if not support_required.issubset(support.columns):
        return False, f"A1 support schema missing {sorted(support_required - set(support.columns))}"
    if not comparison_required.issubset(comparison.columns):
        return False, f"A1 comparison schema missing {sorted(comparison_required - set(comparison.columns))}"
    if len(support) != 40 or comparison["sample"].nunique() < 2:
        return False, "A1 requires the complete 5×8 grid and at least two authenticated sample/engine series"

    support = support.sort_values(["state_order", "ply_order"])
    state_key = support[["state_order", "state"]].drop_duplicates()
    ply_key = support[["ply_order", "ply_band"]].drop_duplicates()
    if (
        len(state_key) != 5
        or state_key["state_order"].duplicated().any()
        or len(ply_key) != 8
        or ply_key["ply_order"].duplicated().any()
    ):
        return False, "A1 support labels are not one-to-one with their frozen order keys"
    state_key = state_key.sort_values("state_order")
    ply_key = ply_key.sort_values("ply_order")
    state_orders = state_key["state_order"].astype(int).tolist()
    state_labels = state_key["state"].tolist()
    ply_orders = ply_key["ply_order"].astype(int).tolist()
    ply_labels = ply_key["ply_band"].tolist()
    pivot = support.pivot(index="state_order", columns="ply_order", values="n").reindex(
        index=state_orders, columns=ply_orders
    )
    if pivot.isna().any().any() or (pivot.to_numpy(float) <= 0).any():
        return False, "A1 support grid contains missing or nonpositive cells"
    matrix = pivot.to_numpy(float)

    expected_orders = set(state_orders)
    for sample, cells in comparison.groupby("sample", sort=False):
        if cells["state_order"].duplicated().any() or set(cells["state_order"].astype(int)) != expected_orders:
            return False, f"A1 comparison series is incomplete or duplicated: {sample}"
        rates = cells["rate_pct"].to_numpy(float)
        counts = 100.0 * cells["kind_draws"].to_numpy(float) / cells["n"].to_numpy(float)
        if not np.isfinite(rates).all() or not np.allclose(rates, counts, rtol=0, atol=0.002):
            return False, f"A1 comparison rates are nonfinite or inconsistent with counts: {sample}"

    fig, axes = plt.subplots(1, 2, figsize=(7.25, 3.35), gridspec_kw={"width_ratios": [1.45, 1.05]})
    im = axes[0].imshow(np.log10(matrix), aspect="auto", cmap="YlGnBu")
    axes[0].set_xticks(np.arange(len(ply_labels)), ply_labels, rotation=35, ha="right")
    axes[0].set_yticks(np.arange(len(state_labels)), state_labels)
    axes[0].set_xlabel("Final-position ply band")
    panel_title(axes[0], "A", "Support across board merit and game stage")
    for i in range(matrix.shape[0]):
        for j in range(matrix.shape[1]):
            value = matrix[i, j]
            label = f"{value / 1e6:.1f}m" if value >= 1_000_000 else f"{value / 1e3:.0f}k"
            color = "white" if np.log10(value) > np.nanmin(np.log10(matrix)) + 0.63 * np.ptp(np.log10(matrix)) else INK
            axes[0].text(j, i, label, ha="center", va="center", fontsize=5.5, color=color)
    cbar = fig.colorbar(im, ax=axes[0], fraction=0.035, pad=0.025)
    cbar.set_label("log10 opportunities", fontsize=7)

    comparison = comparison.sort_values(["sample_order", "state_order"])
    x = np.arange(len(state_labels))
    for (sample, cells), color, marker in zip(comparison.groupby("sample", sort=False),
                                               [BLUE, ORANGE, TEAL, PURPLE], ["o", "s", "^", "D"]):
        # The historical authority uses verbose state labels while the Stage 07
        # support grid uses short display labels.  The integer order key is the
        # frozen cross-source join; joining on label text silently produced an
        # all-NaN series in v1.0.1.
        cells = cells.set_index("state_order").reindex(state_orders)
        rates = cells["rate_pct"].to_numpy(float)
        axes[1].plot(x, rates, color=color, marker=marker, lw=1.5, ms=3.8, label=sample)
    axes[1].set_xticks(x, state_labels, rotation=30, ha="right")
    axes[1].set_ylabel("Kind-draw rate")
    axes[1].set_ylim(0, 1.12 * float(comparison["rate_pct"].max()))
    pct_axis(axes[1], 1)
    clean_axes(axes[1])
    panel_title(axes[1], "B", "Year/engine comparison")
    axes[1].legend(loc="upper right")
    add_note(fig, "Panel A uses the certified 24-month/100k Stage 07 grid. Panel B may include the historical 10k predecessor only under its original authenticated label; it is not relabeled as current evidence.")
    save_figure(fig, output, "appendix_A1_structure_support", wspace=0.48, bottom=0.23)
    return True, f"A1 rendered from {support_path} and {comparison_path}"


def render_f4(input_dir: Path, output: Path) -> tuple[bool, str]:
    raw_path = find_table(input_dir, "f4_raw")
    horizon_path = find_table(input_dir, "f4_horizon")
    if raw_path is None or horizon_path is None:
        missing = [name for name, path in (("f4_raw", raw_path), ("f4_horizon", horizon_path)) if path is None]
        return False, "F4 missing " + ", ".join(missing)
    raw = read_table(raw_path)
    horizon = read_table(horizon_path)
    if not {"relationship", "rate_pct"}.issubset(raw.columns):
        return False, "F4 raw schema failure"
    if not {"horizon_order", "horizon", "relationship", "rate_pct"}.issubset(horizon.columns):
        return False, "F4 horizon schema failure"

    fig, axes = plt.subplots(1, 2, figsize=(7.25, 3.3), gridspec_kw={"width_ratios": [0.9, 1.4]})
    colors = ["#AAB2BD", ORANGE, TEAL]
    raw_labels = [
        str(value).replace("Ordinary re-encounter", "Ordinary\nre-encounter")
        .replace("Prior claimer", "Prior\nclaimer")
        .replace("Prior benefactor", "Prior\nbenefactor")
        for value in raw["relationship"]
    ]
    raw_x = np.arange(len(raw))
    bars = axes[0].bar(raw_x, raw["rate_pct"], color=colors[:len(raw)], zorder=3)
    axes[0].set_xticks(raw_x, raw_labels)
    axes[0].set_ylabel("Kind-draw rate")
    pct_axis(axes[0], 0)
    clean_axes(axes[0])
    panel_title(axes[0], "A", "Targeted raw rates")
    for bar, value in zip(bars, raw["rate_pct"]):
        axes[0].text(bar.get_x() + bar.get_width() / 2, value + 0.02 * max(raw["rate_pct"]), f"{value:.1f}%", ha="center", fontsize=6.5)
    for relationship, color in (("Prior benefactor", TEAL), ("Prior claimer", ORANGE)):
        subset = horizon[horizon["relationship"].astype(str) == relationship].sort_values("horizon_order")
        if subset.empty:
            continue
        axes[1].plot(subset["horizon_order"], subset["rate_pct"], color=color, marker="o", lw=1.7, label=relationship)
        axes[1].set_xticks(subset["horizon_order"], subset["horizon"])
    axes[1].set_xlabel("Time since prior encounter")
    axes[1].set_ylabel("Kind-draw rate")
    pct_axis(axes[1], 0)
    clean_axes(axes[1])
    panel_title(axes[1], "B", "The targeted gap remains large")
    axes[1].legend()
    axes[1].text(0.02, 0.03, "Exploratory / outcome-informed / post-gate",
                 transform=axes[1].transAxes, fontsize=6.3, color=RED, fontweight="bold",
                 bbox={"facecolor": "white", "edgecolor": "none", "alpha": 0.8, "pad": 1.5})
    add_note(fig, "C7X full-panel extension. The prespecified support gate failed; estimates are conditional on re-encounter and outside the confirmatory Holm family.")
    save_figure(fig, output, "figure_4_targeted_memory", bottom=0.22)
    return True, f"F4 rendered from {raw_path} and {horizon_path}"


def render_a7(input_dir: Path, output: Path) -> tuple[bool, str]:
    source = find_table(input_dir, "a7_patron_five_bin")
    if source is None:
        return False, "A7 missing a7_patron_five_bin"
    frame = read_table(source).sort_values("state_order")
    if not {"state", "estimate_pp", "se_pp"}.issubset(frame.columns):
        return False, "A7 schema failure"
    y = np.arange(len(frame))
    fig, ax = plt.subplots(figsize=(5.8, 3.35))
    ax.axvline(0, color=INK, lw=0.8)
    ax.errorbar(frame["estimate_pp"], y, xerr=1.96 * frame["se_pp"], fmt="o", color=BLUE,
                ecolor=BLUE, capsize=2.5, lw=1.1, ms=4.2)
    ax.set_yticks(y, frame["state"])
    ax.invert_yaxis()
    ax.set_xlabel("Association with current Patron status (pp)")
    ax.set_ylabel("Disconnected player's position")
    clean_axes(ax, "x")
    panel_title(ax, "", "Patron association by state")
    if {"endpoint_difference_pp", "endpoint_p_value"}.issubset(frame.columns):
        difference = float(frame["endpoint_difference_pp"].iloc[0])
        p_value = float(frame["endpoint_p_value"].iloc[0])
        ax.text(0.98, 0.05, f"Endpoint contrast: {difference:+.3f} pp\nHC1 p={p_value:.4g}",
                transform=ax.transAxes, ha="right", va="bottom", fontsize=7, color=GRAY)
    support_text = ""
    if {"support_users", "support_patrons", "support_match_cells"}.issubset(frame.columns):
        support_text = (f" N={int(frame['support_users'].iloc[0]):,}; "
                        f"{int(frame['support_patrons'].iloc[0]):,} Patrons; "
                        f"{int(frame['support_match_cells'].iloc[0])} cells.")
    add_note(fig, "Chooser-level simultaneous min-4 five-bin model; 95% HC1 CIs." + support_text +
             " Current Patron status is cross-sectional; adjacent differences are not uniformly significant.")
    save_figure(fig, output, "appendix_A7_patron_five_bin")
    return True, f"A7 rendered from {source}"


def render_a2(input_dir: Path, output: Path) -> tuple[bool, str]:
    corr_path = find_table(input_dir, "a2_krd_correlations")
    if corr_path is None:
        return False, "A2 missing a2_krd_correlations"
    corr = read_table(corr_path).sort_values("measure_order")
    if not {"measure", "value"}.issubset(corr.columns):
        return False, "A2 correlation schema failure"
    fig, ax = plt.subplots(figsize=(6.25, 3.25))
    y = np.arange(len(corr))
    colors = [BLUE if value >= 0 else RED for value in corr["value"]]
    ax.barh(y, corr["value"], color=colors, zorder=3)
    ax.set_yticks(y, corr["measure"])
    ax.invert_yaxis()
    ax.axvline(0, color=INK, lw=0.8)
    ax.set_xlabel("Correlation")
    clean_axes(ax, "x")
    panel_title(ax, "", "Draw-payoff magnitude mixes rating distance and update scale")
    for yi, value in enumerate(corr["value"]):
        ax.text(value + (0.015 if value >= 0 else -0.015), yi, f"{value:.3f}",
                va="center", ha="left" if value >= 0 else "right", fontsize=6.5)
    add_note(fig, "Appendix forensic diagnostic. Draw payoff is K(0.5−E); the figure does not identify a causal price response.")
    save_figure(fig, output, "appendix_A2_payoff_krd_decomposition")
    return True, f"A2 rendered from {corr_path}"


def render_a3(input_dir: Path, output: Path) -> tuple[bool, str]:
    curve_path = find_table(input_dir, "f2_curve")
    if curve_path is None:
        return False, "A3 missing f2_curve"
    curve = read_table(curve_path)
    if not {"rating_gap", "estimate_pp", "board_band", "variant"}.issubset(curve.columns):
        return False, "A3 requires f2_curve variants"
    variants = list(dict.fromkeys(curve["variant"].astype(str).tolist()))
    if len(variants) < 2:
        return False, "A3 needs at least two authenticated robustness variants"
    bands = list(dict.fromkeys(curve["board_band"].astype(str).tolist()))
    preferred_band = next((band for band in bands if "100" in band and ("−100" in band or "-100" in band)), bands[0])
    subset = curve[curve["board_band"].astype(str) == preferred_band]
    if "sample" in subset.columns:
        selected = subset[subset["sample"].astype(str).str.lower().str.contains("gt_10|>10|plygt10", regex=True)]
        if not selected.empty:
            subset = selected
    fig, ax = plt.subplots(figsize=(6.5, 3.45))
    ax.axhline(0, color=INK, lw=0.8)
    ax.axvline(0, color=GRAY, lw=0.7, ls="--")
    for variant, color, marker in zip(variants[:5], [BLUE, ORANGE, TEAL, PURPLE, RED], ["o", "s", "^", "D", "v"]):
        cells = subset[subset["variant"].astype(str) == variant].sort_values("rating_gap")
        if cells.empty:
            continue
        ax.plot(cells["rating_gap"], cells["estimate_pp"], color=color, marker=marker,
                ms=2.6, lw=1.1, label=variant)
    ax.set_xlim(-375, 375)
    ax.set_xlabel("Disconnected player rating − chooser rating (Elo)")
    ax.set_ylabel("Adjusted kind-draw difference (pp)")
    clean_axes(ax)
    panel_title(ax, "", f"Relative-strength robustness; board evaluation {preferred_band}")
    ax.legend(ncol=2, loc="upper left")
    add_note(fig, "Year 2 may be plotted only after rebuilding month fixed effects with an omitted month inside the Year-2 sample.")
    save_figure(fig, output, "appendix_A3_relative_strength_robustness")
    return True, f"A3 rendered from {curve_path}"


def render_a4(input_dir: Path, output: Path) -> tuple[bool, str]:
    forest_path = find_table(input_dir, "a1_receipt_forest")
    horizon_path = find_table(input_dir, "a1_receipt_horizon")
    if forest_path is None or horizon_path is None:
        missing = [name for name, path in (("a1_receipt_forest", forest_path), ("a1_receipt_horizon", horizon_path)) if path is None]
        return False, "A4 missing " + ", ".join(missing)
    forest = read_table(forest_path).sort_values("spec_order")
    horizon = read_table(horizon_path).sort_values("horizon_order")
    if not {"spec", "estimate_pp"}.issubset(forest.columns) or not {"horizon", "estimate_pp"}.issubset(horizon.columns):
        return False, "A4 schema failure"
    fig, axes = plt.subplots(1, 2, figsize=(7.25, 3.3), gridspec_kw={"width_ratios": [1.15, 1.1]})
    y = np.arange(len(forest))
    axes[0].axvline(0, color=INK, lw=0.8)
    bounds = error_bounds(forest)
    if bounds:
        axes[0].errorbar(forest["estimate_pp"], y,
                         xerr=[forest["estimate_pp"] - bounds[0], bounds[1] - forest["estimate_pp"]],
                         fmt="o", color=BLUE, ecolor=BLUE, capsize=2, lw=1.0, ms=3.8)
    else:
        axes[0].scatter(forest["estimate_pp"], y, color=BLUE, s=20)
    axes[0].set_yticks(y, forest["spec"])
    axes[0].invert_yaxis()
    axes[0].set_xlabel("Mercy-minus-claim estimate (pp)")
    clean_axes(axes[0], "x")
    panel_title(axes[0], "A", "Next-opportunity estimates")
    axes[1].axhline(0, color=INK, lw=0.8)
    horizon_bounds = error_bounds(horizon)
    if horizon_bounds:
        axes[1].errorbar(horizon["horizon_order"], horizon["estimate_pp"],
                         yerr=[horizon["estimate_pp"] - horizon_bounds[0],
                               horizon_bounds[1] - horizon["estimate_pp"]],
                         color=BLUE, marker="o", lw=1.5, ms=3.8, capsize=2.2)
    else:
        axes[1].plot(horizon["horizon_order"], horizon["estimate_pp"], color=BLUE, marker="o", lw=1.7)
    axes[1].set_xticks(horizon["horizon_order"], horizon["horizon"], rotation=25, ha="right")
    axes[1].set_xlabel("Time to next opportunity")
    axes[1].set_ylabel("Mercy-minus-claim estimate (pp)")
    clean_axes(axes[1])
    panel_title(axes[1], "B", "Broad attenuation with time")
    add_note(fig, "Conditional next-opportunity design. Receipt is not described as experimentally randomized; full balance, pretrend, and censoring checks appear in the appendix tables.")
    save_figure(fig, output, "appendix_A4_receipt_dynamics")
    return True, f"A4 rendered from {forest_path} and {horizon_path}"


def render_a5(input_dir: Path, output: Path) -> tuple[bool, str]:
    b2_path = find_table(input_dir, "a5_b2")
    c9_path = find_table(input_dir, "a5_c9")
    if b2_path is None or c9_path is None:
        missing = [name for name, path in (("a5_b2", b2_path), ("a5_c9", c9_path)) if path is None]
        return False, "A5 missing " + ", ".join(missing)
    b2 = read_table(b2_path).sort_values("horizon_order")
    c9 = read_table(c9_path).sort_values("contrast_order")
    if not {"horizon", "observed_pct", "benchmark_pct"}.issubset(b2.columns) or not {"contrast", "excess_pp"}.issubset(c9.columns):
        return False, "A5 schema failure"
    fig, axes = plt.subplots(1, 2, figsize=(7.25, 3.25))
    axes[0].plot(b2["horizon_order"], b2["observed_pct"], color=TEAL, marker="o", lw=1.8, label="Observed")
    axes[0].plot(b2["horizon_order"], b2["benchmark_pct"], color=GRAY, marker="o", lw=1.5, ls="--", label="Randomization benchmark")
    axes[0].set_xticks(b2["horizon_order"], b2["horizon"])
    axes[0].set_ylabel("Probability of another grant")
    pct_axis(axes[0], 0)
    clean_axes(axes[0])
    panel_title(axes[0], "A", "B2: grants cluster in time")
    axes[0].legend()
    bars = axes[1].bar(c9["contrast"], c9["excess_pp"], color=[BLUE, PURPLE, TEAL, ORANGE][:len(c9)], zorder=3)
    axes[1].tick_params(axis="x", rotation=18)
    axes[1].set_ylabel("Excess over randomization benchmark (pp)")
    clean_axes(axes[1])
    panel_title(axes[1], "B", "C9: episodes cross sessions")
    for bar, value in zip(bars, c9["excess_pp"]):
        axes[1].text(bar.get_x() + bar.get_width() / 2, value + 0.03 * max(c9["excess_pp"]), f"{value:.1f}", ha="center", fontsize=6.5)
    if "epistemic_label" in c9.columns:
        for bar, label in zip(bars, c9["epistemic_label"]):
            display_label = {"C": "Primary", "S": "Secondary"}.get(str(label), str(label))
            axes[1].text(bar.get_x() + bar.get_width() / 2, 0.35, display_label,
                         ha="center", va="bottom", rotation=90, fontsize=5.3,
                         color="white", fontweight="bold")
    add_note(fig, "Exact conditional-randomization designs. They reject exchangeability of event timing but do not identify a causal effect of one grant on the next.")
    save_figure(fig, output, "appendix_A5_episode_dynamics")
    return True, f"A5 rendered from {b2_path} and {c9_path}"


def render_a6(input_dir: Path, output: Path) -> tuple[bool, str]:
    matched_path = find_table(input_dir, "a6_patron_matched")
    diagnostic_path = find_table(input_dir, "a6_patron_diagnostic")
    dose_path = find_table(input_dir, "a6_patron_dose")
    if matched_path is None or diagnostic_path is None or dose_path is None:
        missing = [name for name, path in (("a6_patron_matched", matched_path),
                                          ("a6_patron_diagnostic", diagnostic_path),
                                          ("a6_patron_dose", dose_path)) if path is None]
        return False, "A6 missing " + ", ".join(missing)
    matched = read_table(matched_path)
    diagnostic = read_table(diagnostic_path)
    dose = read_table(dose_path).sort_values("dose_order")
    if not {"group", "rate_pct"}.issubset(matched.columns) or not {"group", "rate_pct"}.issubset(diagnostic.columns):
        return False, "A6 matched/diagnostic schema failure"
    if not {"dose", "rate_pct"}.issubset(dose.columns):
        return False, "A6 dose schema failure"
    fig, axes = plt.subplots(1, 3, figsize=(7.25, 3.15), gridspec_kw={"width_ratios": [0.8, 1.1, 1.35]})
    matched_bars = axes[0].bar(matched["group"], matched["rate_pct"], color=["#AAB2BD", TEAL][:len(matched)], zorder=3)
    axes[0].tick_params(axis="x", rotation=18)
    axes[0].set_ylabel("Current Patron rate")
    pct_axis(axes[0], 1)
    clean_axes(axes[0])
    panel_title(axes[0], "A", "Matched rates")
    axes[0].set_ylim(0, 1.16 * matched["rate_pct"].max())
    for bar, value in zip(matched_bars, matched["rate_pct"]):
        axes[0].text(bar.get_x() + bar.get_width() / 2, value + 0.025,
                     f"{value:.3f}%", ha="center", fontsize=5.9)
    diagnostic_bars = axes[1].barh(np.arange(len(diagnostic)), diagnostic["rate_pct"], color=[RED, "#AAB2BD", BLUE, TEAL][:len(diagnostic)], zorder=3)
    diagnostic_labels = [
        str(value).replace("Clearly-worse only", "Clearly-worse\nonly")
        for value in diagnostic["group"]
    ]
    axes[1].set_yticks(np.arange(len(diagnostic)), diagnostic_labels)
    axes[1].set_xlabel("Current Patron rate")
    axes[1].xaxis.set_major_formatter(FuncFormatter(lambda value, pos: f"{value:.1f}%"))
    clean_axes(axes[1], "x")
    panel_title(axes[1], "B", "Diagnostic horse race")
    axes[1].set_xlim(0, 1.18 * diagnostic["rate_pct"].max())
    for bar, value in zip(diagnostic_bars, diagnostic["rate_pct"]):
        axes[1].text(value + 0.025, bar.get_y() + bar.get_height() / 2,
                     f"{value:.3f}%", va="center", fontsize=5.6)
    axes[2].plot(dose["dose_order"], dose["rate_pct"], color=TEAL, marker="o", lw=1.8)
    axes[2].set_xticks(dose["dose_order"], dose["dose"])
    axes[2].set_xlabel("Observed fair-state kind draws")
    axes[2].set_ylabel("Current Patron rate")
    pct_axis(axes[2], 1)
    clean_axes(axes[2])
    panel_title(axes[2], "C", "Dose and saturation")
    for x_value, y_value in zip(dose["dose_order"], dose["rate_pct"]):
        axes[2].text(x_value, y_value + 0.055, f"{y_value:.2f}%", ha="center", fontsize=5.5)
    axes[2].set_ylim(0, 1.18 * dose["rate_pct"].max())
    add_note(fig, "Current Patron status is cross-sectional. The association does not identify Patron adoption, and the 10+ bin is not evidence of strict monotonicity.")
    save_figure(fig, output, "appendix_A6_patron_bridge", wspace=0.58, bottom=0.22)
    return True, f"A6 rendered from {matched_path}, {diagnostic_path}, and {dose_path}"


def render_a9(input_dir: Path, output: Path) -> tuple[bool, str]:
    source = find_table(input_dir, "a9_clock_state")
    if source is None:
        return False, "A9 optional clock diagnostic missing a9_clock_state"
    frame = read_table(source)
    required = {"clock_bin_order", "clock_bin", "state_order", "state", "n", "kind_draws", "rate_pct"}
    if not required.issubset(frame.columns):
        return False, f"A9 schema missing {sorted(required - set(frame.columns))}"
    states = frame.sort_values("state_order")["state"].drop_duplicates().tolist()
    clocks = frame.sort_values("clock_bin_order")["clock_bin"].drop_duplicates().tolist()
    if len(states) < 2 or len(clocks) < 3:
        return False, "A9 needs at least two board states and three clock bins"
    rate = frame.pivot(index="state", columns="clock_bin", values="rate_pct").reindex(index=states, columns=clocks)
    counts = frame.pivot(index="state", columns="clock_bin", values="n").reindex(index=states, columns=clocks)
    matrix = rate.to_numpy(float)
    count_matrix = counts.to_numpy(float)
    fig, ax = plt.subplots(figsize=(6.65, 3.45))
    im = ax.imshow(matrix, aspect="auto", cmap="Blues", vmin=0, vmax=np.nanmax(matrix))
    ax.set_xticks(np.arange(len(clocks)), clocks, rotation=30, ha="right")
    ax.set_yticks(np.arange(len(states)), states)
    ax.set_xlabel("Disconnected player clock at final observation")
    panel_title(ax, "", "Board-merit gradient within clock bins")
    for i in range(matrix.shape[0]):
        for j in range(matrix.shape[1]):
            color = "white" if matrix[i, j] > 0.58 * np.nanmax(matrix) else INK
            ax.text(j, i, f"{matrix[i, j]:.2f}%\nN={count_matrix[i, j] / 1e6:.1f}m",
                    ha="center", va="center", fontsize=5.5, color=color)
    colorbar = fig.colorbar(im, ax=ax, fraction=0.035, pad=0.025)
    colorbar.set_label("Kind-draw rate (%)", fontsize=7)
    add_note(fig, "Optional live-choice diagnostic from Stage 07 aggregate cells. This checks clock composition; it does not identify a causal time-pressure effect.")
    save_figure(fig, output, "appendix_A9_clock_attribution", bottom=0.23)
    return True, f"A9 rendered from {source}"


def render_manuscript_set(input_dir: Path, output: Path) -> list[tuple[str, bool, str]]:
    results = []
    for name, renderer in (
        ("Figure 1", render_f1),
        ("Figure 2", render_f2),
        ("Figure 3", render_f3),
        ("Figure 4", render_f4),
        ("Appendix A1", render_a1),
        ("Appendix A2", render_a2),
        ("Appendix A3", render_a3),
        ("Appendix A4", render_a4),
        ("Appendix A5", render_a5),
        ("Appendix A6", render_a6),
        ("Appendix A7", render_a7),
        ("Appendix A9", render_a9),
    ):
        try:
            success, message = renderer(input_dir, output)
        except Exception as exc:
            success, message = False, f"{name} error: {type(exc).__name__}: {exc}"
        results.append((name, success, message))
    return results


def write_status(path: Path, results: list[tuple[str, bool, str]], input_dir: Path, output: Path) -> None:
    lines = [
        "# Figure-factory status",
        "",
        f"Normalized input directory: `{input_dir}`",
        f"Output directory: `{output}`",
        "",
        "| Exhibit | Status | Detail |",
        "|---|---|---|",
    ]
    for name, success, message in results:
        lines.append(f"| {name} | {'RENDERED' if success else 'BLOCKED'} | {message.replace('|', '/')} |")
    lines.extend([
        "",
        "Blocked means the renderer did not substitute memo values. Run discovery, authenticate the named aggregate source, normalize it to the contract, and rerun.",
        "",
    ])
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines), encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description="Render Lichess 100k/24m paper figures.")
    parser.add_argument("--mode", choices=("preview", "manuscript"), required=True)
    parser.add_argument("--input-dir")
    parser.add_argument("--output", required=True)
    parser.add_argument("--status")
    args = parser.parse_args()
    set_style()
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    if args.mode == "preview":
        written = render_preview_set(output)
        print(f"Rendered {len(written)} preview files in {output}")
        return 0
    if not args.input_dir:
        raise SystemExit("--input-dir is required in manuscript mode")
    results = render_manuscript_set(Path(args.input_dir), output)
    status_path = Path(args.status) if args.status else output / "STATUS.md"
    write_status(status_path, results, Path(args.input_dir), output)
    for name, success, message in results:
        print(f"{'OK' if success else 'BLOCKED'} {name}: {message}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
