# Figure Source Recovery v1.0.2

This patch supersedes v1.0.0 and v1.0.1 for manuscript use. Version 1.0.1
correctly recomputed Appendix A1 rates from authenticated integer counts, but
its renderer joined the verbose historical state labels to the short Stage 07
display labels. That label-text mismatch produced missing plotted values even
though the normalized rates were correct. Version 1.0.2 aligns the series by
their frozen integer state-order key and fails closed unless both complete
five-bin series are finite and reconcile with the authenticated counts.

The package also retains v1.0.1's panel-specific Figure 2 samples and reference
categories, Appendix A3 board-evaluation-band clarification, and label-collision
repairs in Figure 4 and Appendix A6.

This is a recovery-only renderer for the blocked exhibits from the
`20260902T163456Z` figure run. It does not estimate a regression, rescan Stage
07, call an API, install software, or write any row-level data.

It authenticates six already completed aggregate authorities by frozen
SHA-256, normalizes their schemas, copies the six previously valid plot-data
families, and renders a fresh complete required figure set.

Recovered exhibits:

- Figure 2: local displayed-gap schedule plus nonparametric relative-strength curve;
- Figure 4: targeted relationship rates and horizon profile;
- Appendix A1: historical 12m/10k versus current 24m/100k five-bin replication;
- Appendix A2: aggregate payoff/K/RD correlations;
- Appendix A3: authenticated relative-strength robustness variants.

Appendix A9 remains optional and intentionally blocked. The renderer excludes
the uncertified Year-2 curve variant. Figure 4 remains explicitly exploratory,
outcome-informed, post-gate, and conditional on re-encounter.

Expected runtime: **2–6 minutes; most likely 3–4 minutes**.
