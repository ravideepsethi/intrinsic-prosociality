# Normalized aggregate input contracts

Production inputs should be compressed Parquet. CSV is accepted for already-
authenticated public result bundles and for debugging. No row-level identifiers
are permitted in normalized plot data.

## `f1_state_ply`

Required columns:

| Column | Type | Meaning |
|---|---|---|
| `state_order` | integer 0–4 | Clearly better through clearly worse |
| `state` | string | Display label |
| `ply_order` | integer 0–7 | Ordered ply band |
| `ply_band` | string | `0–4`, `5–6`, `7–8`, `9–10`, `11–20`, `21–40`, `41–80`, `81+` |
| `n` | integer | Opportunity count |
| `kind_draws` | integer | Kind-draw count |
| `rate_pct` | float | `100 * kind_draws / n` |

The file must contain all 40 cells and sum to 47,587,020 opportunities and
669,503 kind draws.

## `f2_local`

Required: `rating_gap`, `estimate_pp`, and either `se_pp` or both `ci_low_pp`
and `ci_high_pp`. Optional: `sample` (`all`, `ply_gt_10`) and `contrast_label`.
The final main panel requires the complete −12…+12 local schedule, not only the
three contrasts summarized in prose.

## `f2_curve`

Required: `rating_gap`, `estimate_pp`, `board_band`, `variant`; plus `se_pp` or
CI bounds. `variant=primary_k20` is the main series. Optional variants include
`k50`, `stable_rd_k95`, `year_1`, and `year_2_rebuilt`. Main plotted board bands
are `−100 to +100`, `+100 to +300`, and `+300 to +600`. Rows outside adequate
support must be absent or have `plot_ok=false`.

## `f3_split`

Required: `split` (`Hash`, `Temporal`), `metric` (`Raw`,
`Opportunity-weighted`, `Harmonic-weighted`, optionally `Spearman`), `value`,
and a chooser count named `choosers` or `n_choosers`.

## `f3_forward`

Required: `prior_group`, `rate_pct`; preferred: `n`, `kind_draws`, and CI
bounds. Labels are `No prior kind draw` and `Prior kind draw`.

## `f3_fe_hist` (optional until found)

Required: `bin_left`, `bin_right`, and either `count` or `share_pct`. Must be a
disclosure-safe aggregate, not chooser-level output.

## `f4_raw`

Required: `relationship`, `rate_pct`; preferred: `n`, `kind_draws`, and CI
bounds. Ordered labels: `Ordinary re-encounter`, `Prior claimer`, `Prior
benefactor`.

## `f4_horizon`

Required: `horizon_order`, `horizon`, `relationship`, `rate_pct`; preferred:
`n`, `kind_draws`, and CI bounds. Relationships are `Prior claimer` and `Prior
benefactor`.

## Appendix contracts

- `a1_year_engine`: `sample_order`, `sample`, `state_order`, `state`, `n`,
  `kind_draws`, `rate_pct`. Appendix A1 additionally reuses the complete
  `f1_state_ply` grid. At least two explicitly authenticated sample/engine
  series are required; the historical 10k predecessor keeps its historical
  label. Normalization must derive `rate_pct = 100 * kind_draws / n`; any
  source rate field is a cross-check whose percent/proportion units must be
  detected from the integer counts. Cross-source alignment must use the frozen
  integer `state_order`, not label text: the historical authority uses verbose
  state descriptions while the Stage 07 grid uses short display labels.
- `a2_krd_correlations`: `measure_order`, `measure`, `value` for the disclosed
  correlations among absolute draw payoff, rating gap, expected-score distance,
  log K, and RDs. Optional companion `a2_k_distribution` uses `stat_order`,
  `stat`, `value`.
- `a1_receipt_forest`: `spec_order`, `spec`, `estimate_pp`, `se_pp` or CI.
- `a1_receipt_horizon`: `horizon_order`, `horizon`, `estimate_pp`, optional CI.
- `a5_b2`: `horizon_order`, `horizon`, `observed_pct`, `benchmark_pct`.
- `a5_c9`: `contrast_order`, `contrast`, `excess_pp`, optional CI.
- `a6_patron_matched`: `group`, `n`, `patrons`, `rate_pct`.
- `a6_patron_diagnostic`: `group`, `rate_pct`, preferred counts.
- `a6_patron_dose`: `dose_order`, `dose`, `users` (or `n`), `patrons`,
  `rate_pct`.
- `a7_patron_five_bin`: `state_order`, `state`, `estimate_pp`, `se_pp`;
  preferred exact metadata: endpoint contrast/SE/p-value and min-4 support
  users, Patrons, and match cells.
- `a9_clock_state` (optional): `clock_bin_order`, `clock_bin`, `state_order`,
  `state`, `n`, `kind_draws`, `rate_pct`. Inputs are aggregate Stage 07 cells;
  no row-level clock/game data enter the figure package.

## Provenance sidecar

Every normalized file must have a sibling `<stem>.provenance.json` recording:

- input path(s) and SHA-256;
- success/authentication receipt path(s) and SHA-256;
- executed script/commit hash when available;
- source sample, dates, engine version, and node budget;
- normalization script hash;
- row count and column schema;
- whether the file is `submission_ready`, `conditional`, or `preview_only`.
