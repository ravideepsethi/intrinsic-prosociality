#!/bin/bash
set -euo pipefail

PROJECT_ROOT="/Volumes/XT_Pro/lichess_kindness"
PYTHON="$PROJECT_ROOT/venv/bin/python"
SELF_DIR="$(cd "$(dirname "$0")" && pwd)"
SCRIPT="$SELF_DIR/payload/code/run_campaign1_c9_v100.py"

printf '%s\n' \
  'CAMPAIGN 1 — C9 IGNITION TRANSFER [CONFIRMATORY] (r1 authority-hash fix)' \
  'Expected runtime: approximately 2–10 hours; most likely 3–6 hours on the first run.' \
  'The 4,999 exact B2 conditional draws are checkpointed and resumable.' \
  'Uses 8 randomization workers and DuckDB 8-thread/12GB preprocessing.' \
  'No API, no Patron/profile input, no chronology rebuild, no Git mutation.' \
  ''

[[ -x "$PYTHON" ]] || { echo "ERROR: project Python missing." >&2; exit 1; }
[[ -f "$SCRIPT" ]] || { echo "ERROR: C9 producer missing." >&2; exit 1; }

export PYTHONDONTWRITEBYTECODE=1
export OPENBLAS_NUM_THREADS=1
export OMP_NUM_THREADS=1
export MKL_NUM_THREADS=1
export VECLIB_MAXIMUM_THREADS=1
export NUMEXPR_NUM_THREADS=1

printf '%s\n' 'Running C9 synthetic partition self-test...'
"$PYTHON" -B "$SCRIPT" --self-test

printf '\n%s\n' 'Starting actual C9 production...'
"$PYTHON" -B -u "$SCRIPT" \
  --project-root "$PROJECT_ROOT" \
  --threads 8 \
  --memory-limit 12GB \
  --workers 8
