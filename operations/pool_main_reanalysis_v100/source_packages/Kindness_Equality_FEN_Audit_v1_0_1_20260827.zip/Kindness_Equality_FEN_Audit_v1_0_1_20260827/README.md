# Kindness equality/FEN audit v1.0.1

This is the append-only, no-download analysis authorized by the independently
verified Gate 1 preflight on 2026-08-27.

Version 1.0.1 supersedes v1.0.0, which stopped during its synthetic gate before
any production run began. The v1.0.0 fixture mechanically assigned a constant
fairness category within chooser, leaving the chooser fixed-effect test with no
identifying variation. Version 1.0.1 repairs only synthetic QA and adds explicit
identification-support assertions. The frozen estimands are unchanged; see
`docs/IMPLEMENTATION_ERRATUM_v1_0_1.md`.

## Scientific purpose

The package determines whether the 24-month raw kindness-rate bump in roughly
equal positions survives modern within-chooser adjustment, whether it is
concentrated in games ending by ply 10, and whether it covaries with the
empirical commonness of the exact terminal chess position already retained in
Stage 07. It also audits the local kindness schedule around zero engine
evaluation: fine bins, exact zero, level and slope changes, donut exclusions,
placebo knots, temporal stability, and short-game heterogeneity.

The exact-position measures are deliberately called **FEN commonness
proxies**. They measure how often the same terminal position occurs in the
certified short-game panel. They are not ECO codes, movetext histories, or
chooser-specific prior opening familiarity. Those require the later bulk-PGN
recovery and redesigned extraction stages.

## Safety boundary

The runner:

- reads only the frozen Stage 07 panel and compact upstream authorities;
- makes no network request, Lichess API call, or PGN download;
- installs or changes no dependency;
- makes no Git mutation;
- never writes to Stage 07, Stage 08, Stage 09, or the opening-plan roots;
- builds the FEN-frequency design before loading the kindness outcome;
- keeps game IDs and design caches under a private derived-data root; and
- transfers only aggregate tables, receipts, verification, and executed
  package source.

## Inputs

Canonical project root:

```text
/Volumes/XT_Pro/lichess_kindness
```

Frozen panel:

```text
derived/replication/analysis_panel_24m_sf100k/month=YYYY-MM/analysis_panel.parquet
```

The package authenticates the Stage 07 success receipt, producer, all 24
monthly Parquet byte sizes, SHA-256 hashes, row counts, and schemas before
reading outcomes. It also authenticates the Stage 08 and Stage 09 receipts
that establish which earlier specifications are already certified.

## Outputs

Public aggregate output:

```text
/Volumes/XT_Pro/lichess_kindness/output/KINDNESS_EQUALITY_FEN_AUDIT_V101/<RUN_ID>
```

Private resumable state:

```text
/Volumes/XT_Pro/lichess_kindness/derived/private/KINDNESS_EQUALITY_FEN_AUDIT_V101/<RUN_ID>
```

Transfer files:

```text
/Users/u6025368/Desktop/Lichess_Desktop/KINDNESS_EQUALITY_FEN_AUDIT_V101_RESULTS_<RUN_ID>.zip
/Users/u6025368/Desktop/Lichess_Desktop/KINDNESS_EQUALITY_FEN_AUDIT_V101_RESULTS_<RUN_ID>.zip.sha256
```

## Runtime and resumption

Expected runtime is approximately 30–90 minutes, most likely 45–70 minutes on
the canonical machine. Full authentication of 13.16 GiB, private position
design construction, and the multi-model fixed-effect grid are checkpointed.
Rerunning the same launcher resumes the latest incomplete authenticated run.

After completion, upload the generated result ZIP and sidecar and paste the
complete terminal summary into ChatGPT.
