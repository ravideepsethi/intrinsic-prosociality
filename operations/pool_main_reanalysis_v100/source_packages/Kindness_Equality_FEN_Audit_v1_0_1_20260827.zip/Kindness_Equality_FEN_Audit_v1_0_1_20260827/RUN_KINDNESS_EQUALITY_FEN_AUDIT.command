#!/bin/bash

# macOS Bash 3.2-compatible authenticated launcher.
# This is a no-download, no-API, no-install, no-Git-mutation append-only audit.

set -euo pipefail
umask 077

task_package_root="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd -P)"
task_project_root="/Volumes/XT_Pro/lichess_kindness"
task_repo_root="${task_project_root}/replication_package"
task_desktop="/Users/u6025368/Desktop/Lichess_Desktop"
task_python="${task_project_root}/venv/bin/python"
task_public_parent="${task_project_root}/output/KINDNESS_EQUALITY_FEN_AUDIT_V101"
task_private_parent="${task_project_root}/derived/private/KINDNESS_EQUALITY_FEN_AUDIT_V101"
task_active_pointer="${task_private_parent}/ACTIVE_RUN_ID.txt"

printf '%s\n' '============================================================'
printf '%s\n' 'KINDNESS EQUALITY/FEN AUDIT v1.0.1'
printf '%s\n' '============================================================'
printf 'Expected runtime: approximately 30-90 minutes; most likely 45-70.\n'
printf 'Package: %s\n' "$task_package_root"
printf 'Project: %s\n' "$task_project_root"
printf 'Repository: %s\n' "$task_repo_root"
printf 'Transfers: %s\n\n' "$task_desktop"
printf '%s\n' 'No PGN download, Lichess API call, dependency installation, Git mutation,'
printf '%s\n' 'certified-input write, or row-level transfer occurs.'
printf '%s\n\n' 'The private design and model stages are resumable.'

[[ -d "$task_project_root" ]] || {
    printf 'ERROR: Project root is missing: %s\n' "$task_project_root" >&2
    exit 21
}
[[ -d "$task_repo_root/.git" ]] || {
    printf 'ERROR: Git repository is missing: %s\n' "$task_repo_root" >&2
    exit 22
}
[[ -x "$task_python" ]] || {
    printf 'ERROR: Canonical Python is missing: %s\n' "$task_python" >&2
    exit 23
}
[[ -f "$task_package_root/PACKAGE_MANIFEST.sha256" ]] || {
    printf 'ERROR: Package manifest is missing.\n' >&2
    exit 24
}

printf 'Authenticating every packaged source file...\n'
(
    cd "$task_package_root"
    /usr/bin/shasum -a 256 -c PACKAGE_MANIFEST.sha256
)
printf 'PACKAGE_CONTENTS_AUTHENTICATED_OK\n\n'

PYTHONDONTWRITEBYTECODE=1 "$task_python" \
    "$task_package_root/code/99_verify_package_contents.py" \
    --package-root "$task_package_root"

task_symlink_count="$(
    /usr/bin/find "$task_package_root" -type l -print |
        /usr/bin/wc -l |
        /usr/bin/tr -d ' '
)"
[[ "$task_symlink_count" == "0" ]] || {
    printf 'ERROR: Package contains symbolic links.\n' >&2
    exit 25
}

task_forbidden_count="$(
    /usr/bin/find "$task_package_root" -type f \( \
        -name '*.parquet' -o -name '*.pgn' -o -name '*.zst' -o \
        -name '*.jsonl' -o -name '*.ndjson' -o -name '*.duckdb' \
    \) -print |
        /usr/bin/wc -l |
        /usr/bin/tr -d ' '
)"
[[ "$task_forbidden_count" == "0" ]] || {
    printf 'ERROR: Package contains a forbidden row-level/private file type.\n' >&2
    exit 26
}
printf 'PACKAGE_CLEANLINESS_OK\n\n'

printf 'Running numerical and component self-tests...\n'
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 "$task_python" \
    "$task_package_root/code/00_build_position_design.py" \
    --package-root "$task_package_root" \
    --project-root "$task_project_root" \
    --private-root "$task_private_parent" \
    --public-root "$task_public_parent" \
    --self-test
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 "$task_python" \
    "$task_package_root/code/01_run_equality_fen_audit.py" \
    --package-root "$task_package_root" \
    --project-root "$task_project_root" \
    --private-root "$task_private_parent" \
    --public-root "$task_public_parent" \
    --self-test
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 "$task_python" \
    "$task_package_root/code/02_verify_equality_fen_audit.py" \
    --package-root "$task_package_root" \
    --public-root "$task_public_parent" \
    --self-test
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 "$task_python" \
    "$task_package_root/code/03_make_synthetic_fixture.py" \
    --root "$task_private_parent" \
    --self-test
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 "$task_python" \
    "$task_package_root/code/04_package_results.py" \
    --package-root "$task_package_root" \
    --public-root "$task_public_parent" \
    --transfer-root "$task_desktop" \
    --run-id SELFTEST \
    --self-test
printf '\n'

/bin/mkdir -p "$task_public_parent" "$task_private_parent" "$task_desktop"
task_selftest_id="$(/bin/date -u +%Y%m%dT%H%M%SZ)"
task_selftest_root="${task_project_root}/output/KINDNESS_EQUALITY_FEN_AUDIT_SELFTEST.${task_selftest_id}.$$"
task_selftest_fixture="${task_selftest_root}/fixture"
task_selftest_private="${task_selftest_root}/private"
task_selftest_public="${task_selftest_root}/public"
task_selftest_transfer="${task_selftest_root}/transfer"

printf 'Running end-to-end synthetic self-test...\n'
/bin/mkdir -p \
    "$task_selftest_fixture" \
    "$task_selftest_private" \
    "$task_selftest_public" \
    "$task_selftest_transfer"

PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 "$task_python" \
    "$task_package_root/code/03_make_synthetic_fixture.py" \
    --root "$task_selftest_fixture"

PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 "$task_python" \
    "$task_package_root/code/00_build_position_design.py" \
    --package-root "$task_package_root" \
    --project-root "$task_selftest_fixture" \
    --private-root "$task_selftest_private" \
    --public-root "$task_selftest_public" \
    --synthetic

PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 "$task_python" \
    "$task_package_root/code/01_run_equality_fen_audit.py" \
    --package-root "$task_package_root" \
    --project-root "$task_selftest_fixture" \
    --private-root "$task_selftest_private" \
    --public-root "$task_selftest_public" \
    --synthetic

PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 "$task_python" \
    "$task_package_root/code/02_verify_equality_fen_audit.py" \
    --package-root "$task_package_root" \
    --public-root "$task_selftest_public" \
    --synthetic

PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 "$task_python" \
    "$task_package_root/code/04_package_results.py" \
    --package-root "$task_package_root" \
    --public-root "$task_selftest_public" \
    --transfer-root "$task_selftest_transfer" \
    --run-id "$task_selftest_id" \
    --synthetic

printf 'KINDNESS_EQUALITY_FEN_END_TO_END_SYNTHETIC_SELFTEST_OK\n'
printf 'Synthetic self-test retained at: %s\n\n' "$task_selftest_root"

task_run_id=""
if [[ -f "$task_active_pointer" ]]; then
    task_candidate="$(
        /usr/bin/sed -n '1p' "$task_active_pointer" |
            /usr/bin/tr -d '[:space:]'
    )"
    if [[ "$task_candidate" =~ ^[0-9]{8}T[0-9]{6}Z$ ]]; then
        task_candidate_public="${task_public_parent}/${task_candidate}"
        if [[ ! -f "${task_candidate_public}/_SUCCESS.json" ]]; then
            task_run_id="$task_candidate"
            printf 'Resuming incomplete authenticated run: %s\n' "$task_run_id"
        fi
    else
        printf 'ERROR: Active-run pointer is malformed: %s\n' "$task_active_pointer" >&2
        exit 27
    fi
fi

if [[ -z "$task_run_id" ]]; then
    task_run_id="$(/bin/date -u +%Y%m%dT%H%M%SZ)"
    task_pointer_tmp="${task_active_pointer}.tmp.$$"
    printf '%s\n' "$task_run_id" > "$task_pointer_tmp"
    /bin/mv "$task_pointer_tmp" "$task_active_pointer"
    printf 'Starting new authenticated run: %s\n' "$task_run_id"
fi

task_public_root="${task_public_parent}/${task_run_id}"
task_private_root="${task_private_parent}/${task_run_id}"
/bin/mkdir -p "$task_public_root" "$task_private_root"

printf 'Public aggregate root: %s\n' "$task_public_root"
printf 'Private resumable root: %s\n\n' "$task_private_root"

printf 'Building or authenticating outcome-blind position design...\n'
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 "$task_python" \
    "$task_package_root/code/00_build_position_design.py" \
    --package-root "$task_package_root" \
    --project-root "$task_project_root" \
    --private-root "$task_private_root" \
    --public-root "$task_public_root"

printf '\nRunning or resuming equality/FEN outcome analysis...\n'
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 "$task_python" \
    "$task_package_root/code/01_run_equality_fen_audit.py" \
    --package-root "$task_package_root" \
    --project-root "$task_project_root" \
    --private-root "$task_private_root" \
    --public-root "$task_public_root"

printf '\nRunning independent aggregate verifier...\n'
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 "$task_python" \
    "$task_package_root/code/02_verify_equality_fen_audit.py" \
    --package-root "$task_package_root" \
    --public-root "$task_public_root"

printf '\nRechecking executed-source cleanliness before transfer...\n'
(
    cd "$task_package_root"
    /usr/bin/shasum -a 256 -c PACKAGE_MANIFEST.sha256
)
PYTHONDONTWRITEBYTECODE=1 "$task_python" \
    "$task_package_root/code/99_verify_package_contents.py" \
    --package-root "$task_package_root"

printf '\nBuilding aggregate-only transfer ZIP...\n'
PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 "$task_python" \
    "$task_package_root/code/04_package_results.py" \
    --package-root "$task_package_root" \
    --public-root "$task_public_root" \
    --transfer-root "$task_desktop" \
    --run-id "$task_run_id"

printf '\n%s\n' '============================================================'
printf '%s\n' 'KINDNESS EQUALITY/FEN AUDIT CERTIFIED COMPLETE'
printf '%s\n' '============================================================'
PYTHONDONTWRITEBYTECODE=1 "$task_python" - "$task_public_root/_SUCCESS.json" <<'PY'
import json
import sys

value = json.load(open(sys.argv[1], "r", encoding="utf-8"))
raw = value["raw_bump"]
adjusted = value["adjusted_bump"]
short = value["short_game_concentration"]
slope = value["engine_zero_placebo_uniqueness"][
    "derivative_change_right_plus_left_distance"
]
level = value["engine_zero_placebo_uniqueness"][
    "strict_positive_level_shift_pp"
]
print("Status: " + value["status"])
print(
    "Raw roughly-equal minus disconnected-better (pp): "
    + str(raw["estimate_pp"])
    + " [t="
    + str(raw["t"])
    + "]"
)
print(
    "Adjusted roughly-equal coefficient (pp): "
    + str(adjusted["estimate_pp"])
    + " [t="
    + str(adjusted["t"])
    + "]"
)
print(
    "Adjusted bump detected under frozen rule: "
    + str(adjusted["detected_under_frozen_rule"]).upper()
)
print(
    "Equality x ply<=10 interaction (pp): "
    + str(short["interaction_pp"])
    + " [t="
    + str(short["t"])
    + "]"
)
print(
    "Short-game concentration detected under frozen rule: "
    + str(short["detected_under_frozen_rule"]).upper()
)
print(
    "Engine-zero slope change descriptively unique after Holm: "
    + str(slope["descriptively_unique_under_frozen_rule"]).upper()
)
print(
    "Engine-zero level shift descriptively unique after Holm: "
    + str(level["descriptively_unique_under_frozen_rule"]).upper()
)
print("Position commonness interpretation: terminal-FEN proxy only; no causal claim.")
print("Rating-payoff-zero next package: " + value["rating_payoff_zero_next"])
PY
printf 'Public aggregate root: %s\n' "$task_public_root"
printf 'Private resumable root: %s\n' "$task_private_root"
printf 'Synthetic self-test root: %s\n' "$task_selftest_root"
printf '\nKINDNESS_EQUALITY_FEN_AUDIT_LAUNCHER_COMPLETE\n'
printf 'Upload the generated result ZIP and sidecar and paste this complete final summary into ChatGPT.\n'
