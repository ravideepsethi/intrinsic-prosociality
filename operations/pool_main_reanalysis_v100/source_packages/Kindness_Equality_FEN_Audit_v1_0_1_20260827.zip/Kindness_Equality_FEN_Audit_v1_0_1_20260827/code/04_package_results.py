#!/usr/bin/env python3
"""Create an authenticated aggregate-only transfer ZIP and SHA sidecar."""

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import os
import sys
import tempfile
import zipfile
from pathlib import Path
from typing import Any

import pandas as pd

import equality_fen_common as common


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--package-root", type=Path, required=True)
    parser.add_argument("--public-root", type=Path, required=True)
    parser.add_argument("--transfer-root", type=Path, required=True)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--synthetic", action="store_true")
    parser.add_argument("--self-test", action="store_true")
    return parser.parse_args()


def eligible_files(root: Path) -> list[Path]:
    return [
        path
        for path in sorted(root.rglob("*"))
        if path.is_file()
        and "__pycache__" not in path.parts
        and path.suffix != ".pyc"
        and not path.name.startswith(".")
    ]


def build_zip(
    package_root: Path,
    public_root: Path,
    transfer_root: Path,
    run_id: str,
    *,
    synthetic: bool,
) -> dict[str, Any]:
    common.verify_package_manifest(package_root)
    success = common.load_json(public_root / "_SUCCESS.json")
    if success.get("status") != common.PUBLIC_STATUS:
        raise RuntimeError("Public audit success receipt is missing or invalid")
    if bool(success.get("synthetic")) != bool(synthetic):
        raise RuntimeError("Synthetic/production transfer status changed")
    common.verify_report_manifest(public_root, public_root / "report_file_hashes.tsv")
    common.privacy_scan_public_output(public_root)

    transfer_root.mkdir(parents=True, exist_ok=True)
    prefix = "SYNTHETIC_" if synthetic else ""
    filename = f"{prefix}KINDNESS_EQUALITY_FEN_AUDIT_V101_RESULTS_{run_id}.zip"
    destination = transfer_root / filename
    temporary = transfer_root / f".{filename}.tmp"
    if temporary.exists():
        temporary.unlink()
    entries: list[dict[str, Any]] = []
    with zipfile.ZipFile(
        temporary,
        mode="w",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=9,
        allowZip64=True,
    ) as archive:
        for source_root, archive_root in (
            (public_root, "public_results"),
            (package_root, "executed_package_source"),
        ):
            for path in eligible_files(source_root):
                relative = path.relative_to(source_root)
                archive_name = str(Path(archive_root) / relative)
                data = path.read_bytes()
                archive.writestr(archive_name, data)
                entries.append(
                    {
                        "path": archive_name,
                        "bytes": len(data),
                        "sha256": hashlib.sha256(data).hexdigest(),
                    }
                )
        stream = io.StringIO()
        writer = csv.DictWriter(
            stream,
            fieldnames=["path", "bytes", "sha256"],
            delimiter="\t",
            lineterminator="\n",
        )
        writer.writeheader()
        writer.writerows(entries)
        manifest_bytes = stream.getvalue().encode("utf-8")
        archive.writestr("TRANSFER_MANIFEST.tsv", manifest_bytes)
    os.replace(temporary, destination)

    with zipfile.ZipFile(destination, "r") as archive:
        bad = archive.testzip()
        if bad is not None:
            raise RuntimeError(f"Transfer ZIP CRC failure: {bad}")
        names = archive.namelist()
        if len(names) != len(set(names)):
            raise RuntimeError("Transfer ZIP contains duplicate entry names")
        if "TRANSFER_MANIFEST.tsv" not in names:
            raise RuntimeError("Transfer ZIP manifest is missing")
        manifest = pd.read_csv(
            io.BytesIO(archive.read("TRANSFER_MANIFEST.tsv")), sep="\t"
        )
        if len(manifest) != len(entries):
            raise RuntimeError("Transfer ZIP manifest row count changed")
        for row in manifest.to_dict("records"):
            data = archive.read(str(row["path"]))
            if len(data) != int(row["bytes"]):
                raise RuntimeError(f"Transfer ZIP byte count changed: {row['path']}")
            if hashlib.sha256(data).hexdigest() != row["sha256"]:
                raise RuntimeError(f"Transfer ZIP entry hash changed: {row['path']}")

    digest = common.sha256_file(destination)
    sidecar = destination.with_name(destination.name + ".sha256")
    common.atomic_write_text(sidecar, f"{digest}  {destination.name}\n")
    if sidecar.read_text(encoding="utf-8") != f"{digest}  {destination.name}\n":
        raise RuntimeError("Transfer ZIP sidecar write failed")
    return {
        "status": "KINDNESS_EQUALITY_FEN_AUDIT_TRANSFER_CERTIFIED_OK",
        "zip": str(destination),
        "sidecar": str(sidecar),
        "sha256": digest,
        "bytes": destination.stat().st_size,
        "entries": len(entries) + 1,
    }


def self_test() -> None:
    with tempfile.TemporaryDirectory(prefix="equality_fen_packager_selftest_") as temp:
        root = Path(temp)
        target = root / "sample.zip"
        with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as archive:
            archive.writestr("public_results/example.json", b'{"aggregate":true}\n')
        with zipfile.ZipFile(target, "r") as archive:
            if archive.testzip() is not None:
                raise RuntimeError("Packager self-test CRC failed")
            if hashlib.sha256(archive.read("public_results/example.json")).hexdigest() == "":
                raise RuntimeError("Packager self-test hash failed")
    print("KINDNESS_EQUALITY_FEN_PACKAGER_SELFTEST_OK")


def main() -> int:
    args = parse_args()
    if args.self_test:
        self_test()
        return 0
    result = build_zip(
        args.package_root.resolve(),
        args.public_root.resolve(),
        args.transfer_root.resolve(),
        args.run_id,
        synthetic=args.synthetic,
    )
    print(result["status"])
    print(f"TRANSFER_ZIP={result['zip']}")
    print(f"TRANSFER_ZIP_SHA256={result['sha256']}")
    print(f"TRANSFER_SIDECAR={result['sidecar']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
