#!/usr/bin/env python3
"""Verify exact package inventory, hashes, and forbidden generated debris."""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

import equality_fen_common as common


EXPECTED_FILES = {
    "README.md",
    "RUN_KINDNESS_EQUALITY_FEN_AUDIT.command",
    "requirements.txt",
    "code/00_build_position_design.py",
    "code/01_run_equality_fen_audit.py",
    "code/02_verify_equality_fen_audit.py",
    "code/03_make_synthetic_fixture.py",
    "code/04_package_results.py",
    "code/99_verify_package_contents.py",
    "code/equality_fen_common.py",
    "docs/ANALYSIS_PLAN_v1_0_0.md",
    "docs/IMPLEMENTATION_ERRATUM_v1_0_1.md",
    "frozen_authorities/equality_fen_authority_contract_v1_0_1.json",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--package-root", type=Path, required=True)
    parser.add_argument("--self-test", action="store_true")
    return parser.parse_args()


def verify(root: Path) -> dict[str, object]:
    actual = {
        str(path.relative_to(root))
        for path in root.rglob("*")
        if path.is_file()
        and path.name != "PACKAGE_MANIFEST.sha256"
        and "__pycache__" not in path.parts
        and path.suffix != ".pyc"
    }
    if actual != EXPECTED_FILES:
        raise RuntimeError(
            "Exact package inventory changed; "
            f"missing={sorted(EXPECTED_FILES - actual)}; "
            f"extra={sorted(actual - EXPECTED_FILES)}"
        )
    forbidden = [
        path
        for path in root.rglob("*")
        if path.name in {".DS_Store", "__pycache__"}
        or path.suffix in {".pyc", ".pyo"}
    ]
    if forbidden:
        raise RuntimeError(f"Generated debris is present: {forbidden}")
    manifest = common.verify_package_manifest(root)
    launcher = (root / "RUN_KINDNESS_EQUALITY_FEN_AUDIT.command").read_text(
        encoding="utf-8"
    )
    forbidden_launcher = (
        r"\bpip\s+install\b",
        r"\bconda\s+install\b",
        r"\bgit\s+(add|commit|push|pull|reset|checkout)\b",
        r"lichess\.org/api",
        r"database\.lichess\.org",
    )
    for pattern in forbidden_launcher:
        if re.search(pattern, launcher, flags=re.IGNORECASE):
            raise RuntimeError(f"Launcher contains forbidden operation: {pattern}")
    return {
        "status": "PACKAGE_EXACT_INVENTORY_AND_HASHES_OK",
        "files": len(actual),
        "manifest": manifest,
    }


def main() -> int:
    args = parse_args()
    if args.self_test:
        if len(EXPECTED_FILES) != 13:
            raise RuntimeError("Package inventory self-test count changed")
        print("KINDNESS_EQUALITY_FEN_PACKAGE_VALIDATOR_SELFTEST_OK")
        return 0
    result = verify(args.package_root.resolve())
    print(result["status"])
    print(f"Files: {result['files']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
