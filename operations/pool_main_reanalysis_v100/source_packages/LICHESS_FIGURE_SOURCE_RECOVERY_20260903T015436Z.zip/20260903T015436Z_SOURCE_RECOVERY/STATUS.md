# Figure-factory status

Normalized input directory: `/Users/u6025368/Desktop/Lichess_Desktop/lichess_figure_runs/20260903T015436Z_SOURCE_RECOVERY/plotdata`
Output directory: `/Users/u6025368/Desktop/Lichess_Desktop/lichess_figure_runs/20260903T015436Z_SOURCE_RECOVERY/outputs/manuscript`

| Exhibit | Status | Detail |
|---|---|---|
| Figure 1 | RENDERED | F1 rendered from /Users/u6025368/Desktop/Lichess_Desktop/lichess_figure_runs/20260903T015436Z_SOURCE_RECOVERY/plotdata/f1_state_ply.parquet |
| Figure 2 | RENDERED | F2 rendered from /Users/u6025368/Desktop/Lichess_Desktop/lichess_figure_runs/20260903T015436Z_SOURCE_RECOVERY/plotdata/f2_local.parquet and /Users/u6025368/Desktop/Lichess_Desktop/lichess_figure_runs/20260903T015436Z_SOURCE_RECOVERY/plotdata/f2_curve.parquet |
| Figure 3 | RENDERED | F3 rendered from /Users/u6025368/Desktop/Lichess_Desktop/lichess_figure_runs/20260903T015436Z_SOURCE_RECOVERY/plotdata/f3_split.parquet, /Users/u6025368/Desktop/Lichess_Desktop/lichess_figure_runs/20260903T015436Z_SOURCE_RECOVERY/plotdata/f3_forward.parquet |
| Figure 4 | RENDERED | F4 rendered from /Users/u6025368/Desktop/Lichess_Desktop/lichess_figure_runs/20260903T015436Z_SOURCE_RECOVERY/plotdata/f4_raw.parquet and /Users/u6025368/Desktop/Lichess_Desktop/lichess_figure_runs/20260903T015436Z_SOURCE_RECOVERY/plotdata/f4_horizon.parquet |
| Appendix A1 | RENDERED | A1 rendered from /Users/u6025368/Desktop/Lichess_Desktop/lichess_figure_runs/20260903T015436Z_SOURCE_RECOVERY/plotdata/f1_state_ply.parquet and /Users/u6025368/Desktop/Lichess_Desktop/lichess_figure_runs/20260903T015436Z_SOURCE_RECOVERY/plotdata/a1_year_engine.parquet |
| Appendix A2 | RENDERED | A2 rendered from /Users/u6025368/Desktop/Lichess_Desktop/lichess_figure_runs/20260903T015436Z_SOURCE_RECOVERY/plotdata/a2_krd_correlations.parquet |
| Appendix A3 | RENDERED | A3 rendered from /Users/u6025368/Desktop/Lichess_Desktop/lichess_figure_runs/20260903T015436Z_SOURCE_RECOVERY/plotdata/f2_curve.parquet |
| Appendix A4 | RENDERED | A4 rendered from /Users/u6025368/Desktop/Lichess_Desktop/lichess_figure_runs/20260903T015436Z_SOURCE_RECOVERY/plotdata/a1_receipt_forest.parquet and /Users/u6025368/Desktop/Lichess_Desktop/lichess_figure_runs/20260903T015436Z_SOURCE_RECOVERY/plotdata/a1_receipt_horizon.parquet |
| Appendix A5 | RENDERED | A5 rendered from /Users/u6025368/Desktop/Lichess_Desktop/lichess_figure_runs/20260903T015436Z_SOURCE_RECOVERY/plotdata/a5_b2.parquet and /Users/u6025368/Desktop/Lichess_Desktop/lichess_figure_runs/20260903T015436Z_SOURCE_RECOVERY/plotdata/a5_c9.parquet |
| Appendix A6 | RENDERED | A6 rendered from /Users/u6025368/Desktop/Lichess_Desktop/lichess_figure_runs/20260903T015436Z_SOURCE_RECOVERY/plotdata/a6_patron_matched.parquet, /Users/u6025368/Desktop/Lichess_Desktop/lichess_figure_runs/20260903T015436Z_SOURCE_RECOVERY/plotdata/a6_patron_diagnostic.parquet, and /Users/u6025368/Desktop/Lichess_Desktop/lichess_figure_runs/20260903T015436Z_SOURCE_RECOVERY/plotdata/a6_patron_dose.parquet |
| Appendix A7 | RENDERED | A7 rendered from /Users/u6025368/Desktop/Lichess_Desktop/lichess_figure_runs/20260903T015436Z_SOURCE_RECOVERY/plotdata/a7_patron_five_bin.parquet |
| Appendix A9 | BLOCKED | A9 optional clock diagnostic missing a9_clock_state |

Blocked means the renderer did not substitute memo values. Run discovery, authenticate the named aggregate source, normalize it to the contract, and rerun.
