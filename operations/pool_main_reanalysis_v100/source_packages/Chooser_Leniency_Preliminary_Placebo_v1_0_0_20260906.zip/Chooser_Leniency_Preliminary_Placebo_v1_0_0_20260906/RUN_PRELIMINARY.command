#!/bin/bash
set -euo pipefail
umask 077
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE"
/usr/bin/shasum -a 256 -c PACKAGE_MANIFEST.sha256
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export VECLIB_MAXIMUM_THREADS=1 NUMEXPR_NUM_THREADS=1
export PYTHONUNBUFFERED=1 PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1
PROJECT="${PRELIM_PROJECT_ROOT:-/Volumes/XT_Pro/lichess_kindness}"
DESKTOP="${PRELIM_DESKTOP_ROOT:-$HOME/Desktop/Lichess_Desktop}"
WORKERS="${PRELIM_WORKERS:-10}"
MEMORY="${PRELIM_MEMORY_GB:-8}"
RUN_ID="${PRELIM_RESUME_ID:-$(date -u +%Y%m%dT%H%M%SZ)_$$}"
mkdir -p "$DESKTOP"
LOG="$DESKTOP/chooser_leniency_preliminary_${RUN_ID}_$(date -u +%H%M%S).log"
PY="${PRELIM_PYTHON:-}"
if [[ -z "$PY" ]]; then
  for candidate in "$(command -v python3 || true)" "$(command -v python || true)" \
     "$HOME/miniconda3/bin/python" "$HOME/anaconda3/bin/python" \
     /opt/anaconda3/bin/python /opt/miniconda3/bin/python; do
    [[ -n "$candidate" && -x "$candidate" ]] || continue
    if "$candidate" -c 'import numpy,pyarrow; import pyarrow.parquet' >/dev/null 2>&1; then
      PY="$candidate"; break
    fi
  done
fi
if [[ -z "$PY" || ! -x "$PY" ]]; then
  printf '\nERROR: Activate an existing Python with NumPy and PyArrow, or set PRELIM_PYTHON. Nothing was installed.\n'
  exit 2
fi
printf '\nCHOOSER LENIENCY: SOURCE-KNOWN EXPLORATORY PLACEBO + INDEPENDENT 200K PILOT\n'
printf 'Interpreter: %s\nProject: %s\nResume ID: %s\nLog: %s\n' "$PY" "$PROJECT" "$RUN_ID" "$LOG"
printf 'Planning estimate: 5-15 minutes for metadata/status and pilot preparation; 15-40 if normal-game scoring runs.\n'
printf 'Up to %s workers; %s GiB planning memory (not an OS RSS limit); >=12 GiB free disk.\n' "$WORKERS" "$MEMORY"
printf 'No network requests; no raw API or all-game chronology rescan; existing API jobs are not stopped.\n'
printf 'Missing chat/takeback fields are NOT classified as no interaction. Empty placebo support is NOT a null result.\n\n'
run_all() {
  "$PY" -c 'import sys,numpy,pyarrow; print("Python",sys.version.split()[0]); print("numpy",numpy.__version__,"pyarrow",pyarrow.__version__)' || return $?
  "$PY" -u "$HERE/test_preliminary.py" --require-io || return $?
  "$PY" -u "$HERE/run_preliminary.py" --execute --project-root "$PROJECT" \
     --desktop-root "$DESKTOP" --workers "$WORKERS" --memory-gb "$MEMORY" \
     --pilot-size 200000 --run-id "$RUN_ID" || return $?
}
set +e
run_all 2>&1 | /usr/bin/tee "$LOG"
RC=${PIPESTATUS[0]}
set -e
if [[ "$RC" -ne 0 ]]; then
  printf '\nPRELIMINARY RUN STOPPED (exit %s). Certified inputs were not modified.\n' "$RC"
  printf 'Log: %s\nResume ID: %s\n' "$LOG" "$RUN_ID"
  exit "$RC"
fi
printf '\nUpload the final PRELIMINARY_REPORT ZIP, checksum, and this log from:\n%s\n' "$DESKTOP"
