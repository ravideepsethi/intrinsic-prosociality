# Chooser-leniency preliminary placebo and independent 200,000-game pilot

Version 1.0.0, 2026-09-06. **Local-only: this package contains no network fetcher.**

## What runs now

1. Authenticate the completed validity-local run `20260906T052017Z_46893`, its comparison frame and source ledger, and the IV pilot `20260906T034402Z_47553`.
2. Freeze **200,000 games from all 1,912,023 comparison games** using fixed-seed SHA-256 bottom-k sampling. Sampling never reads source, terminal status, metadata availability, receipt, or later kindness. Keep the original recipient orientation and preserve the selected denominator. Missing games are not replaced with other games.
3. Audit the already extracted game-export metadata. The completed local scan contains 189,452 comparison metadata records in 5,877 nonempty extracted metadata files; it is not necessary to reopen the 46-GiB raw API archive. Exact game IDs are case sensitive. Recover explicit source only; conflicting sources/statuses/ratings/timestamps remain flagged. Check API creation times against the archive's second precision.
4. Report the terminal-status composition of the **147,420 metadata-known games**, including the **133,753 explicitly pool-sourced games**. These are the uploaded report's counts, not a random 7.7% sample.
5. For usable normal-ending pool games with complete follow-up, run the exploratory placebo when support permits. The narrow version uses `mate`, `resign`, and `stalemate`; the broader version also allows `draw`. **Both exclude `timeout` and `outoftime`.** All statuses remain in the independent pilot frame. No all-game selection regression is run on the availability-selected fragment.
6. Save the independent pilot's reusable cached metadata and exact remaining API targets. **Do not fetch them during this run**, so this job will not compete for the Lichess API with other ongoing retrieval jobs.

## When no regression is possible

The existing API cache was built largely from time-forfeit candidates. There may be few or no normal-ending games in it. The code does not silently substitute `outoftime` games for ordinary games. It writes the counts and an explicit `NOT_ESTIMATED` reason when support is absent or inadequate. That is not evidence of a zero effect.

A specification's asymptotic coefficient table is suppressed if it has fewer than 500 rows, ten positive kindness outcomes, or twenty recipients, opponents, or exposure dates. The sample-flow and support counts are still reported. Identity disagreements also block the exploratory estimation rather than trigger unreported exclusions or repairs.

## Instrument and outcome details

The exact `iv_numerics.py` from the completed IV pilot is reused and hash-checked. The stored 500-cell, four-fold state-reference model is reused, not refit after looking at new outcomes. Scores use all valid historical active-resolution decisions in the pilot's projected histories, not just past granters. Every decision involving the focal recipient is left out. Histories end before the first day of the exposure month minus seven days; a 30-day variant is included. The principal history floor is five decisions, with one and ten as prespecified sensitivity columns.

The recipient can have more than one sampled exposure. Each exposure receives its own outcome window and pair leave-out. The outcome is the first later fair chooser opportunity against someone other than the original opponent, with the later game starting after the focal API `lastMoveAt` and the later decision anchor within 90 days. Intervening games against the original opponent are skipped, not the recipient. Complete-follow-up nonreachers are zero. `lastMoveAt` is the same anchor convention as the IV pilot, not a newly recovered terminal click time.

If normal games exist, the code checks numeric identities against normalized usernames wherever either appears in the certified Stage07 universe. It does not exclude people simply because they never appear in Stage07; their observed panel outcome remains zero when no qualifying event exists. Conflicting aliases or numeric identities block estimation and are listed privately.

## Controls, scale, and uncertainty

The main controls use the available pregame ratings, rating gap terms, exact clock setting, month/rating cells, exposure day and hour-of-week, and opponent-history size/composition. One variant adds prior recipient kindness-history controls. **Pregame RD and full prior all-game volume are not in these exports**, so the controls are labelled observed-W rather than falsely described as identical to the original IV pilot's controls.

Both native-SD coefficients and coefficients on a common score scale are reported. The common scale is the primary IV pilot's residual score SD, `0.059288502306202064`; its reference reduced form is `0.029038213482045855` percentage points. The common unit aids magnitude comparison, but does not equalize the populations or conditioning sets.

Inference treats the generated history score as fixed. Shared-account dyadic CR0 allows an account to occur in either role; a second covariance estimate also allows within-exposure-date correlation. Wider network dependencies, historical score estimation uncertainty, and the selected nature of the sample remain open. Nonpositive variance estimates are flagged, not repaired. No permutation is represented as exact under the matchmaker.

The 90% confidence interval is also compared descriptively with ±0.03 and ±0.015 pp equivalence margins on the common score scale. This cannot certify exclusion on the broader population. A wide interval is inconclusive; no result is labelled a passed identification gate.

**This does not identify a no-chat/no-takeback sample.** Chat and takeback histories are not available. Missing fields are never treated as proof of no interaction.

## Locations

Existing inputs (read only):

```
/Volumes/XT_Pro/lichess_kindness/derived/replication/
    chooser_leniency_validity_local_v100_PRIVATE/20260906T052017Z_46893/
    chooser_leniency_iv_pilot_v100_PRIVATE/20260906T034402Z_47553/
    analysis_panel_24m_sf100k/
```

New private output:

```
derived/replication/chooser_leniency_preliminary_v100_PRIVATE/<run_id>/
    pilot200k/frame.parquet
    pilot200k/sampling_receipt.json
    audited_metadata/records.parquet
    pilot200k_readiness/cached_metadata.parquet
    pilot200k_readiness/pending_API_targets.parquet
    pilot200k_readiness/retrieval_plan.json
    identity/                         # only when normal-game candidates exist
    history_shards/                   # only when identity permits analysis
    analysis/exploratory_analysis_PRIVATE.parquet
```

Do not upload these identifier-bearing files. The final report archive contains only allowlisted aggregate diagnostics and is placed on `~/Desktop/Lichess_Desktop`.

## Run, resources, and resume

Download the ZIP and checksum, move them to `~/Desktop/Lichess_Desktop`, and use the accompanying terminal block. The included runner verifies the package manifest and requires **all synthetic Arrow I/O tests** to pass before reading production inputs. It uses an existing Python 3.10 or newer with **NumPy and PyArrow**. It installs nothing; no DuckDB, Stockfish, raw PGNs, all-game chronology scan, or new API call is required.

Planning estimate: **5–15 minutes** for cached-metadata/status auditing and independent pilot preparation; **15–40 minutes** if the optional identity/history/placebo stage has sufficient normal-game support. These are planning estimates, not measured benchmarks. Storage and simultaneous jobs can increase runtime.

Maximum ten workers, with stage caps of six metadata workers and four history/identity workers. Each numerical worker uses one numerical-library thread. Eight GiB is a planning budget, not an operating-system RSS cap. Require twelve GiB of free disk. Checkpoint directories and original certified inputs are never overwritten. Failed partial outputs are preserved.

Resume with the same package and settings by setting `PRELIM_RESUME_ID` to the printed run ID before running `RUN_PRELIMINARY.command` again. A changed code version or configuration requires a new run. `PRELIM_PYTHON`, `PRELIM_PROJECT_ROOT`, and `PRELIM_DESKTOP_ROOT` are explicit optional path overrides.

## Completion

```
CHOOSER_LENIENCY_PRELIMINARY_V100_COMPLETE_WITH_OPEN_GATES
NO_API_REQUESTS_MADE
```

An additional line describes whether the exploratory coefficients were estimable. “Complete” means this explicitly scoped local stage finished; the independent 200k sample may still need metadata, and no causal assumption has been certified.

Upload the final `CHOOSER_LENIENCY_PRELIMINARY_REPORT_<run_id>.zip`, its checksum, and the log. The `_STATUS` ZIP is an intermediate snapshot. The next retrieval phase must reconcile the pending IDs against other recent recovery caches, use one API job at a time, preserve nonreturns, and never estimate the substantive selection effect by deleting unknown-source rows from the frozen denominator.
