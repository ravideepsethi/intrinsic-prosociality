#!/bin/bash
set -Eeuo pipefail
IFS=$'\n\t'

task_package_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
task_project="/Volumes/XT_Pro/lichess_kindness"
task_repo="$task_project/replication_package"
task_python="$task_project/venv/bin/python"
task_desktop="/Users/u6025368/Desktop/Lichess_Desktop"
task_script="$task_package_dir/10b_build_a3_chronology_gate.py"
task_test="$task_package_dir/test_a3_chronology_gate_synthetic.py"
task_plan="$task_package_dir/Dynamic_Prosociality_Analysis_Plan_v1_0_1_2026-08-21.md"
task_manifest="$task_package_dir/A3_chronology_gate_v100_package_manifest.tsv"
task_state="$task_project/derived/replication/dynamic_prosociality_a3_chronology_gate_v100_PRIVATE"
task_output_base="$task_project/output/dynamic_prosociality_a3_chronology_gate_v100"
task_run_id="$(date -u +%Y%m%dT%H%M%SZ)"
task_output="$task_output_base/$task_run_id"
task_log_dir="$task_project/logs/dynamics"
task_log="$task_log_dir/a3_chronology_gate_v100_${task_run_id}.log"
task_transfer="$task_desktop/a3_chronology_gate_v100_${task_run_id}.zip"
task_expected_head="7fa2cf415b43c69f4d8d5fc973442d81dbb6ecbf"
task_started="$(date +%s)"

mkdir -p "$task_log_dir" "$task_desktop" "$task_output_base"

{
  printf 'A3_CHRONOLOGY_GATE_V100_START\n\n'
  printf 'Expected first-run runtime: approximately 1-8 hours, depending on XT_Pro I/O.\n'
  printf 'The scan is resumable after every selected chronology file.\n'
  printf 'If interrupted, run the same authenticated terminal block again.\n'
  printf 'No API request, treatment-arm comparison, effect estimate, Git mutation, or certified-input write will occur.\n\n'
  printf 'Private resumable state: %s\n' "$task_state"
  printf 'Aggregate output: %s\n' "$task_output"
  printf 'Log: %s\n\n' "$task_log"

  [[ -d "$task_project" ]] || {
    printf 'ERROR: XT_Pro project root is unavailable: %s\n' "$task_project" >&2
    exit 1
  }
  [[ -x "$task_python" ]] || {
    printf 'ERROR: Project Python is unavailable: %s\n' "$task_python" >&2
    exit 1
  }
  [[ -d "$task_repo/.git" ]] || {
    printf 'ERROR: Replication repository is unavailable: %s\n' "$task_repo" >&2
    exit 1
  }

  "$task_python" - "$task_package_dir" "$task_manifest" <<'PY'
import csv
import hashlib
import pathlib
import sys

root = pathlib.Path(sys.argv[1])
manifest = pathlib.Path(sys.argv[2])
with manifest.open(encoding="utf-8", newline="") as stream:
    rows = list(csv.DictReader(stream, delimiter="\t"))
assert rows, "empty package manifest"
for row in rows:
    path = root / row["path"]
    assert path.is_file(), path
    assert path.stat().st_size == int(row["bytes"]), path
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    assert actual == row["sha256"], (path, actual, row["sha256"])
print("A3_CHRONOLOGY_GATE_PACKAGE_CONTENTS_AUTHENTICATED_OK")
PY

  task_git_head_before="$(git -C "$task_repo" rev-parse HEAD)"
  task_git_status_before="$(git -C "$task_repo" status --porcelain=v1)"
  [[ "$task_git_head_before" == "$task_expected_head" ]] || {
    printf 'ERROR: Frozen Git HEAD mismatch.\nExpected: %s\nActual:   %s\n' \
      "$task_expected_head" "$task_git_head_before" >&2
    exit 1
  }
  [[ -z "$task_git_status_before" ]] || {
    printf 'ERROR: Repository is not clean before the chronology gate.\n' >&2
    git -C "$task_repo" status --short >&2
    exit 1
  }
  printf 'REPOSITORY_PREFLIGHT_OK\n'
  printf 'Git HEAD: %s\n\n' "$task_git_head_before"

  "$task_python" - <<'PY'
import duckdb
import numpy
import pyarrow

print("duckdb:", duckdb.__version__)
print("numpy:", numpy.__version__)
print("pyarrow:", pyarrow.__version__)
assert duckdb.__version__ == "1.5.2"
assert numpy.__version__ == "2.4.4"
assert pyarrow.__version__ == "24.0.0"
print("A3_CHRONOLOGY_GATE_DEPENDENCIES_OK")
PY

  printf '\nPURE_NUMERICAL_SELF_TEST_BEGIN\n'
  "$task_python" "$task_script" --self-test

  printf '\nPYARROW_LINKAGE_SELF_TEST_BEGIN\n'
  "$task_python" "$task_script" --integration-self-test

  printf '\nFULL_SYNTHETIC_GATE_TEST_BEGIN\n'
  "$task_python" "$task_test"

  printf '\nA3_CHRONOLOGY_GATE_PLAN_BEGIN\n'
  "$task_python" "$task_script" \
    --project-root "$task_project" \
    --analysis-plan "$task_plan" \
    --state-root "$task_state" \
    --output-root "$task_output_base" \
    --threads 8 \
    --memory-limit 12GB \
    --batch-rows 500000

  printf '\nA3_CHRONOLOGY_GATE_EXECUTE_OR_RESUME_BEGIN\n'
  task_execute=(
    "$task_python" "$task_script"
    --project-root "$task_project"
    --analysis-plan "$task_plan"
    --state-root "$task_state"
    --output-root "$task_output_base"
    --threads 8
    --memory-limit 12GB
    --batch-rows 500000
    --run-id "$task_run_id"
    --verify-stage07-hashes
    --execute
  )
  if command -v caffeinate >/dev/null 2>&1; then
    PYTHONUNBUFFERED=1 caffeinate -dimsu "${task_execute[@]}"
  else
    printf 'WARNING: caffeinate is unavailable; continuing without it.\n' >&2
    PYTHONUNBUFFERED=1 "${task_execute[@]}"
  fi

  [[ -f "$task_output/_SUCCESS.json" ]] || {
    printf 'ERROR: Aggregate success receipt is missing: %s\n' \
      "$task_output/_SUCCESS.json" >&2
    exit 1
  }

  printf '\nINDEPENDENT_AGGREGATE_AND_PRIVATE_RECEIPT_INSPECTION_BEGIN\n'
  "$task_python" - "$task_output" "$task_state" <<'PY'
import csv
import hashlib
import json
import pathlib
import sys

import pyarrow.parquet as pq

output = pathlib.Path(sys.argv[1])
state = pathlib.Path(sys.argv[2])

with (output / "report_file_hashes.tsv").open(
    encoding="utf-8", newline=""
) as stream:
    manifest = list(csv.DictReader(stream, delimiter="\t"))
assert manifest
for row in manifest:
    path = output / row["path"]
    assert path.is_file(), path
    assert path.stat().st_size == int(row["bytes"]), path
    assert hashlib.sha256(path.read_bytes()).hexdigest() == row["sha256"], path

summary = json.loads((output / "_SUCCESS.json").read_text(encoding="utf-8"))
assert summary["status"] == "A3_CHRONOLOGY_POOLED_FEASIBILITY_GATE_OK"
assert summary["treatment_or_choice_outcome_read"] is False
assert summary["arm_specific_result_produced"] is False
assert summary["a1_a3_b1_effect_estimates_produced"] is False
assert summary["chronology_30d_coverage_complete"] is True
gate = summary["pooled_gate"]
rate = float(gate["pooled_rate_30d"])
assert 0.0 <= rate <= 1.0
expected = (
    "any_rated_standard_game_within_30d"
    if rate <= 0.92
    else "log1p_rated_standard_games_within_30d"
)
assert gate["a3_primary_outcome_selected"] == expected
assert int(gate["accounts"]) == 2_556_782

private_receipt = json.loads(
    (state / "_PRIVATE_SUCCESS.json").read_text(encoding="utf-8")
)
private = pathlib.Path(private_receipt["output_path"])
assert private.is_file(), private
assert private.stat().st_size == int(private_receipt["output_bytes"])
digest = hashlib.sha256()
with private.open("rb") as stream:
    while block := stream.read(8 * 1024 * 1024):
        digest.update(block)
assert digest.hexdigest() == private_receipt["output_sha256"]
assert int(private_receipt["rows"]) == 2_556_782
names = set(pq.ParquetFile(private).schema_arrow.names)
assert not names & {
    "received_mercy", "kind_draw", "outcome_kind_draw", "timeout_draw",
    "timeout_chooser_win",
}

print("A3_CHRONOLOGY_GATE_INDEPENDENT_INSPECTION_OK")
print("status:", summary["status"])
print("cohort accounts:", f"{int(gate['accounts']):,}")
print("accounts with any game in 7 days:", f"{int(gate['accounts_any_7d']):,}")
print("accounts with any game in 30 days:", f"{int(gate['accounts_any_30d']):,}")
print("pooled 30-day participation rate:", f"{rate:.9%}")
print("frozen ceiling threshold:", f"{float(gate['pooled_ceiling_threshold']):.0%}")
print("A3 primary selected:", gate["a3_primary_outcome_selected"])
print("mean games within 7 days:", gate["mean_games_7d"])
print("mean games within 30 days:", gate["mean_games_30d"])
print("median games within 30 days:", gate["count_30d_p50"])
print("90th percentile games within 30 days:", gate["count_30d_p90"])
print("chronology files scanned:", summary["checkpoint_summary"]["selected_chronology_files"])
print("chronology rows scanned:", f"{int(summary['checkpoint_summary']['scanned_rows']):,}")
print("private activity SHA256:", private_receipt["output_sha256"])
print("private activity path:", private)
print("arm-specific result produced:", summary["arm_specific_result_produced"])
print("effect estimates produced:", summary["a1_a3_b1_effect_estimates_produced"])
print("next step:", summary["next_step"])
PY

  task_git_head_after="$(git -C "$task_repo" rev-parse HEAD)"
  task_git_status_after="$(git -C "$task_repo" status --porcelain=v1)"
  [[ "$task_git_head_after" == "$task_git_head_before" ]] || {
    printf 'ERROR: Git HEAD changed during the chronology gate.\n' >&2
    exit 1
  }
  [[ -z "$task_git_status_after" ]] || {
    printf 'ERROR: Repository changed during the chronology gate.\n' >&2
    git -C "$task_repo" status --short >&2
    exit 1
  }

  printf '\nBUILDING_AGGREGATE_ONLY_TRANSFER_ARCHIVE\n'
  (
    cd "$task_output_base"
    zip -q -X -r "$task_transfer" "$task_run_id"
  )
  unzip -tq "$task_transfer"
  task_transfer_sha="$(shasum -a 256 "$task_transfer" | awk '{print $1}')"
  printf '%s  %s\n' "$task_transfer_sha" "$(basename "$task_transfer")" \
    > "$task_transfer.sha256"

  task_elapsed="$(( $(date +%s) - task_started ))"
  printf '\nFINAL GIT STATUS\n'
  git -C "$task_repo" status --short --branch
  printf '\nA3_CHRONOLOGY_GATE_V100_COMPLETE\n'
  printf 'Frozen plan SHA256: '
  shasum -a 256 "$task_plan" | awk '{print $1}'
  printf 'Private resumable state: %s\n' "$task_state"
  printf 'Aggregate output: %s\n' "$task_output"
  printf 'Aggregate-only transfer ZIP: %s\n' "$task_transfer"
  printf 'Transfer ZIP SHA256: %s\n' "$task_transfer_sha"
  printf 'Log: %s\n' "$task_log"
  printf 'Elapsed seconds: %s\n' "$task_elapsed"
  printf 'No API request, arm-specific result, effect estimate, Git mutation, or certified-input write occurred.\n'
} 2>&1 | tee "$task_log"
