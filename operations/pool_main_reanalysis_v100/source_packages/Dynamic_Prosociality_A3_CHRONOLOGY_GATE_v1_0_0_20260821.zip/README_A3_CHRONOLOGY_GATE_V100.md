# A3 chronology feasibility gate v1.0.0

This package completes the last outcome-blind feasibility gate required by the frozen
dynamic-prosociality analysis plan. It links the combined first-fair-recipient cohort
to the canonical all-history rated-standard chronology and applies the prespecified
pooled 30-day ceiling rule. It does **not** compare mercy and claim recipients and does
not estimate A1, A3, B1, or any other treatment effect.

## Frozen authorities

- Stage 07: 24 certified monthly files, 47,587,020 rows, success SHA-256
  `8b7010b528ae5c6f1e1a9b517258648204c14c17ca41a2a6796f8ee5a1ed6db7`.
- Stage 07 producer SHA-256:
  `0411d4061ea9831c20449208a9782aaf668e160139918d106a2b7d63aaa56e6e`.
- Dynamic analysis plan v1.0.1 SHA-256:
  `b11b546ea6fde608140619cffadffad1a7aab054b6fd1a9dcbee8900c98d0a6f`.
- Stage 07-only feasibility producer SHA-256:
  `c7c1da3ce422d3dfeb69c568fe0ca74d6cb1b466da3bace9771e8a6d01004790`.
- Final reentry source-contract producer SHA-256:
  `48806ab26ce53eca826cdcd5c441a816efec8f4d45b5e38d4662fbd3f4b1a61b`.
- Frozen repository HEAD:
  `7fa2cf415b43c69f4d8d5fc973442d81dbb6ecbf`.
- Canonical chronology: 852 Parquet files and 7,763,847,245 rated-standard
  games, through 2026-04-30 23:59:58 UTC.
- Recovered historical clock contract: `disc_clock_s >= 347.0` seconds.

## Arm-blind design

The private cohort reproduces the exact v1.0.1 membership rule: the first fair,
non-tournament-like recipient exposure is selected within normalized recipient
username using `(utc_ms, archive_ordinal, game_id)`. Only after membership is fixed is
the numeric `disconnected_user_id` retained for the chronology join. The producer never
projects `kind_draw`, mercy receipt, or a subsequent chooser outcome.

The exposure anchor is `api_last_move_at_ms`, the audited onset-of-absence proxy. A
chronology event counts only when its `utc_ms` is strictly greater than that anchor.
The scan reads only `utc_ms`, `white_id`, and `black_id`. It derives, for the combined
cohort:

- any rated-standard game within 7 and 30 days;
- rated-standard game counts within 7 and 30 days; and
- the first subsequent rated-standard game timestamp.

The pooled 30-day rule is frozen:

- rate at or below 92%: `any_rated_standard_game_within_30d` is primary;
- rate above 92%: `log1p_rated_standard_games_within_30d` is primary.

The binary outcome and raw count remain required either way. The aggregate report has
no treatment arm, no account identifier, and no treatment-effect estimate.

## Resumability and storage

The durable private state is written only to:

```text
/Volumes/XT_Pro/lichess_kindness/derived/replication/dynamic_prosociality_a3_chronology_gate_v100_PRIVATE
```

Each selected chronology file receives an atomic update Parquet plus a JSON receipt.
On restart, the producer authenticates every completed checkpoint and resumes with the
first unfinished file. An interruption can therefore repeat at most the active
chronology file. Cohort and final private-cache receipts are also authenticated before
reuse.

Aggregate reports are written beneath:

```text
/Volumes/XT_Pro/lichess_kindness/output/dynamic_prosociality_a3_chronology_gate_v100
```

The runner creates a compact transfer ZIP in:

```text
/Users/u6025368/Desktop/Lichess_Desktop
```

The transfer ZIP contains only aggregate feasibility material. It excludes the private
cohort, private activity cache, and per-file account-level updates. None of those files
may be committed, emailed, or publicly uploaded.

## Runtime and restart

Allow approximately 1-8 hours on the current XT_Pro setup; actual time depends on how
many chronology row groups overlap the exact exposure-anchor window and on external-disk
throughput. Progress is printed after every five completed chronology files. The runner
uses `caffeinate` when available.

If the terminal, Python process, or laptop stops, run the same authenticated terminal
block again. Do not delete the private state root. The new invocation will authenticate
and resume it.

## Validation

Before touching project data, the runner performs:

1. package hash authentication;
2. exact dependency and Git-state checks;
3. pure numerical self-tests;
4. a PyArrow chronology-link integration test; and
5. an independent full synthetic test covering cohort selection, treatment omission,
   checkpointing, private finalization, the ceiling rule, and aggregate hash manifests.

The production pass then authenticates every Stage 07 Parquet SHA-256, the prior
feasibility report, the final reentry audit, every chronology footer, the private
checkpoints, and the final aggregate report.

After this gate succeeds, the next step is to freeze the exact A1/A3/B1 estimation
producer before treatment is joined to the private activity cache.
