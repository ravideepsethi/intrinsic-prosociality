#!/usr/bin/env python3
"""End-to-end synthetic validation for the A3 chronology feasibility gate."""

from __future__ import annotations

import importlib.util
import tempfile
import time
from pathlib import Path

import pyarrow as pa
import pyarrow.parquet as pq


def load_producer() -> object:
    path = Path(__file__).with_name("10b_build_a3_chronology_gate.py")
    spec = importlib.util.spec_from_file_location("a3_gate_producer", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not load producer: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main() -> None:
    producer = load_producer()
    original_expected_rows = producer.EXPECTED_PRIMARY_COHORT_ROWS
    producer.EXPECTED_PRIMARY_COHORT_ROWS = 2
    try:
        with tempfile.TemporaryDirectory() as raw:
            root = Path(raw)
            stage07 = root / "synthetic_stage07.parquet"
            pq.write_table(
                pa.table(
                    {
                        "game_id": ["tour", "g1", "g2", "g3"],
                        "archive_ordinal": pa.array([0, 1, 2, 3], type=pa.int64()),
                        "utc_ms": pa.array([800, 1_000, 1_500, 2_000], type=pa.int64()),
                        "api_last_move_at_ms": pa.array(
                            [900, 1_100, 1_600, 2_100], type=pa.int64()
                        ),
                        "disconnected_user_id": pa.array([2, 2, 2, 5], type=pa.int64()),
                        "disconnected_username_norm": ["u1", "u1", "u1", "u2"],
                        "fair_competitive": [True, True, True, True],
                        "tournament_like_event": [True, False, False, False],
                        # This field exists only to prove that the A3 cohort projection
                        # does not retain or use the treatment.
                        "kind_draw": [True, False, True, False],
                    }
                ),
                stage07,
            )
            bounds = producer.arm_blind_anchor_bounds([stage07])
            assert bounds["minimum_anchor_utc_ms"] == 1_100
            assert bounds["maximum_anchor_utc_ms"] == 2_100

            state = root / "state"
            resume_config = {"synthetic": True}
            payload = {
                "state_root": str(state),
                "resume_config": resume_config,
                "resume_config_sha256": producer.sha256_text(
                    producer.canonical_json(resume_config)
                ),
                "stage07": {"paths": [stage07], "success_sha256": "synthetic07"},
                "prior_feasibility": {"success_sha256": "synthetic_prior"},
                "reentry_audit": {"directory_manifest_sha256": "synthetic_reentry"},
                "threads": 2,
                "memory_limit": "1GB",
                "chronology": {
                    "utc_ms_max": 2_100 + 40 * producer.DAY_MS,
                    "footer_plan_sha256": "synthetic_footer",
                    "file_rows": [],
                },
                "analysis_plan_sha256": "synthetic_plan",
                "script_sha256": "synthetic_script",
                "git": {"head": "synthetic_head"},
                "arm_blind_anchor_bounds": bounds,
                "output_root": str(root / "aggregate_reports"),
            }
            state = producer.initialize_or_authenticate_state(payload)
            cohort = producer.build_or_authenticate_cohort(payload, state)
            cohort_table = pq.read_table(cohort)
            assert cohort_table["exposure_game_id"].to_pylist() == ["g1", "g3"]
            assert not (
                set(cohort_table.schema.names) & producer.PROHIBITED_PRIVATE_COLUMNS
            )

            events = root / "synthetic_events.parquet"
            pq.write_table(
                pa.table(
                    {
                        "utc_ms": pa.array(
                            [
                                1_100,
                                1_200,
                                2_200,
                                1_100 + 8 * producer.DAY_MS,
                                2_100 + 31 * producer.DAY_MS,
                            ],
                            type=pa.int64(),
                        ),
                        "white_id": pa.array([2, 2, 5, 2, 5], type=pa.int64()),
                        "black_id": pa.array([7, 7, 7, 7, 7], type=pa.int64()),
                    }
                ),
                events,
                row_group_size=2,
            )
            lookup, anchors, cohort_rows = producer.load_cohort_lookup(cohort)
            update_path = state / "updates" / "chronology_0000.parquet"
            event_file = pq.ParquetFile(events)
            file_row = {
                "path": str(events),
                "bytes": events.stat().st_size,
                "rows": event_file.metadata.num_rows,
                "row_groups": event_file.metadata.num_row_groups,
                "selected_row_groups": list(range(event_file.metadata.num_row_groups)),
                "utc_ms_min": 1_100,
                "utc_ms_max": 2_100 + 31 * producer.DAY_MS,
                "footer_signature_sha256": "synthetic_footer_file",
            }
            checkpoint = producer.process_event_file(
                file_row=file_row,
                file_index=0,
                cohort_rows=cohort_rows,
                lookup=lookup,
                anchors=anchors,
                output_path=update_path,
                batch_rows=10_000,
            )
            private, private_receipt = producer.finalize_private_activity(
                payload, state, cohort, [update_path]
            )
            activity = pq.read_table(private).to_pydict()
            assert activity["games_within_7d"] == [1, 1]
            assert activity["games_within_30d"] == [2, 1]

            pooled = producer.pooled_gate_statistics(payload, private)
            assert pooled["pooled_rate_30d"] == 1.0
            assert (
                pooled["a3_primary_outcome_selected"]
                == "log1p_rated_standard_games_within_30d"
            )
            assert pooled["arm_specific_result_produced"] is False

            payload["chronology"]["file_rows"] = [file_row]
            final = producer.write_aggregate_report(
                payload,
                state,
                private,
                private_receipt,
                [checkpoint],
                "SYNTHETIC",
                time.time(),
            )
            summary = producer.load_json(final / "_SUCCESS.json")
            assert summary["arm_specific_result_produced"] is False
            assert summary["a1_a3_b1_effect_estimates_produced"] is False
            assert (
                producer.authenticate_manifest(final, final / "report_file_hashes.tsv")
                == 6
            )
    finally:
        producer.EXPECTED_PRIMARY_COHORT_ROWS = original_expected_rows
    print("A3_CHRONOLOGY_GATE_FULL_SYNTHETIC_OK")


if __name__ == "__main__":
    main()
