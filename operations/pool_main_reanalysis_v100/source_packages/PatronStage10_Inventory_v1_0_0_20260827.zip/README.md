# Patron Stage 10 inventory v1.0.0

This package performs the read-only input inventory required before the
24-month patron/profile production analysis. It does not estimate any patron
model and does not make an API request.

The inventory authenticates the certified profile snapshot, inspects Parquet
schemas without printing account values, locates the original matching plan and
the historical patron scripts, copies only source/receipt material, and writes a
redacted diagnostic bundle for review.

Run `RUN_PATRON_STAGE10_INVENTORY.command` through the authenticated launcher
provided with the package. The runner uses the existing canonical project
environment and never installs or downgrades a dependency.

Expected runtime on XT_Pro: 2-10 minutes. Hashing the 437 MB snapshot is the
largest fixed task; filesystem discovery may add several minutes.

The production analysis must not start until the inventory reports
`PATRON_STAGE10_INVENTORY_COMPLETE` and its bundle has been reviewed.
