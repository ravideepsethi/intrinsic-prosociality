# Source provenance

The implementation contract and inventory were prepared from:

- the public `ravideepsethi/intrinsic-prosociality` repository at commit
  `6ab3003a2b829ad0449daa7da738e040be4090bf` (retrieved 2026-08-27 UTC);
- the certified Stage 07 schema and Stage 08 authority files copied under
  `frozen_authorities/`;
- `lichess_kindness_consolidated_handoff_v23_2026-08-12.md`;
- `lichess_kindness_prior_scripts_memo.md`;
- the 74-page manuscript `The Structure of Intrinsic Prosociality: Field
  Evidence from Online Chess`, compiled 2026-08-12; and
- the final 2026-08-26 profile-acquisition certification transcript.

The public repository still described patron acquisition as pending at that
commit. This package does not treat that status text as current; it binds the
newly completed snapshot directly by its certified SHA-256.

Historical 10k-node patron values inform specification continuity only. They
are not inputs to the new estimates.
