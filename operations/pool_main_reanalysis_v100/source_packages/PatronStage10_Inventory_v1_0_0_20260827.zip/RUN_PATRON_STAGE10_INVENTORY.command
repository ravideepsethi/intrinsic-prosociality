#!/bin/bash
set -euo pipefail

PACKAGE_ROOT="$(
    cd "$(dirname "$0")"
    pwd -P
)"

PROJECT="${PATRON_PROJECT_ROOT:-/Volumes/XT_Pro/lichess_kindness}"
PYTHON="$PROJECT/venv/bin/python"
PROFILE_ROOT="$PROJECT/derived/replication/patron_profile_snapshot_24m_v100_FINAL_CERTIFIED"
SNAPSHOT="$PROFILE_ROOT/profile_snapshot_24m_private_lossless.parquet"
STAGE07_ROOT="$PROJECT/derived/replication/analysis_panel_24m_sf100k"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUTPUT_ROOT="$PROJECT/output/PATRON_STAGE10_INVENTORY_V100_$STAMP"
DESKTOP="/Users/u6025368/Desktop/Lichess_Desktop"
ZIP_PATH="$DESKTOP/PATRON_STAGE10_INVENTORY_RESULTS_$STAMP.zip"
SIDECAR="$ZIP_PATH.sha256"

printf '%s\n' '============================================================'
printf '%s\n' 'PATRON STAGE 10 — CERTIFIED INPUT INVENTORY v1.0.0'
printf '%s\n' '============================================================'
printf '\nExpected runtime: approximately 2-10 minutes.\n'
printf 'This is read-only with respect to research inputs.\n'
printf 'No API call and no patron model will be run.\n\n'

if [[ ! -d "$PROJECT" ]]; then
    printf 'ERROR: XT_Pro project is not mounted at:\n%s\n' "$PROJECT" >&2
    exit 1
fi

if [[ ! -x "$PYTHON" ]]; then
    printf 'ERROR: canonical project Python is missing:\n%s\n' "$PYTHON" >&2
    exit 1
fi

if [[ ! -f "$SNAPSHOT" ]]; then
    printf 'ERROR: certified profile snapshot is missing:\n%s\n' "$SNAPSHOT" >&2
    exit 1
fi

mkdir -p "$PROJECT/output" "$DESKTOP"

printf 'Verifying canonical numerical environment...\n'
"$PYTHON" - <<'PY'
import duckdb
import numpy
import pandas
import pyarrow

observed = {
    "duckdb": duckdb.__version__,
    "numpy": numpy.__version__,
    "pandas": pandas.__version__,
    "pyarrow": pyarrow.__version__,
}
expected = {
    "duckdb": "1.5.2",
    "numpy": "2.4.4",
    "pandas": "3.0.3",
    "pyarrow": "24.0.0",
}
print("Observed:", observed)
print("Expected:", expected)
if observed != expected:
    raise SystemExit("ERROR: canonical numerical environment mismatch")
print("CANONICAL_ENVIRONMENT_OK")
PY

printf '\nRunning synthetic self-test...\n'
"$PYTHON" "$PACKAGE_ROOT/code/00_inventory_patron_stage10.py" --self-test
"$PYTHON" "$PACKAGE_ROOT/code/01_verify_patron_stage10_inventory.py" --self-test

printf '\nRunning certified read-only inventory...\n'
"$PYTHON" "$PACKAGE_ROOT/code/00_inventory_patron_stage10.py" \
    --project "$PROJECT" \
    --profile-root "$PROFILE_ROOT" \
    --snapshot "$SNAPSHOT" \
    --stage07-root "$STAGE07_ROOT" \
    --output-root "$OUTPUT_ROOT"

printf '\nRunning independent inventory verification...\n'
"$PYTHON" "$PACKAGE_ROOT/code/01_verify_patron_stage10_inventory.py" \
    --output-root "$OUTPUT_ROOT"

printf '\nCreating authenticated transfer bundle...\n'
(
    cd "$OUTPUT_ROOT"
    /usr/bin/zip -qry "$ZIP_PATH" .
)

ZIP_SHA="$(shasum -a 256 "$ZIP_PATH" | awk '{print $1}')"
printf '%s  %s\n' "$ZIP_SHA" "$(basename "$ZIP_PATH")" > "$SIDECAR"

printf '\n%s\n' '============================================================'
printf '%s\n' 'INVENTORY REPORT'
printf '%s\n' '============================================================'
/bin/cat "$OUTPUT_ROOT/inventory_report.md"

printf '\n%s\n' '============================================================'
printf '%s\n' 'PATRON STAGE 10 INVENTORY COMPLETE'
printf '%s\n' '============================================================'
printf 'Output root: %s\n' "$OUTPUT_ROOT"
printf 'Authenticated ZIP: %s\n' "$ZIP_PATH"
printf 'ZIP SHA-256: %s\n' "$ZIP_SHA"
printf 'Sidecar: %s\n' "$SIDECAR"
printf '\nSTOP HERE. Do not start patron production estimation yet.\n'
printf 'Upload the ZIP and sidecar and paste the complete Terminal output.\n'
