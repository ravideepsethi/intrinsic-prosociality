#!/usr/bin/env python3
"""Read-only inventory for the certified 24-month patron/profile extension.

The program authenticates the fixed profile snapshot and Stage 07 receipt,
inspects schemas without reading or printing account-level values, locates the
matching-plan and historical-source lineage, and emits a disclosure-safe bundle.
It does not estimate a patron model and does not call an API.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import platform
import re
import shutil
import sys
import tempfile
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

import pyarrow as pa
import pyarrow.parquet as pq


VERSION = "1.0.0"

PROJECT_DEFAULT = Path("/Volumes/XT_Pro/lichess_kindness")
PROFILE_ROOT_REL = Path(
    "derived/replication/"
    "patron_profile_snapshot_24m_v100_FINAL_CERTIFIED"
)
SNAPSHOT_NAME = "profile_snapshot_24m_private_lossless.parquet"
STAGE07_ROOT_REL = Path(
    "derived/replication/analysis_panel_24m_sf100k"
)

EXPECTED = {
    "snapshot_sha256": "f42f28a6540a65c0a83f0da488663b4adddf60d1001daeed556f1ffbb961e238",
    "snapshot_rows": 1_305_872,
    "returned_profiles": 1_305_683,
    "unreturned_profiles": 189,
    "patrons": 4_896,
    "kind_requested": 326_468,
    "kind_returned": 326_427,
    "kind_patrons": 1_743,
    "control_requested": 979_404,
    "control_returned": 979_256,
    "control_patrons": 3_153,
    "stage07_success_sha256": "8b7010b528ae5c6f1e1a9b517258648204c14c17ca41a2a6796f8ee5a1ed6db7",
    "stage07_script_sha256": "0411d4061ea9831c20449208a9782aaf668e160139918d106a2b7d63aaa56e6e",
    "stage07_rows": 47_587_020,
    "stage07_kind_draws": 669_503,
    "stage07_months": 24,
    "stage07_columns": 157,
    "plan_success_sha256": "2838aa942e20027561763855c387a454d74bb0a92d0a8b62ca47343511897e57",
    "audit_file_hashes_sha256": "be1b69ac46d2a0e44180868e0ccead43ad0043299cffeb0203346c6c0c28aa3e",
}

HISTORICAL_SCRIPT_NAMES = [
    "146_profile_patron_country_10k_dependency_audit.py",
    "147_profile_marker_opportunity_gate_nodes10000.py",
    "148_locate_patron_inputs_for_nodes10000.py",
    "149_patron_main_nodes10000_analysis.py",
    "150_finish_patron_main_nodes10000_from_cache.py",
    "151_country_profile_fair_state_descriptives_nodes10000.py",
    "190_priority_remaining_analyses_nodes10000.py",
    "199_corollary1_diagnostic_kindness_patron_nodes10000.py",
    "200_final_paper_requests_A_B_nodes10000.py",
]

SOURCE_TOKENS = (
    "patron",
    "profile_snapshot",
    "profilepatron",
    "profile_acquisition",
)
PLAN_TOKENS = (
    "plan",
    "target",
    "catalog",
    "assignment",
    "match",
    "chooser",
    "user_list",
    "userlist",
)
SOURCE_SUFFIXES = {".py", ".sh", ".command", ".md", ".toml", ".yaml", ".yml"}
TABULAR_SUFFIXES = {".parquet", ".csv", ".tsv", ".json"}


@dataclass(frozen=True)
class LocatedFile:
    path: Path
    root_label: str
    relative_path: str


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256_file(path: Path, block_size: int = 8 * 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while True:
            block = stream.read(block_size)
            if not block:
                break
            digest.update(block)
    return digest.hexdigest()


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + f".tmp.{os.getpid()}")
    with temporary.open("w", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, sort_keys=True, ensure_ascii=True)
        stream.write("\n")
    temporary.replace(path)


def write_text(path: Path, value: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + f".tmp.{os.getpid()}")
    temporary.write_text(value, encoding="utf-8")
    temporary.replace(path)


def load_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as stream:
        return json.load(stream)


def sanitize_path(path: Path, project: Path) -> str:
    value = str(path)
    project_s = str(project)
    if value == project_s:
        return "$PROJECT"
    if value.startswith(project_s + os.sep):
        return "$PROJECT/" + value[len(project_s) + 1 :]
    home = str(Path.home())
    if value == home:
        return "$USER_HOME"
    if value.startswith(home + os.sep):
        return "$USER_HOME/" + value[len(home) + 1 :]
    return value


def arrow_type_record(field: pa.Field) -> dict[str, Any]:
    return {
        "name": field.name,
        "type": str(field.type),
        "nullable": bool(field.nullable),
    }


def inspect_parquet(path: Path, project: Path) -> dict[str, Any]:
    parquet = pq.ParquetFile(path)
    metadata = parquet.metadata
    schema = parquet.schema_arrow
    return {
        "path": sanitize_path(path, project),
        "bytes": path.stat().st_size,
        "rows": metadata.num_rows,
        "row_groups": metadata.num_row_groups,
        "columns": metadata.num_columns,
        "created_by": metadata.created_by,
        "schema": [arrow_type_record(field) for field in schema],
        "schema_names": list(schema.names),
    }


def inspect_delimited_header(path: Path, delimiter: str) -> dict[str, Any]:
    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        reader = csv.reader(stream, delimiter=delimiter)
        header = next(reader, [])
    return {
        "columns": len(header),
        "schema_names": header,
    }


def inspect_json_shape(path: Path) -> dict[str, Any]:
    if path.stat().st_size > 20 * 1024 * 1024:
        return {"shape": "not_read_large_json"}
    value = load_json(path)
    if isinstance(value, dict):
        return {"shape": "object", "top_level_keys": sorted(map(str, value.keys()))}
    if isinstance(value, list):
        first_keys: list[str] = []
        if value and isinstance(value[0], dict):
            first_keys = sorted(map(str, value[0].keys()))
        return {
            "shape": "array",
            "items": len(value),
            "first_object_keys": first_keys,
        }
    return {"shape": type(value).__name__}


def candidate_columns(names: Iterable[str]) -> dict[str, list[str]]:
    groups = {
        "normalized_username": [],
        "return_status": [],
        "patron_status": [],
        "acquisition_role": [],
        "match_cell_or_set": [],
        "control_rank": [],
        "raw_or_lossless_json": [],
        "created_at": [],
        "seen_at": [],
        "playtime": [],
        "game_counts": [],
        "bot_or_title": [],
    }
    for name in names:
        lowered = name.casefold()
        if "username" in lowered or lowered in {"user", "user_norm", "userid"}:
            groups["normalized_username"].append(name)
        if any(token in lowered for token in ("returned", "return_status", "http_status")):
            groups["return_status"].append(name)
        if "patron" in lowered:
            groups["patron_status"].append(name)
        if "role" in lowered or "assignment" in lowered:
            groups["acquisition_role"].append(name)
        if "match" in lowered or "cell" in lowered or "stratum" in lowered:
            groups["match_cell_or_set"].append(name)
        if "rank" in lowered or "control_index" in lowered:
            groups["control_rank"].append(name)
        if "json" in lowered or "raw_profile" in lowered or "lossless" in lowered:
            groups["raw_or_lossless_json"].append(name)
        if "created" in lowered:
            groups["created_at"].append(name)
        if "seen" in lowered or "last_online" in lowered:
            groups["seen_at"].append(name)
        if "playtime" in lowered or "play_time" in lowered:
            groups["playtime"].append(name)
        if "count" in lowered or "games" in lowered or "perfs" in lowered:
            groups["game_counts"].append(name)
        if "bot" in lowered or "title" in lowered:
            groups["bot_or_title"].append(name)
    return {key: sorted(set(values)) for key, values in groups.items()}


def verify_equal(label: str, observed: Any, expected: Any) -> None:
    if observed != expected:
        raise RuntimeError(
            f"AUTHORITY MISMATCH: {label}: expected {expected!r}, observed {observed!r}"
        )


def find_profile_audit(profile_root: Path) -> tuple[Path, dict[str, Any]]:
    candidates: list[tuple[Path, dict[str, Any]]] = []
    for path in sorted(profile_root.rglob("*.json")):
        if path.stat().st_size > 20 * 1024 * 1024:
            continue
        try:
            value = load_json(path)
        except Exception:
            continue
        if not isinstance(value, dict):
            continue
        if value.get("status") == "PROFILE_SNAPSHOT_24M_CERTIFIED_OK":
            candidates.append((path, value))
    if not candidates:
        raise RuntimeError(
            "Expected at least one PROFILE_SNAPSHOT_24M_CERTIFIED_OK JSON under "
            f"{profile_root}; found none"
        )
    valid: list[tuple[Path, dict[str, Any]]] = []
    errors: list[str] = []
    for path, value in candidates:
        try:
            validate_profile_audit(value)
        except Exception as error:
            errors.append(f"{path}: {error}")
        else:
            valid.append((path, value))
    if not valid:
        raise RuntimeError(
            "No profile certification JSON matched the frozen authority. "
            + " | ".join(errors)
        )
    valid.sort(
        key=lambda item: (
            0 if item[0].name == "_SUCCESS.json" else 1,
            0 if "summary" in item[0].name.casefold() else 1,
            str(item[0]),
        )
    )
    return valid[0]


def validate_profile_audit(value: dict[str, Any]) -> None:
    qa = value.get("final_qa") or {}
    verify_equal("profile status", value.get("status"), "PROFILE_SNAPSHOT_24M_CERTIFIED_OK")
    verify_equal("completed batches", value.get("completed_batches"), 4_353)
    verify_equal("expected batches", value.get("expected_batches"), 4_353)
    verify_equal("completed users", value.get("completed_users"), EXPECTED["snapshot_rows"])
    verify_equal("returned profiles", value.get("returned_profiles"), EXPECTED["returned_profiles"])
    verify_equal("normalized rows", qa.get("normalized_rows"), EXPECTED["snapshot_rows"])
    verify_equal("normalized unique users", qa.get("normalized_unique_users"), EXPECTED["snapshot_rows"])
    verify_equal("unreturned profiles", qa.get("unreturned_profiles"), EXPECTED["unreturned_profiles"])
    verify_equal("patrons", qa.get("patrons"), EXPECTED["patrons"])
    verify_equal("unplanned rows", qa.get("unplanned_normalized_rows"), 0)
    verify_equal("planned missing row", qa.get("planned_without_normalized_row"), 0)
    verify_equal("wrong batch rows", qa.get("wrong_batch_rows"), 0)
    verify_equal("snapshot SHA-256 in receipt", qa.get("snapshot_sha256"), EXPECTED["snapshot_sha256"])
    verify_equal("plan-success SHA-256", value.get("plan_success_sha256"), EXPECTED["plan_success_sha256"])
    verify_equal(
        "audit-file-hashes SHA-256",
        value.get("audit_file_hashes_sha256"),
        EXPECTED["audit_file_hashes_sha256"],
    )

    coverage = {
        str(row.get("acquisition_role")): row
        for row in value.get("coverage_by_role", [])
        if isinstance(row, dict)
    }
    verify_equal("kind requested", coverage.get("kind", {}).get("requested"), EXPECTED["kind_requested"])
    verify_equal("kind returned", coverage.get("kind", {}).get("returned"), EXPECTED["kind_returned"])
    verify_equal("kind patrons", coverage.get("kind", {}).get("patrons"), EXPECTED["kind_patrons"])
    verify_equal("control requested", coverage.get("control", {}).get("requested"), EXPECTED["control_requested"])
    verify_equal("control returned", coverage.get("control", {}).get("returned"), EXPECTED["control_returned"])
    verify_equal("control patrons", coverage.get("control", {}).get("patrons"), EXPECTED["control_patrons"])


def locate_stage07_success(stage07_root: Path) -> tuple[Path, dict[str, Any]]:
    preferred = [
        stage07_root / "_SUCCESS.json",
        stage07_root / "_manifests" / "latest_summary.json",
    ]
    for path in preferred:
        if path.is_file() and sha256_file(path) == EXPECTED["stage07_success_sha256"]:
            value = load_json(path)
            if not isinstance(value, dict):
                raise RuntimeError(f"Stage 07 receipt is not a JSON object: {path}")
            return path, value

    matching: list[Path] = []
    for path in stage07_root.rglob("*.json"):
        if path.stat().st_size <= 20 * 1024 * 1024:
            if sha256_file(path) == EXPECTED["stage07_success_sha256"]:
                matching.append(path)
    if len(matching) != 1:
        raise RuntimeError(
            "Could not locate exactly one Stage 07 success receipt with expected SHA-256; "
            f"found {len(matching)}"
        )
    value = load_json(matching[0])
    if not isinstance(value, dict):
        raise RuntimeError(f"Stage 07 receipt is not a JSON object: {matching[0]}")
    return matching[0], value


def validate_stage07(value: dict[str, Any]) -> None:
    global_qa = value.get("global_qa") or value.get("core_qa", {}).get("core") or {}
    status = value.get("status")
    if status is not None:
        verify_equal("Stage 07 status", status, "STAGE07_24M_CERTIFIED_OK")
    verify_equal("Stage 07 rows", global_qa.get("rows"), EXPECTED["stage07_rows"])
    verify_equal("Stage 07 kind draws", global_qa.get("kind_draws"), EXPECTED["stage07_kind_draws"])
    observed_months = global_qa.get("months", value.get("months"))
    if isinstance(observed_months, list):
        observed_months = len(observed_months)
    verify_equal("Stage 07 months", observed_months, EXPECTED["stage07_months"])
    producer_sha = value.get("script_sha256")
    if producer_sha is not None:
        verify_equal("Stage 07 producer SHA-256", producer_sha, EXPECTED["stage07_script_sha256"])


def walk_limited(root: Path, max_depth: int) -> Iterable[Path]:
    if not root.exists():
        return
    root_parts = len(root.parts)
    for current, directories, files in os.walk(root):
        current_path = Path(current)
        depth = len(current_path.parts) - root_parts
        directories[:] = sorted(
            d
            for d in directories
            if not d.startswith(".")
            and d not in {"__pycache__", "venv", "node_modules", "raw", "downloads"}
        )
        if depth >= max_depth:
            directories[:] = []
        for filename in sorted(files):
            if filename.startswith("."):
                continue
            yield current_path / filename


def discover_relevant_files(project: Path) -> list[LocatedFile]:
    roots: list[tuple[str, Path, int]] = [
        ("derived_replication", project / "derived" / "replication", 5),
        ("replication_package", project / "replication_package", 6),
        ("scripts_stockfish", project / "scripts_stockfish", 2),
        ("desktop_staging", Path.home() / "Desktop" / "Lichess_Desktop", 5),
    ]
    found: dict[str, LocatedFile] = {}
    for label, root, depth in roots:
        for path in walk_limited(root, depth) or []:
            lowered = str(path).casefold()
            if not any(token in lowered for token in SOURCE_TOKENS):
                continue
            relative = str(path.relative_to(root))
            found[str(path)] = LocatedFile(path, label, relative)
    return [found[key] for key in sorted(found)]


def inventory_candidate_file(item: LocatedFile, project: Path) -> dict[str, Any]:
    path = item.path
    record: dict[str, Any] = {
        "root_label": item.root_label,
        "relative_path": item.relative_path,
        "path": sanitize_path(path, project),
        "bytes": path.stat().st_size,
        "suffix": path.suffix.casefold(),
    }
    suffix = path.suffix.casefold()
    try:
        if suffix == ".parquet":
            record["tabular"] = inspect_parquet(path, project)
        elif suffix == ".csv":
            record["tabular"] = inspect_delimited_header(path, ",")
        elif suffix == ".tsv":
            record["tabular"] = inspect_delimited_header(path, "\t")
        elif suffix == ".json":
            record["json"] = inspect_json_shape(path)
    except Exception as error:
        record["inspection_error"] = f"{type(error).__name__}: {error}"
    return record


def copy_source_lineage(
    relevant: list[LocatedFile],
    project: Path,
    output_root: Path,
) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    destinations_seen: set[str] = set()

    def consider(path: Path, label: str, relative: str) -> None:
        if not path.is_file() or path.suffix.casefold() not in SOURCE_SUFFIXES:
            return
        if path.stat().st_size > 5 * 1024 * 1024:
            return
        destination = output_root / "source_lineage" / label / relative
        destination_key = str(destination)
        if destination_key in destinations_seen:
            return
        destinations_seen.add(destination_key)
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, destination)
        records.append(
            {
                "source_path": sanitize_path(path, project),
                "copied_relative_path": str(destination.relative_to(output_root)),
                "bytes": path.stat().st_size,
                "sha256": sha256_file(path),
            }
        )

    historical_root = project / "scripts_stockfish"
    for name in HISTORICAL_SCRIPT_NAMES:
        consider(historical_root / name, "historical_patron", name)

    for item in relevant:
        lowered = item.path.name.casefold()
        if any(token in lowered for token in SOURCE_TOKENS):
            consider(item.path, item.root_label, item.relative_path)

    for name in (
        "07_build_analysis_panel.py",
        "08_make_core_paper_results.py",
        "09_build_panel_robustness.py",
    ):
        consider(
            project / "replication_package" / "code" / name,
            "canonical_current",
            name,
        )

    return sorted(records, key=lambda row: row["copied_relative_path"])


def stage07_month_metadata(stage07_root: Path, project: Path) -> dict[str, Any]:
    files = sorted(stage07_root.glob("month=*/analysis_panel.parquet"))
    records: list[dict[str, Any]] = []
    total_rows = 0
    schemas: set[tuple[str, ...]] = set()
    for path in files:
        parquet = pq.ParquetFile(path)
        rows = parquet.metadata.num_rows
        names = tuple(parquet.schema_arrow.names)
        total_rows += rows
        schemas.add(names)
        records.append(
            {
                "month": path.parent.name.removeprefix("month="),
                "path": sanitize_path(path, project),
                "rows": rows,
                "columns": len(names),
                "bytes": path.stat().st_size,
            }
        )
    verify_equal("Stage 07 monthly files", len(files), EXPECTED["stage07_months"])
    verify_equal("Stage 07 metadata row total", total_rows, EXPECTED["stage07_rows"])
    verify_equal("Stage 07 schema variants", len(schemas), 1)
    schema_names = list(next(iter(schemas)))
    verify_equal("Stage 07 physical columns", len(schema_names), EXPECTED["stage07_columns"])
    return {
        "files": records,
        "total_rows": total_rows,
        "schema_names": schema_names,
        "schema_candidates": candidate_columns(schema_names),
    }


def public_profile_audit_summary(value: dict[str, Any], project: Path) -> dict[str, Any]:
    qa = value.get("final_qa") or {}
    return {
        "status": value.get("status"),
        "mode": value.get("mode"),
        "created_utc": value.get("created_utc"),
        "expected_batches": value.get("expected_batches"),
        "completed_batches": value.get("completed_batches"),
        "completed_users": value.get("completed_users"),
        "returned_profiles": value.get("returned_profiles"),
        "remaining_batches": value.get("remaining_batches"),
        "coverage_by_role": value.get("coverage_by_role"),
        "distinct_json_pointer_type_pairs_seen": value.get(
            "distinct_json_pointer_type_pairs_seen"
        ),
        "final_qa": {
            key: qa.get(key)
            for key in (
                "normalized_rows",
                "normalized_unique_users",
                "patrons",
                "planned_rows",
                "planned_unique_users",
                "planned_without_normalized_row",
                "returned_profiles",
                "snapshot_bytes",
                "snapshot_sha256",
                "unplanned_normalized_rows",
                "unreturned_profiles",
                "wrong_batch_rows",
            )
        },
        "interpretation": value.get("interpretation"),
        "plan_success_sha256": value.get("plan_success_sha256"),
        "audit_file_hashes_sha256": value.get("audit_file_hashes_sha256"),
        "auditor_sha256": value.get("auditor_sha256"),
        "auditor_version": value.get("auditor_version"),
        "raw_and_personally_identifying_profile_data": value.get(
            "raw_and_personally_identifying_profile_data"
        ),
    }


def make_report(record: dict[str, Any]) -> str:
    profile = record["profile"]
    mapping = profile["schema_candidates"]
    candidates = record["candidate_files"]
    tabular = [row for row in candidates if "tabular" in row]
    historical = [
        row
        for row in record["source_lineage"]
        if "/historical_patron/" in "/" + row["copied_relative_path"]
    ]
    lines = [
        "# Patron Stage 10 inventory report",
        "",
        f"Created UTC: `{record['created_utc']}`",
        f"Inventory version: `{record['inventory_version']}`",
        "",
        "## Certified authorities",
        "",
        f"- Profile snapshot SHA-256: `{profile['sha256']}`",
        f"- Profile rows: {profile['parquet']['rows']:,}",
        f"- Profile columns: {profile['parquet']['columns']:,}",
        f"- Stage 07 rows: {record['stage07']['monthly_metadata']['total_rows']:,}",
        f"- Stage 07 months: {len(record['stage07']['monthly_metadata']['files'])}",
        "- Authority authentication: PASS",
        "",
        "## Profile-schema mapping candidates",
        "",
    ]
    for key, values in mapping.items():
        rendered = ", ".join(f"`{value}`" for value in values) if values else "NONE FOUND"
        lines.append(f"- {key}: {rendered}")
    lines.extend(
        [
            "",
            "## Located plan/tabular candidates",
            "",
            f"Located {len(tabular)} relevant tabular files. Their schemas are in `candidate_files.json`.",
            "",
        ]
    )
    for row in tabular[:80]:
        tab = row.get("tabular", {})
        lines.append(
            f"- `{row['path']}` — rows={tab.get('rows', 'header-only')}, "
            f"columns={tab.get('columns', 'unknown')}"
        )
    if len(tabular) > 80:
        lines.append(f"- ... {len(tabular) - 80} additional tabular candidates in JSON inventory")
    lines.extend(
        [
            "",
            "## Historical source lineage",
            "",
            f"Recovered {len(historical)} of {len(HISTORICAL_SCRIPT_NAMES)} named historical patron scripts.",
            "",
        ]
    )
    for row in historical:
        lines.append(f"- `{row['copied_relative_path']}` — `{row['sha256']}`")

    match_found = bool(mapping["match_cell_or_set"])
    username_found = bool(mapping["normalized_username"])
    patron_found = bool(mapping["patron_status"] or mapping["raw_or_lossless_json"])
    if username_found and patron_found and (match_found or tabular):
        decision = "READY_FOR_EXACT_MAPPING_REVIEW"
    else:
        decision = "BLOCKED_PENDING_SCHEMA_OR_PLAN_MAPPING"
    record["decision"] = decision
    lines.extend(
        [
            "",
            "## Decision",
            "",
            f"`{decision}`",
            "",
            "This inventory intentionally stops before patron estimation. Review the exact "
            "snapshot and matching-plan mappings, then issue the authenticated production package.",
            "",
            "No account values, usernames, raw profile JSON, patron models, or API requests "
            "were included in this report.",
            "",
        ]
    )
    return "\n".join(lines)


def run_inventory(args: argparse.Namespace) -> Path:
    started = time.monotonic()
    project = args.project.resolve()
    profile_root = args.profile_root.resolve()
    snapshot = args.snapshot.resolve()
    stage07_root = args.stage07_root.resolve()
    output_root = args.output_root.resolve()

    if output_root.exists():
        raise RuntimeError(f"Output root already exists: {output_root}")
    output_root.mkdir(parents=True)

    if not project.is_dir():
        raise RuntimeError(f"Project root missing: {project}")
    if not profile_root.is_dir():
        raise RuntimeError(f"Certified profile root missing: {profile_root}")
    if not snapshot.is_file():
        raise RuntimeError(f"Certified profile snapshot missing: {snapshot}")
    if not stage07_root.is_dir():
        raise RuntimeError(f"Stage 07 root missing: {stage07_root}")

    print("Authenticating 437 MB profile snapshot...", flush=True)
    snapshot_sha = sha256_file(snapshot)
    verify_equal("snapshot SHA-256", snapshot_sha, EXPECTED["snapshot_sha256"])

    audit_path, audit = find_profile_audit(profile_root)
    validate_profile_audit(audit)

    profile_parquet = inspect_parquet(snapshot, project)
    verify_equal("snapshot Parquet rows", profile_parquet["rows"], EXPECTED["snapshot_rows"])

    print("Authenticating Stage 07 receipt and monthly metadata...", flush=True)
    stage07_success_path, stage07_success = locate_stage07_success(stage07_root)
    validate_stage07(stage07_success)
    stage07_metadata = stage07_month_metadata(stage07_root, project)

    stage07_script = project / "replication_package" / "code" / "07_build_analysis_panel.py"
    if not stage07_script.is_file():
        raise RuntimeError(f"Installed Stage 07 producer missing: {stage07_script}")
    stage07_script_sha = sha256_file(stage07_script)
    verify_equal("installed Stage 07 producer", stage07_script_sha, EXPECTED["stage07_script_sha256"])

    print("Discovering matching-plan and source-lineage candidates...", flush=True)
    relevant = discover_relevant_files(project)
    candidate_records: list[dict[str, Any]] = []
    for item in relevant:
        lowered = item.path.name.casefold()
        if item.path.suffix.casefold() in TABULAR_SUFFIXES and any(
            token in lowered for token in PLAN_TOKENS
        ):
            candidate_records.append(inventory_candidate_file(item, project))

    source_records = copy_source_lineage(relevant, project, output_root)

    audit_public = public_profile_audit_summary(audit, project)
    record: dict[str, Any] = {
        "status": "PATRON_STAGE10_INVENTORY_COMPLETE",
        "inventory_version": VERSION,
        "created_utc": utc_now(),
        "runtime_environment": {
            "python": platform.python_version(),
            "platform": platform.platform(),
            "pyarrow": pa.__version__,
        },
        "scope": {
            "api_requests": 0,
            "patron_models_estimated": 0,
            "account_values_read_for_reporting": 0,
            "row_level_identifiers_emitted": 0,
            "source_data_mutations": 0,
            "git_mutations": 0,
        },
        "profile": {
            "root": sanitize_path(profile_root, project),
            "snapshot": sanitize_path(snapshot, project),
            "sha256": snapshot_sha,
            "parquet": profile_parquet,
            "schema_candidates": candidate_columns(profile_parquet["schema_names"]),
            "audit_path": sanitize_path(audit_path, project),
            "audit": audit_public,
        },
        "stage07": {
            "root": sanitize_path(stage07_root, project),
            "success_path": sanitize_path(stage07_success_path, project),
            "success_sha256": EXPECTED["stage07_success_sha256"],
            "script_path": sanitize_path(stage07_script, project),
            "script_sha256": stage07_script_sha,
            "monthly_metadata": stage07_metadata,
        },
        "candidate_files": candidate_records,
        "source_lineage": source_records,
        "expected_authorities": EXPECTED,
    }

    report = make_report(record)
    record["runtime_seconds"] = round(time.monotonic() - started, 3)

    write_json(output_root / "inventory.json", record)
    write_json(output_root / "profile_snapshot_schema.json", profile_parquet)
    write_json(output_root / "profile_audit_redacted.json", audit_public)
    write_json(output_root / "candidate_files.json", candidate_records)
    write_json(output_root / "stage07_month_metadata.json", stage07_metadata)
    write_json(output_root / "source_lineage.json", source_records)
    write_text(output_root / "inventory_report.md", report)

    with (output_root / "source_hashes.tsv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(
            stream,
            fieldnames=["copied_relative_path", "bytes", "sha256", "source_path"],
            delimiter="\t",
            lineterminator="\n",
        )
        writer.writeheader()
        writer.writerows(source_records)

    print("PATRON_STAGE10_INVENTORY_COMPLETE", flush=True)
    print(f"Decision: {record['decision']}", flush=True)
    print(f"Output: {output_root}", flush=True)
    print(f"Runtime seconds: {record['runtime_seconds']}", flush=True)
    return output_root


def run_self_test() -> None:
    with tempfile.TemporaryDirectory(prefix="patron_stage10_inventory_test_") as tmp:
        root = Path(tmp)
        path = root / "fixture.parquet"
        table = pa.table(
            {
                "username_norm": ["fixture_a", "fixture_b"],
                "profile_returned": [True, False],
                "acquisition_role": ["kind", "control"],
                "patron": [True, None],
                "match_cell": ["c1", "c1"],
                "createdAt": [1, None],
                "seenAt": [2, None],
                "playTime_total": [3, None],
                "raw_json": ["{}", None],
            }
        )
        pq.write_table(table, path)
        record = inspect_parquet(path, root)
        verify_equal("self-test rows", record["rows"], 2)
        mapping = candidate_columns(record["schema_names"])
        if not mapping["normalized_username"]:
            raise RuntimeError("Self-test failed to locate username field")
        if not mapping["patron_status"]:
            raise RuntimeError("Self-test failed to locate patron field")
        if not mapping["match_cell_or_set"]:
            raise RuntimeError("Self-test failed to locate match-cell field")
        verify_equal("self-test SHA length", len(sha256_file(path)), 64)
    print("PATRON_STAGE10_INVENTORY_SELF_TEST_OK")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--project", type=Path, default=PROJECT_DEFAULT)
    parser.add_argument("--profile-root", type=Path)
    parser.add_argument("--snapshot", type=Path)
    parser.add_argument("--stage07-root", type=Path)
    parser.add_argument("--output-root", type=Path)
    args = parser.parse_args()
    if args.profile_root is None:
        args.profile_root = args.project / PROFILE_ROOT_REL
    if args.snapshot is None:
        args.snapshot = args.profile_root / SNAPSHOT_NAME
    if args.stage07_root is None:
        args.stage07_root = args.project / STAGE07_ROOT_REL
    if not args.self_test and args.output_root is None:
        parser.error("--output-root is required outside --self-test")
    return args


def main() -> int:
    args = parse_args()
    if args.self_test:
        run_self_test()
        return 0
    run_inventory(args)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("INTERRUPTED", file=sys.stderr)
        raise SystemExit(130)
    except Exception as error:
        print(f"PATRON_STAGE10_INVENTORY_FAIL_CLOSED: {error}", file=sys.stderr)
        raise
