#!/usr/bin/env python3
"""Independent fail-closed verifier for the Stage 10 patron inventory."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


VERSION = "1.0.0"
EXPECTED_SNAPSHOT_SHA256 = (
    "f42f28a6540a65c0a83f0da488663b4adddf60d1001daeed556f1ffbb961e238"
)
EXPECTED_STAGE07_SUCCESS_SHA256 = (
    "8b7010b528ae5c6f1e1a9b517258648204c14c17ca41a2a6796f8ee5a1ed6db7"
)
FORBIDDEN_OUTPUT_SUFFIXES = {
    ".parquet",
    ".arrow",
    ".feather",
    ".pgn",
    ".ndjson",
    ".jsonl",
    ".zst",
    ".bz2",
    ".gz",
}


def sha256_file(path: Path, block_size: int = 8 * 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while True:
            block = stream.read(block_size)
            if not block:
                break
            digest.update(block)
    return digest.hexdigest()


def load_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as stream:
        return json.load(stream)


def atomic_json(path: Path, value: Any) -> None:
    temporary = path.with_name(path.name + f".tmp.{os.getpid()}")
    with temporary.open("w", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, sort_keys=True, ensure_ascii=True)
        stream.write("\n")
    temporary.replace(path)


def verify(root: Path, verifier_path: Path) -> dict[str, Any]:
    inventory_path = root / "inventory.json"
    report_path = root / "inventory_report.md"
    if not inventory_path.is_file() or not report_path.is_file():
        raise RuntimeError("Required inventory output is missing")

    inventory = load_json(inventory_path)
    if inventory.get("status") != "PATRON_STAGE10_INVENTORY_COMPLETE":
        raise RuntimeError("Inventory status is not complete")
    if inventory.get("decision") not in {
        "READY_FOR_EXACT_MAPPING_REVIEW",
        "BLOCKED_PENDING_SCHEMA_OR_PLAN_MAPPING",
    }:
        raise RuntimeError("Inventory decision is missing or invalid")

    profile = inventory.get("profile") or {}
    stage07 = inventory.get("stage07") or {}
    if profile.get("sha256") != EXPECTED_SNAPSHOT_SHA256:
        raise RuntimeError("Snapshot authority changed")
    if stage07.get("success_sha256") != EXPECTED_STAGE07_SUCCESS_SHA256:
        raise RuntimeError("Stage 07 authority changed")

    scope = inventory.get("scope") or {}
    for key in (
        "api_requests",
        "patron_models_estimated",
        "account_values_read_for_reporting",
        "row_level_identifiers_emitted",
        "source_data_mutations",
        "git_mutations",
    ):
        if scope.get(key) != 0:
            raise RuntimeError(f"Forbidden scope count is nonzero: {key}")

    copied = inventory.get("source_lineage") or []
    for row in copied:
        relative = row.get("copied_relative_path")
        expected_sha = row.get("sha256")
        if not relative or not expected_sha:
            raise RuntimeError("Malformed source-lineage row")
        path = root / relative
        if not path.is_file():
            raise RuntimeError(f"Copied source is missing: {relative}")
        if sha256_file(path) != expected_sha:
            raise RuntimeError(f"Copied source SHA mismatch: {relative}")

    files: list[Path] = []
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        if path.name in {"_SUCCESS.json", "report_file_hashes.tsv"}:
            continue
        if path.suffix.casefold() in FORBIDDEN_OUTPUT_SUFFIXES:
            raise RuntimeError(f"Forbidden row-data suffix in output: {path}")
        files.append(path)

    manifest_path = root / "report_file_hashes.tsv"
    with manifest_path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream, delimiter="\t", lineterminator="\n")
        writer.writerow(["relative_path", "bytes", "sha256"])
        for path in files:
            writer.writerow(
                [
                    str(path.relative_to(root)),
                    path.stat().st_size,
                    sha256_file(path),
                ]
            )

    success = {
        "status": "PATRON_STAGE10_INVENTORY_VERIFIED_OK",
        "verifier_version": VERSION,
        "verifier_sha256": sha256_file(verifier_path),
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "inventory_sha256": sha256_file(inventory_path),
        "inventory_report_sha256": sha256_file(report_path),
        "report_file_hashes_sha256": sha256_file(manifest_path),
        "files_authenticated": len(files),
        "decision": inventory.get("decision"),
        "privacy": {
            "row_level_profile_data_in_output": False,
            "raw_profile_json_in_output": False,
            "usernames_in_inventory_tables": False,
            "source_code_lineage_included": True,
        },
    }
    atomic_json(root / "_SUCCESS.json", success)
    return success


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-root", type=Path)
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if not args.self_test and args.output_root is None:
        parser.error("--output-root is required outside --self-test")
    return args


def self_test() -> None:
    with tempfile.TemporaryDirectory(prefix="patron_stage10_verify_test_") as temporary:
        root = Path(temporary)
        copied = root / "source_lineage" / "fixture.py"
        copied.parent.mkdir(parents=True)
        copied.write_text("print('fixture')\n", encoding="utf-8")
        inventory = {
            "status": "PATRON_STAGE10_INVENTORY_COMPLETE",
            "decision": "READY_FOR_EXACT_MAPPING_REVIEW",
            "profile": {"sha256": EXPECTED_SNAPSHOT_SHA256},
            "stage07": {"success_sha256": EXPECTED_STAGE07_SUCCESS_SHA256},
            "scope": {
                "api_requests": 0,
                "patron_models_estimated": 0,
                "account_values_read_for_reporting": 0,
                "row_level_identifiers_emitted": 0,
                "source_data_mutations": 0,
                "git_mutations": 0,
            },
            "source_lineage": [
                {
                    "copied_relative_path": "source_lineage/fixture.py",
                    "sha256": sha256_file(copied),
                }
            ],
        }
        atomic_json(root / "inventory.json", inventory)
        (root / "inventory_report.md").write_text("# Fixture\n", encoding="utf-8")
        result = verify(root, Path(__file__).resolve())
        if result.get("status") != "PATRON_STAGE10_INVENTORY_VERIFIED_OK":
            raise RuntimeError("Verifier self-test status mismatch")
        if not (root / "_SUCCESS.json").is_file():
            raise RuntimeError("Verifier self-test did not create success receipt")
    print("PATRON_STAGE10_INVENTORY_VERIFIER_SELF_TEST_OK")


def main() -> int:
    args = parse_args()
    if args.self_test:
        self_test()
        return 0
    root = args.output_root.resolve()
    if not root.is_dir():
        raise RuntimeError(f"Inventory output root is missing: {root}")
    success = verify(root, Path(__file__).resolve())
    print("PATRON_STAGE10_INVENTORY_VERIFIED_OK")
    print(f"Decision: {success['decision']}")
    print(f"Files authenticated: {success['files_authenticated']}")
    print(f"Output: {root}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f"PATRON_STAGE10_INVENTORY_VERIFY_FAIL_CLOSED: {error}", file=sys.stderr)
        raise
