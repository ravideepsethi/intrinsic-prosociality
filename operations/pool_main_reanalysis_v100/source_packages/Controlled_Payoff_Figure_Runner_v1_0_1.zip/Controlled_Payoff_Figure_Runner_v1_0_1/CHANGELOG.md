# Changelog

## 1.0.1 — 2026-09-07

- Quote the reserved Stage07 `month` identifier in every DuckDB query.
- Rename the public month-inventory column to `source_month`.
- Use explicit `AS` aliases throughout the staging SQL for parser portability.
- Separate structural source checks from certified authority checks so the
  production path can be exercised on a miniature 24-month test fixture.
- Preserve the v1.0.0 estimand, controls, fixed effects, inference, privacy
  boundary, and authenticated numerical benchmarks without modification.
