#!/usr/bin/env python3
"""Exercise the production Stage07 staging path on a miniature 24-month panel."""

from __future__ import annotations

import tempfile
from pathlib import Path

import duckdb
import numpy as np
import pandas as pd

import controlled_payoff_figure as runner


def fixture_frame(month: str, month_index: int, spec: dict[str, object]) -> pd.DataFrame:
    centers = np.asarray([row["payoff_center"] for row in spec["rows"]], dtype=float)
    r = np.tile(centers, 2)
    n = len(r)
    sequence = np.arange(n)
    kappa = 6.5 + 0.05 * ((sequence + month_index) % 5)
    chooser_rating = 1450.0 + 17.0 * month_index + 3.0 * (sequence % 11)
    gap = 40.0 * r + ((sequence % 7) - 3)
    chooser = f"fixture_chooser_{month_index:02d}"
    return pd.DataFrame(
        {
            "game_id": [f"fixture_{month_index:02d}_{i:03d}" for i in sequence],
            "chooser_user_id": [chooser] * n,
            "api_speed": [runner.POOLS[month_index % len(runner.POOLS)]] * n,
            "month": [month] * n,
            "outcome_kind_draw": ((sequence + month_index) % 17 == 0).astype(np.int8),
            "chooser_draw_payoff_v2": r,
            "chooser_win_payoff_v2": r + kappa,
            "chooser_win_premium_v2": kappa,
            "engine_eval_cp_disconnected": -80.0 + 11.0 * (sequence % 37),
            "chooser_pre_rd_v2": 35.0 + (sequence % 23),
            "disconnected_pre_rd_v2": 38.0 + ((sequence * 3) % 29),
            "chooser_elo": chooser_rating,
            "disconnected_elo": chooser_rating + gap,
            "ply_count": 2 + (sequence % 94),
            "tournament_like_event": ((sequence + month_index) % 2).astype(np.int8),
            "chooser_clock_last_obs_s": 10.0 + (sequence % 180),
            "disconnected_clock_last_obs_s": 12.0 + ((sequence * 5) % 180),
        }
    )


def write_fixture(panel: Path, spec: dict[str, object]) -> None:
    con = duckdb.connect()
    try:
        for month_index, month in enumerate(runner.MONTHS):
            month_dir = panel / f"month={month}"
            month_dir.mkdir(parents=True)
            frame = fixture_frame(month, month_index, spec)
            con.register("fixture_month", frame)
            path = month_dir / "analysis_panel.parquet"
            con.execute(
                f"COPY fixture_month TO {runner.sql_quote(path)} "
                "(FORMAT PARQUET, COMPRESSION ZSTD)"
            )
            con.unregister("fixture_month")
    finally:
        con.close()


def main() -> int:
    spec = runner.bin_spec(6.0, 0.25)
    with tempfile.TemporaryDirectory(prefix="controlled_payoff_stage07_test_") as temp:
        root = Path(temp)
        panel = root / "panel"
        public = root / "public"
        private = root / "private"
        public.mkdir()
        private.mkdir()
        write_fixture(panel, spec)
        broad, local, info = runner.stage_certified_panel(
            panel,
            public,
            private,
            spec,
            1.0,
            2,
            "1GB",
            False,
            False,
        )
        expected_rows = len(runner.MONTHS) * len(spec["rows"]) * 2
        assert broad.is_file()
        assert local.is_file()
        assert int(info["broad"]["n"]) == expected_rows
        assert int(info["broad"]["bins"]) == len(spec["rows"])
        assert (public / "tables" / "source_month_inventory.csv").is_file()
        inventory = pd.read_csv(public / "tables" / "source_month_inventory.csv")
        assert inventory["source_month"].astype(str).tolist() == runner.MONTHS
    print("STAGE07_FIXTURE_SELFTEST_PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
