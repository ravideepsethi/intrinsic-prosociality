#!/bin/bash
set -euo pipefail

task_package_dir="$(cd "$(dirname "$0")" && pwd)"
task_project="/Volumes/XT_Pro/lichess_kindness"
task_panel="$task_project/derived/replication/analysis_panel_24m_sf100k"
task_python="${LICHESS_PYTHON:-$(command -v python3)}"
task_threads="${LICHESS_PAYOFF_THREADS:-8}"
task_memory="${LICHESS_PAYOFF_MEMORY:-8GB}"
task_run_id="${LICHESS_PAYOFF_RUN_ID:-$(date -u +%Y%m%dT%H%M%SZ)_$$}"
task_out="$task_project/output/controlled_payoff_figure_v101/$task_run_id"
task_private="$task_project/derived/replication/controlled_payoff_figure_PRIVATE/$task_run_id"
task_log_dir="$task_project/logs/controlled_payoff_figure_v101"
task_log="$task_log_dir/controlled_payoff_figure_${task_run_id}.log"

[[ -d "$task_panel" ]] || {
  echo "ERROR: certified Stage07 panel not found: $task_panel" >&2
  exit 1
}

"$task_python" - <<'PY'
import importlib
missing=[]
for name in ["duckdb","matplotlib","numpy","pandas","pyarrow"]:
    try: importlib.import_module(name)
    except Exception: missing.append(name)
if missing:
    raise SystemExit("Missing Python packages: "+", ".join(missing)+
                     ". Install requirements.txt into the selected LICHESS_PYTHON environment.")
PY

mkdir -p "$task_log_dir"

echo
echo "CONTROLLED DRAW-PAYOFF FIGURE"
echo "Expected runtime: approximately 20-60 minutes on the MacBook."
echo "Expected private scratch: approximately 2-4 GB on XT_Pro."
echo "Threads: $task_threads"
echo "Panel: $task_panel"
echo "Output: $task_out"
echo "Log: $task_log"
echo

export OMP_NUM_THREADS="$task_threads"
export OPENBLAS_NUM_THREADS="$task_threads"
export MKL_NUM_THREADS="$task_threads"
export VECLIB_MAXIMUM_THREADS="$task_threads"
export NUMEXPR_NUM_THREADS="$task_threads"

set +e
/usr/bin/caffeinate -dimsu "$task_python" \
  "$task_package_dir/controlled_payoff_figure.py" \
  --panel "$task_panel" \
  --out "$task_out" \
  --private "$task_private" \
  --threads "$task_threads" \
  --memory "$task_memory" \
  --batch-rows 32768 \
  --payoff-limit 6 \
  --bin-width 0.25 \
  --local-bandwidth 1 \
  --resume \
  --validate-authority \
  2>&1 | /usr/bin/tee "$task_log"
task_status=${PIPESTATUS[0]}
set -e

if [[ "$task_status" -ne 0 ]]; then
  echo
  echo "CONTROLLED PAYOFF FIGURE FAILED"
  echo "Upload the log: $task_log"
  exit "$task_status"
fi

echo
echo "CONTROLLED PAYOFF FIGURE COMPLETE"
echo "Upload these two files:"
echo "  ${task_out}.zip"
echo "  ${task_out}.zip.sha256"
