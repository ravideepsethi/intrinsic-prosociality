# Method note: controlled payoff bins and fitted local shape

The earlier draft figure plotted raw payoff-bin rates alongside a
“residualized + mean” series. The raw series is compositionally confounded:
distance from zero mixes relative strength with the update scale, rating
deviation, board state, and game stage. The new figure therefore estimates the
displayed points and the local fit from controlled models.

## Panel A: controlled data points

For competitive positions with `|r_G| < 6`, the runner estimates a linear
probability model containing 0.25-point payoff-bin indicators, the full control
set, and chooser-by-pool fixed effects. One bin is omitted for identification.
The complete vector of bin effects is then centered by the sample frequency of
each bin and shifted by the fitted-sample outcome mean. Thus the weighted mean
of the plotted adjusted bin levels equals the sample mean; the zero category is
not mechanically set equal to the mean. Confidence intervals use the joint
chooser-clustered covariance matrix, including the covariance induced by the
centering transformation.

## Panel B: fitted local shape

The runner separately estimates the preferred finite-window model on the
underlying opportunities with `|r_G| < 1`, using the same controls and fixed
effects. It includes separate loss-side and gain-side slopes, a right-versus-
left level term, and an exact-zero term. The lines are vertically aligned to
the adjusted bins for display; all reported slopes and their covariance come
from the opportunity-level model, not from a regression through the plotted
bin means.

The runner authenticates this local fit against the completed September 2026
price-shape bridge: loss slope 0.3671, gain slope 0.1717, and loss-minus-gain
0.1954 percentage points per payoff point (clustered SE 0.0325). Failure to
reproduce those values stops the production run.

These are controlled associations. They are not CCT bias-corrected
discontinuity estimates, causal price elasticities, or a separation of a
reference-price response from relative strength near parity.
