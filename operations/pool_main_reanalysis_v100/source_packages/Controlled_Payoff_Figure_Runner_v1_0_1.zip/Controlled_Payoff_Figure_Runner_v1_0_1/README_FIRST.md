# Controlled draw-payoff figure runner v1.0.1

Version 1.0.1 is the DuckDB portability hotfix. It quotes the Stage07 `month`
field, uses non-reserved SQL aliases, and adds a full miniature-panel staging
test. The estimand, controls, fixed effects, inference, and authenticated
benchmarks are unchanged from v1.0.0.

This runner creates the data-driven analogue of the old draft figure. It does
not plot raw payoff-bin rates. It estimates fully adjusted payoff-bin effects,
shifts them back to the fitted-sample mean, and then overlays separate local
linear fits estimated on the underlying observations within one rating point
of zero.

## What is controlled

- chooser-by-pool fixed effects;
- the Glicko-2 update scale / forgone-win premium, `kappa`;
- game-stage bands;
- both players' log rating deviations;
- flexible final-position engine evaluation terms;
- chooser rating, month, tournament status, and both clocks;
- missing-clock indicators.

The sample is the certified November 2023-October 2025 Stage07 panel,
restricted to competitive positions and `|r_G| < 6`. Standard errors are
clustered by chooser. Exact-zero observations are a separate category. The
local fit uses `h=1` and must reproduce the already authenticated controlled
slope difference before the run can complete.

## Expected runtime

Approximately **20-60 minutes** on the MacBook using eight threads. Allow
roughly **2-4 GB** of temporary private storage on `XT_Pro`. The run makes no
network requests and never packages chooser or game identifiers.

## Run on the Mac

Put the downloaded runner ZIP and SHA-256 sidecar in:

```text
/Users/u6025368/Desktop/Lichess_Desktop
```

Then paste this block into Terminal:

```bash
cd /Users/u6025368/Desktop/Lichess_Desktop

shasum -a 256 -c Controlled_Payoff_Figure_Runner_v1_0_1.zip.sha256

ditto -x -k Controlled_Payoff_Figure_Runner_v1_0_1.zip .

chmod 700 \
  Controlled_Payoff_Figure_Runner_v1_0_1/RUN_CONTROLLED_PAYOFF_FIGURE.command

Controlled_Payoff_Figure_Runner_v1_0_1/RUN_CONTROLLED_PAYOFF_FIGURE.command
```

If the required Python packages are not in `python3`, set `LICHESS_PYTHON` to
the project interpreter before running. The launcher checks dependencies and
fails before touching the panel if anything is missing.

The launcher prints its run ID. If a later modeling or rendering step is
interrupted after staging completed, rerun with that same ID:

```bash
export LICHESS_PAYOFF_RUN_ID='<RUN_ID_FROM_THE_LOG>'
Controlled_Payoff_Figure_Runner_v1_0_1/RUN_CONTROLLED_PAYOFF_FIGURE.command
```

The package's release check for the real 24-month staging path can be rerun
without private data:

```bash
python3 Controlled_Payoff_Figure_Runner_v1_0_1/stage07_fixture_selftest.py
```

## What to upload when it finishes

The last lines print two paths. Upload both:

```text
.../controlled_payoff_figure_v101/<RUN_ID>.zip
.../controlled_payoff_figure_v101/<RUN_ID>.zip.sha256
```

The result ZIP contains PDF/PNG/SVG figures, controlled bins in CSV and
Parquet, local-fit results, a caption draft, model coefficients, sample-flow
tables, and an authentication receipt. Private row-level caches stay under
`derived/replication/controlled_payoff_figure_PRIVATE/` and are excluded.
