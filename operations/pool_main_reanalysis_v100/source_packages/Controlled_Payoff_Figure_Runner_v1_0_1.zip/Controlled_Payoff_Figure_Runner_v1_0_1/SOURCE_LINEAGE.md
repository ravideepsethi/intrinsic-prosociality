# Source lineage and authority contract

## Certified input

The production launcher reads exactly:

```text
/Volumes/XT_Pro/lichess_kindness/derived/replication/analysis_panel_24m_sf100k/
  month=YYYY-MM/analysis_panel.parquet
```

It requires the 24 monthly partitions from November 2023 through October
2025 and validates the certified totals before staging:

- 47,587,020 opportunities;
- 669,503 kind draws;
- 17,328,130 competitive/fair rows before the payoff-window and complete-case
  restrictions;
- unique, nonmissing game IDs and binary outcomes.

The payoff fields are the audited v2 reconstruction:
`chooser_draw_payoff_v2`, `chooser_win_payoff_v2`, and
`chooser_win_premium_v2`. The script verifies
`chooser_win_payoff_v2 = chooser_draw_payoff_v2 +
chooser_win_premium_v2` on staged rows.

## Authentication target

The local `|r_G|<1` specification duplicates the completed price-shape bridge's
preferred full-control, chooser-by-pool fixed-effects model. Production stops
unless it reproduces:

| Quantity | Authenticated value |
|---|---:|
| Opportunities | 11,036,021 |
| Chooser-by-pool cells | 1,483,874 |
| Chooser clusters | 1,290,329 |
| Kind draws | 276,094 |
| Loss-side slope | 0.367133 |
| Gain-side slope | 0.171707 |
| Loss-minus-gain slope | 0.195427 |
| Clustered SE of difference | 0.032544 |

The broad `|r_G|<6` controlled-bin model is new output requested for the
figure. It is not assigned an authenticated numerical result in advance; its
sample, rank, dropped terms, hashes, and complete coefficient table are
recorded in the returned receipt.

## Privacy and mutation boundary

The runner creates a new timestamped output and never overwrites the certified
panel or an existing result. The staged Parquets containing chooser/game IDs
are written only below the timestamped private directory. The returned ZIP is
assembled only from aggregate public outputs.
