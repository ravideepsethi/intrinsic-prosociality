#!/bin/bash
set -euo pipefail
IFS=$'\n\t'
umask 077

task_started="$(date +%s)"
task_stamp="$(date '+%Y%m%d_%H%M%S')"
task_project="/Volumes/XT_Pro/lichess_kindness"
task_python="$task_project/venv/bin/python"
task_package_dir="$(cd "$(dirname "$0")" && pwd -P)"
task_auditor="$task_package_dir/09c_audit_patron_profile_snapshot.py"
task_expected_auditor_sha="2b8bd221bb5765ff31535ce594a8acf21ef4183e778a082dadeef39aaf876055"
task_plan="${PROFILE_PLAN_ROOT:-$task_project/derived/replication/patron_profile_acquisition_24m_plan_v100}"
task_fetch1="${PROFILE_FETCH_ROOT_1:-}"
task_fetch2="${PROFILE_FETCH_ROOT_2:-}"
task_output="${PROFILE_AUDIT_ROOT:-$task_project/derived/replication/patron_profile_snapshot_24m_v100_CERTIFIED}"
task_log="$HOME/Desktop/profile_snapshot_final_audit_v100_${task_stamp}.log"

[[ -n "$task_fetch1" ]] || {
  printf 'ERROR: Set PROFILE_FETCH_ROOT_1 to the completed single or dual-1 fetch root.\n' >&2
  exit 1
}

{
  printf 'PROFILE_ACQUISITION_FINAL_AUDIT_V100_START\n'
  printf 'Expected runtime: 5-25 minutes, depending on snapshot size and disk speed.\n'
  printf 'Output: %s\n' "$task_output"
  printf 'Log: %s\n\n' "$task_log"
  [[ -x "$task_python" && -d "$task_plan" && -d "$task_fetch1" ]] || {
    printf 'ERROR: Project Python, plan root, or first fetch root is missing.\n' >&2
    exit 1
  }
  [[ ! -e "$task_output" ]] || {
    printf 'ERROR: Refusing to overwrite existing final audit root.\n' >&2
    exit 1
  }
  task_actual="$(shasum -a 256 "$task_auditor" | awk '{print $1}')"
  [[ "$task_actual" == "$task_expected_auditor_sha" ]] || {
    printf 'ERROR: Packaged auditor SHA mismatch.\n' >&2
    exit 1
  }
  task_args=(--plan-root "$task_plan" --fetch-root "$task_fetch1")
  if [[ -n "$task_fetch2" ]]; then
    [[ -d "$task_fetch2" ]] || { printf 'ERROR: Second fetch root is missing.\n' >&2; exit 1; }
    task_args+=(--fetch-root "$task_fetch2")
  fi
  task_args+=(--output-root "$task_output" --mode final --threads 8 --memory-limit 12GB)

  printf 'FINAL_AUDIT_PREFLIGHT_BEGIN\n'
  "$task_python" "$task_auditor" "${task_args[@]}"
  printf '\nFINAL_AUDIT_EXECUTE_BEGIN\n'
  "$task_python" "$task_auditor" "${task_args[@]}" --execute

  printf '\nFINAL SNAPSHOT INSPECTION\n'
  "$task_python" - "$task_output/_SUCCESS.json" <<'PY'
import json, sys
s = json.load(open(sys.argv[1], encoding="utf-8"))
assert s["status"] == "PROFILE_SNAPSHOT_24M_CERTIFIED_OK"
qa = s["final_qa"]
print("status:", s["status"])
print("requested unique users:", f"{qa['planned_unique_users']:,}")
print("returned profiles:", f"{qa['returned_profiles']:,}")
print("unreturned profiles:", f"{qa['unreturned_profiles']:,}")
print("current patrons:", f"{qa['patrons']:,}")
print("lossless snapshot SHA256:", qa["snapshot_sha256"])
print("coverage by role:")
for row in s["coverage_by_role"]:
    print(" ", row)
PY

  task_elapsed="$(( $(date +%s) - task_started ))"
  printf '\nPROFILE_ACQUISITION_FINAL_AUDIT_V100_COMPLETE\n'
  printf 'Certified private snapshot: %s\n' "$task_output"
  printf 'Log: %s\n' "$task_log"
  printf 'Elapsed seconds: %s\n' "$task_elapsed"
  printf 'No regression, Git commit, push, or public-data export was performed.\n'
} 2>&1 | tee "$task_log"
