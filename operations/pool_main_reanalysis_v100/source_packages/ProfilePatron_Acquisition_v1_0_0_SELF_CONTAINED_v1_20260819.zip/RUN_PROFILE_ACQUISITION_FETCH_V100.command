#!/bin/bash
set -euo pipefail
IFS=$'\n\t'
umask 077

task_started="$(date +%s)"
task_stamp="$(date '+%Y%m%d_%H%M%S')"
task_project="/Volumes/XT_Pro/lichess_kindness"
task_python="$task_project/venv/bin/python"
task_package_dir="$(cd "$(dirname "$0")" && pwd -P)"
task_fetcher="$task_package_dir/09b_fetch_patron_profile_snapshot.py"
task_auditor="$task_package_dir/09c_audit_patron_profile_snapshot.py"
task_expected_fetcher_sha="549d2d7f2102ed7458173c7e45df02a34d36544fb118989c0cb66c3fdf70a0e9"
task_expected_auditor_sha="2b8bd221bb5765ff31535ce594a8acf21ef4183e778a082dadeef39aaf876055"
task_plan="${PROFILE_PLAN_ROOT:-$task_project/derived/replication/patron_profile_acquisition_24m_plan_v100}"
task_assignment="${PROFILE_ASSIGNMENT:-}"
task_max_batches="${PROFILE_MAX_BATCHES:-}"
task_peer_ledger="${PROFILE_PEER_COMPLETION_LEDGER:-}"
task_peer_offline="${PROFILE_PEER_OFFLINE_CONFIRMED:-NO}"

[[ "$task_assignment" == "single" || "$task_assignment" == "work-ascending" || "$task_assignment" == "home-descending" ]] || {
  printf 'ERROR: Set PROFILE_ASSIGNMENT to single, work-ascending, or home-descending.\n' >&2
  exit 1
}
if [[ "$task_assignment" != "single" && "${LICHESS_DUAL_QUOTA_APPROVED:-}" != "YES" ]]; then
  printf 'ERROR: Dual-client execution is locked until Lichess has approved independent quotas.\n' >&2
  printf 'After approval, export LICHESS_DUAL_QUOTA_APPROVED=YES on each client.\n' >&2
  exit 1
fi
if [[ -n "$task_peer_ledger" && ! -f "$task_peer_ledger" ]]; then
  printf 'ERROR: PROFILE_PEER_COMPLETION_LEDGER is not a file: %s\n' "$task_peer_ledger" >&2
  exit 1
fi
if [[ "$task_peer_offline" != "NO" && "$task_peer_offline" != "YES" ]]; then
  printf 'ERROR: PROFILE_PEER_OFFLINE_CONFIRMED must be YES or NO.\n' >&2
  exit 1
fi

task_default_fetch="$task_project/derived/replication/patron_profile_snapshot_24m_v100_fetch_${task_assignment}"
task_fetch="${PROFILE_FETCH_ROOT:-$task_default_fetch}"
task_progress="$task_fetch/progress_reports/${task_stamp}"
task_log="$HOME/Desktop/profile_fetch_${task_assignment}_${task_stamp}.log"

{
  printf 'PROFILE_ACQUISITION_FETCH_V100_START\n'
  if [[ -n "$task_max_batches" ]]; then
    printf 'Expected runtime: about 1-3 minutes for the first batch; later pilot batches are paced 23.2 seconds apart.\n'
    printf 'This invocation is capped at %s newly completed batch(es).\n' "$task_max_batches"
  else
    printf 'Expected runtime per full 120K macro-batch: approximately 2.6-4 hours.\n'
    printf 'The client will stop at 120,000 attempted IDs in a rolling 24-hour window.\n'
  fi
  printf 'Assignment: %s\n' "$task_assignment"
  printf 'Plan: %s\n' "$task_plan"
  printf 'Fetch root: %s\n' "$task_fetch"
  printf 'Peer ledger: %s\n' "${task_peer_ledger:-NONE (allowed only for the initial opposite-end macro)}"
  printf 'Peer offline confirmed: %s\n' "$task_peer_offline"
  printf 'Log: %s\n\n' "$task_log"

  [[ -x "$task_python" && -d "$task_plan" ]] || {
    printf 'ERROR: Project Python or certified acquisition plan is missing.\n' >&2
    exit 1
  }
  for task_spec in \
    "$task_fetcher|$task_expected_fetcher_sha" \
    "$task_auditor|$task_expected_auditor_sha"
  do
    task_file="${task_spec%%|*}"
    task_expected="${task_spec##*|}"
    task_actual="$(shasum -a 256 "$task_file" | awk '{print $1}')"
    [[ "$task_actual" == "$task_expected" ]] || {
      printf 'ERROR: Packaged source SHA mismatch for %s\n' "$task_file" >&2
      exit 1
    }
  done
  printf 'PACKAGE_SOURCE_AUTHENTICATION_OK\n'

  printf '\nFETCH_PLAN_PREFLIGHT_BEGIN\n'
  task_fetch_args=(
    --plan-root "$task_plan"
    --fetch-root "$task_fetch"
    --assignment "$task_assignment"
    --min-interval 23.2
    --timeout 90
  )
  if [[ -n "$task_max_batches" ]]; then
    [[ "$task_max_batches" =~ ^[1-9][0-9]*$ ]] || {
      printf 'ERROR: PROFILE_MAX_BATCHES must be a positive integer.\n' >&2
      exit 1
    }
    task_fetch_args+=(--max-batches "$task_max_batches")
  fi
  if [[ -n "$task_peer_ledger" ]]; then
    task_fetch_args+=(--peer-completion-ledger "$task_peer_ledger")
  fi
  if [[ "$task_peer_offline" == "YES" ]]; then
    task_fetch_args+=(--peer-offline-confirmed)
  fi
  "$task_python" "$task_fetcher" "${task_fetch_args[@]}"

  printf '\nLIVE_API_FETCH_BEGIN\n'
  "$task_python" "$task_fetcher" "${task_fetch_args[@]}" --execute

  printf '\nPOST-RUN_PROGRESS_AUDIT_BEGIN\n'
  "$task_python" "$task_auditor" \
    --plan-root "$task_plan" \
    --fetch-root "$task_fetch" \
    --output-root "$task_progress" \
    --mode progress \
    --threads 8 \
    --memory-limit 12GB \
    --execute

  printf '\nLATEST FETCH SUMMARY\n'
  "$task_python" - "$task_fetch/latest_run_summary.json" "$task_progress/_PROGRESS.json" <<'PY'
import json, sys
run = json.load(open(sys.argv[1], encoding="utf-8"))
progress = json.load(open(sys.argv[2], encoding="utf-8"))
print("run status:", run["status"])
print("active 120K macro-batch:", run.get("active_macro_batch_id"))
print("new batches this run:", f"{run['completed_this_run']:,}")
print("local completed:", f"{run['local_completed_total']:,}", "/", f"{run['assignment_batches']:,}")
print("combined local+peer completed:", f"{run['combined_completed_total']:,}")
print("combined remaining:", f"{run['remaining_combined_batches']:,}")
print("completion ledger:", run["completion_ledger_path"])
print("completion ledger SHA256:", run["completion_ledger_sha256"])
print("all-plan completed batches visible here:", f"{progress['completed_batches']:,}")
print("all-plan remaining batches:", f"{progress['remaining_batches']:,}")
print("profiles returned so far:", f"{progress['returned_profiles']:,}")
print("next eligible UTC:", run.get("next_eligible_utc"))
print("429 responses recorded:", run.get("429_responses_recorded"))
PY

  task_elapsed="$(( $(date +%s) - task_started ))"
  printf '\nPROFILE_ACQUISITION_FETCH_V100_COMPLETE\n'
  printf 'Fetch root: %s\n' "$task_fetch"
  printf 'Progress audit: %s\n' "$task_progress"
  printf 'Log: %s\n' "$task_log"
  printf 'Elapsed seconds: %s\n' "$task_elapsed"
  printf 'SYNC THIS FILE TO THE OTHER LAPTOP BEFORE IT STARTS ANOTHER MACRO-BATCH:\n'
  printf '%s\n' "$task_fetch/completed_macro_batches.json"
  printf 'Raw and normalized profile data are private and must not be committed or published.\n'
} 2>&1 | tee "$task_log"
