# Draft message to Lichess API support

Hello,

I am conducting an academic research project using a locked sample of rated Lichess
games. I need to obtain a one-time current profile snapshot for a pre-selected matched
sample of users through `POST /api/users` with `profile=true` and `rank=true`. The
sample is selected entirely from game behavior before any profile information is
observed; I am not attempting to export all Lichess users.

My client uses batches of at most 300 IDs, makes only one request at a time, waits at
least 23.2 seconds between request starts, caps itself at 7,800 attempted IDs per
rolling 10 minutes and 120,000 attempted IDs per rolling 24 hours, counts retries
against those limits, and waits at least 60 seconds after a 429.

The final matched-sample size and number of batches are recorded in the attached/local
acquisition-plan summary. Because the acquisition is quota-bound, I would like to ask
whether Lichess permits two independent clients on two genuinely separate public
networks, each respecting the published limits, to process opposite ends of one
authenticated batch catalog. The clients exchange completion ledgers so that no user
batch is intentionally queried twice. If those limits are global to the research
project, account, or another identifier rather than independently applicable, I will
use one client and the 120,000-user daily limit in total.

Could you please confirm the permitted arrangement? I am happy to provide the exact
sample size, code, pacing logic, and institutional contact information.

Thank you.
