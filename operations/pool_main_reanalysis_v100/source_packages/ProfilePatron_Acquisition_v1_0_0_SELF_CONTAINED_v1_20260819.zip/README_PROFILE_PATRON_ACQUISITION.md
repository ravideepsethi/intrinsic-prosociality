# 24-month Lichess patron/profile acquisition package

Version 1.0.0 — 2026-08-19

## What this package does

This package creates a new profile snapshot for the locked November 2023 through
October 2025 Intrinsic Prosociality sample. It deliberately separates three tasks:

1. `09a_prepare_patron_profile_acquisition.py` reads the certified Stage 07 panel,
   aggregates to chooser level, performs deterministic 1:3 matching, and creates
   authenticated 300-ID requests nested inside numbered 120,000-user macro-batches.
   It makes **no API requests**.
2. `09b_fetch_patron_profile_snapshot.py` makes serial, rate-limited, resumable bulk
   profile requests and captures the complete returned objects losslessly.
3. `09c_audit_patron_profile_snapshot.py` authenticates completed batches and, after
   full coverage, creates the private consolidated snapshot. It performs no patron
   regression or public-data export.

The first command to run is the no-API preparation launcher. Return its complete
terminal output before starting the live API pilot.

## Scientific sample contract

- Every chooser with at least one kind draw in any board-evaluation state is retained
  in the acquisition universe.
- Fair-state and clearly-worse-state kindness are recorded separately.
- Never-kind controls are selected without replacement within the historical
  fair-opportunity-count-bin × modal-speed cells.
- Up to three controls are selected for each kind chooser. Exact 1:3 groups, thin
  cells, and groups without full support are explicitly identified.
- Control slot 1 supplies a nested deterministic 1:1 robustness sample.
- Profile or patron information has no role in matching or query ordering.
- The old one-year snapshot is not used to exempt users from the new query. Everyone
  in the new matched universe is re-queried during the new acquisition window.

## Lossless private capture contract

For each batch, the fetcher preserves:

- the exact comma-separated request entity and its SHA-256;
- exact response entity bytes and SHA-256;
- all safe response headers and their SHA-256;
- the complete JSON object returned for every user;
- a canonical per-user raw JSON copy in Parquet;
- all common user/profile fields in convenient typed columns;
- a recursive JSON-pointer/type inventory, including undocumented fields;
- explicit requested-but-unreturned user rows;
- request timestamps, statuses, attempts, backoff, and immutable receipts; and
- a restart-persistent rolling rate-limit ledger.

`Set-Cookie` response headers are excluded because they are credentials/session
material rather than profile data. No request uses or requires a Lichess token.

The plan, raw responses, normalized files, biographies, locations, real names, links,
and usernames are private research data. Keep them outside GitHub and do not place them
in a public replication deposit. A later analysis/release stage can anonymize or
suppress fields after their economic relevance has been assessed.

## Rate contract

The documented endpoint is `POST /api/users?profile=true&rank=true` with a plain-text,
comma-separated request body. The official maximum is 300 user IDs per request,
8,000 users per 10 minutes, and 120,000 users per day.

`profile=true` requests the public profile object and `rank=true` requests the
documented performance-rank augmentation. Exact returned JSON remains authoritative,
so additional or newly introduced response fields are retained automatically.

The operational client uses the fastest settings that remain within the published
numeric limits:

- 300 IDs maximum per request;
- one request at a time;
- at least 23.2 seconds between request starts;
- at most 7,800 attempted IDs in every rolling 10 minutes;
- at most 120,000 attempted IDs in every rolling 24 hours;
- every retry counts again against both operational limits;
- a 429 triggers at least a 60-second wait and permanently slower pacing for the
  current fetch root; and
- the daily client stops rather than waiting many hours inside one Terminal process.

Official sources:

- <https://github.com/lichess-org/api/blob/master/doc/specs/tags/users/api-users.yaml>
- <https://github.com/lichess-org/api/blob/master/doc/specs/lichess-api.yaml>
- <https://lichess.org/page/api-tips>

## Two-client rule

The package provides one-client and two-client assignments from the same immutable
plan. The selected users are divided into numbered macro-batches of 120,000 users
(the last may be smaller), each containing up to 400 serial 300-ID API requests.

If there are `N` macro-batches, **both laptops receive all `N`**. The work laptop
traverses `1,2,...,N`; the home laptop traverses `N,N-1,...,1`. Each invocation
starts or resumes only one macro-batch. This full-catalog redundancy means either
laptop can finish every remaining batch if the other fails.

Opposite traversal alone is not a lock. Each fetch root therefore publishes
`completed_macro_batches.json`, a plan-linked, payload-hashed ledger containing every
locally completed request and each complete or partial macro-batch. After the initial
opposite-end macro, copy each ledger to the other laptop and supply it before starting
the next macro. The fetcher skips peer-completed work, will not enter a peer-started
macro, rejects duplicate request-batch claims, and rejects reuse of a stale peer ledger
for a new macro. When only one macro remains, `work-ascending` owns the deterministic
online tie-break and `home-descending` waits. The home laptop can take over that macro
only after the work laptop is confirmed offline.

Do not infer that two laptops automatically receive independent 120,000-user limits.
The dual launch mode is locked unless Lichess has confirmed the proposed independent
network/quota arrangement. After confirmation, set
`LICHESS_DUAL_QUOTA_APPROVED=YES` on both machines and use `work-ascending` on the
work laptop and `home-descending` on the home laptop. Never run `single` together with
either two-laptop assignment.

## Phase 1: no-API preparation

Expected runtime: 3–15 minutes. The launcher authenticates the frozen repository,
the exact Stage 07 receipt, all 24 Parquet schemas, and all packaged source hashes.
It then runs and inspects the full chooser aggregation and matching plan.

Run `RUN_PROFILE_ACQUISITION_PREPARE_V100.command` from the authenticated package.

The canonical output is:

```text
/Volumes/XT_Pro/lichess_kindness/derived/replication/
  patron_profile_acquisition_24m_plan_v100
```

Stop after this phase and inspect the exact user, batch, support, and quota-day counts.

## Phase 2: one-batch API pilot

Expected runtime: about 1–3 minutes. After the plan has been reviewed, open a fresh
Terminal in the extracted package directory and run:

```bash
export PROFILE_ASSIGNMENT="work-ascending"
export PROFILE_MAX_BATCHES="1"
export LICHESS_DUAL_QUOTA_APPROVED="YES"
bash RUN_PROFILE_ACQUISITION_FETCH_V100.command
```

The launcher performs the fetch and an authenticated progress audit in one run.
Return its complete output before removing the one-batch cap.

## Phase 3: daily production

The requested two-laptop production schedule, after independent quotas are confirmed:

```bash
export LICHESS_DUAL_QUOTA_APPROVED="YES"
unset PROFILE_MAX_BATCHES
export PROFILE_ASSIGNMENT="work-ascending"  # work laptop
export PROFILE_PEER_COMPLETION_LEDGER="$HOME/Desktop/home_completed_macro_batches.json"
bash RUN_PROFILE_ACQUISITION_FETCH_V100.command
```

On the home laptop use the same package and certified plan, but set:

```bash
export LICHESS_DUAL_QUOTA_APPROVED="YES"
export PROFILE_ASSIGNMENT="home-descending"
unset PROFILE_MAX_BATCHES
export PROFILE_PEER_COMPLETION_LEDGER="$HOME/Desktop/work_completed_macro_batches.json"
bash RUN_PROFILE_ACQUISITION_FETCH_V100.command
```

Each successful day processes at most one 120,000-user macro-batch per independently
permitted quota (fewer new users if retries consume part of the request allowance).
Re-run after the printed rolling-24-hour eligibility time. Before every new macro after
the first, exchange the newly printed `completed_macro_batches.json` files and point
`PROFILE_PEER_COMPLETION_LEDGER` at the fresh peer copy. Each machine must use a
separate fetch root. Bring both roots together for the final audit. Do not switch
between single and two-laptop assignments after acquisition begins.

If one laptop is unavailable, first ensure it is not still querying. Supply its newest
ledger if one is available, then set `PROFILE_PEER_OFFLINE_CONFIRMED=YES` on the
surviving laptop. This explicitly unlocks failover over the complete catalog. Return
the variable to `NO` before normal dual-client operation resumes.

## Phase 4: final private snapshot audit

Expected runtime: 5–25 minutes.

For a single-client run:

```bash
export PROFILE_FETCH_ROOT_1="/Volumes/XT_Pro/lichess_kindness/derived/replication/patron_profile_snapshot_24m_v100_fetch_single"
unset PROFILE_FETCH_ROOT_2
bash RUN_PROFILE_ACQUISITION_FINAL_AUDIT_V100.command
```

For a two-client run, set `PROFILE_FETCH_ROOT_1` and `PROFILE_FETCH_ROOT_2` to the two
completed roots. Final mode fails closed on any missing, duplicated, unplanned,
mis-batched, modified, or unauthenticated observation.

## Interpretation guardrail

The resulting patron indicator is a current profile snapshot observed after the paper
sample. Without patron start dates, it supports a same-platform cross-domain
association, not a causal claim that kind behavior caused patron adoption.
