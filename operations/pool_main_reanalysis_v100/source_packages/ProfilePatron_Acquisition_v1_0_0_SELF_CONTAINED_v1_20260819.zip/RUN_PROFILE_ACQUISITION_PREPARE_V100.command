#!/bin/bash
set -euo pipefail
IFS=$'\n\t'
umask 077

task_started="$(date +%s)"
task_stamp="$(date '+%Y%m%d_%H%M%S')"
task_project="/Volumes/XT_Pro/lichess_kindness"
task_repo="$task_project/replication_package"
task_python="$task_project/venv/bin/python"
task_stage07="$task_project/derived/replication/analysis_panel_24m_sf100k"
task_package_dir="$(cd "$(dirname "$0")" && pwd -P)"
task_planner="$task_package_dir/09a_prepare_patron_profile_acquisition.py"
task_fetcher="$task_package_dir/09b_fetch_patron_profile_snapshot.py"
task_auditor="$task_package_dir/09c_audit_patron_profile_snapshot.py"
task_expected_planner_sha="aaaa70e119456258c2fd351dca5b59e52cfe6924421fe6103211e6e812f730de"
task_expected_fetcher_sha="549d2d7f2102ed7458173c7e45df02a34d36544fb118989c0cb66c3fdf70a0e9"
task_expected_auditor_sha="2b8bd221bb5765ff31535ce594a8acf21ef4183e778a082dadeef39aaf876055"
task_expected_head="a7ce86a06c406cf7cfbeb4927cdf40ba5bce4bee"
task_expected_origin="https://github.com/ravideepsethi/intrinsic-prosociality.git"
task_output="$task_project/derived/replication/patron_profile_acquisition_24m_plan_v100"
task_log="$HOME/Desktop/profile_acquisition_prepare_v100_${task_stamp}.log"

{
  printf 'PROFILE_ACQUISITION_PREPARE_V100_START\n'
  printf 'Expected runtime: 3-15 minutes.\n'
  printf 'Mode: full 47.6M-row chooser aggregation and deterministic matching; NO API calls.\n'
  printf 'Output: %s\n' "$task_output"
  printf 'Log: %s\n\n' "$task_log"

  [[ -d "$task_project" && -d "$task_repo/.git" && -d "$task_stage07" ]] || {
    printf 'ERROR: Expected project, repository, or certified Stage 07 root is missing.\n' >&2
    exit 1
  }
  [[ -x "$task_python" ]] || {
    printf 'ERROR: Project Python is missing or not executable: %s\n' "$task_python" >&2
    exit 1
  }
  [[ ! -e "$task_output" ]] || {
    printf 'ERROR: Refusing to overwrite existing acquisition plan: %s\n' "$task_output" >&2
    exit 1
  }

  for task_spec in \
    "$task_planner|$task_expected_planner_sha" \
    "$task_fetcher|$task_expected_fetcher_sha" \
    "$task_auditor|$task_expected_auditor_sha"
  do
    task_file="${task_spec%%|*}"
    task_expected="${task_spec##*|}"
    [[ -f "$task_file" ]] || { printf 'ERROR: Missing packaged file: %s\n' "$task_file" >&2; exit 1; }
    task_actual="$(shasum -a 256 "$task_file" | awk '{print $1}')"
    [[ "$task_actual" == "$task_expected" ]] || {
      printf 'ERROR: Packaged source SHA mismatch for %s\n' "$task_file" >&2
      printf 'Expected: %s\nActual:   %s\n' "$task_expected" "$task_actual" >&2
      exit 1
    }
  done
  printf 'PACKAGE_SOURCE_AUTHENTICATION_OK\n'

  task_branch="$(git -C "$task_repo" branch --show-current)"
  task_head="$(git -C "$task_repo" rev-parse HEAD)"
  task_origin="$(git -C "$task_repo" remote get-url origin)"
  task_status="$(git -C "$task_repo" status --porcelain=v1)"
  task_remote="$(git -C "$task_repo" ls-remote --exit-code origin refs/heads/main | awk 'NR==1 {print $1}')"
  [[ "$task_branch" == "main" ]] || { printf 'ERROR: Expected main branch.\n' >&2; exit 1; }
  [[ "$task_origin" == "$task_expected_origin" ]] || { printf 'ERROR: Unexpected Git origin.\n' >&2; exit 1; }
  [[ "$task_head" == "$task_expected_head" && "$task_remote" == "$task_expected_head" ]] || {
    printf 'ERROR: Local or remote Git HEAD differs from frozen Stage 08 provenance.\n' >&2
    printf 'Expected: %s\nLocal:    %s\nRemote:   %s\n' "$task_expected_head" "$task_head" "$task_remote" >&2
    exit 1
  }
  [[ -z "$task_status" ]] || {
    printf 'ERROR: Repository must be clean before sample preparation.\n' >&2
    git -C "$task_repo" status --short >&2
    exit 1
  }
  printf 'FROZEN_REPOSITORY_AUTHENTICATION_OK\n'

  "$task_python" - <<'PY'
import duckdb, pyarrow, requests, sys
print("PYTHON_DEPENDENCIES_OK")
print("python:", sys.version.split()[0])
print("duckdb:", duckdb.__version__)
print("pyarrow:", pyarrow.__version__)
print("requests:", requests.__version__)
PY

  printf '\nPACKAGE_SELF_TESTS_BEGIN\n'
  "$task_python" "$task_planner" --self-test
  "$task_python" "$task_fetcher" --self-test
  "$task_python" "$task_auditor" --self-test
  printf 'PACKAGE_SELF_TESTS_OK\n\n'

  printf 'NO_API_PLAN_PREFLIGHT_BEGIN\n'
  "$task_python" "$task_planner" \
    --stage07-root "$task_stage07" \
    --repo "$task_repo" \
    --output-root "$task_output" \
    --threads 8 \
    --memory-limit 12GB

  printf '\nNO_API_PLAN_EXECUTE_BEGIN\n'
  "$task_python" "$task_planner" \
    --stage07-root "$task_stage07" \
    --repo "$task_repo" \
    --output-root "$task_output" \
    --threads 8 \
    --memory-limit 12GB \
    --execute

  printf '\nACQUISITION PLAN INSPECTION\n'
  "$task_python" - "$task_output/_SUCCESS.json" <<'PY'
import json, sys
summary = json.load(open(sys.argv[1], encoding="utf-8"))
assert summary["status"] == "PROFILE_ACQUISITION_PLAN_CERTIFIED_OK"
chooser = summary["chooser_qa"]
match = summary["matching_qa"]
query = summary["query_plan"]
print("status:", summary["status"])
print("unique chooser universe:", f"{chooser['unique_choosers']:,}")
print("any-state kind choosers acquired:", f"{match['kind_users_acquired']:,}")
print("matched controls acquired:", f"{match['controls_acquired']:,}")
print("total users to query:", f"{query['query_users']:,}")
print("300-ID API requests:", f"{query['api_request_batches']:,}")
print("numbered 120K macro-batches:", query["numbered_120k_macro_batches"])
print("single-client quota days:", query["single_machine_quota_days"])
print("work-laptop full catalog macro-batches:", query["work_ascending_full_catalog_macro_batches"])
print("home-laptop full catalog macro-batches:", query["home_descending_full_catalog_macro_batches"])
print("two-client days if independently permitted:", query["two_machine_completion_days_if_independent_quotas_approved"])
print("coordination:", query["coordination_rule"])
print("exact 1:3 kind groups:", f"{match['exact_1to3_kind_groups']:,}")
print("thin 1:3 cells:", f"{match['thin_1to3_cells']:,}")
print("kind groups without a control:", f"{match['kind_groups_without_controls']:,}")
print("API calls made:", 0)
PY

  printf '\nTHIN-CELL INSPECTION\n'
  "$task_python" - "$task_output/matching_cell_diagnostics.tsv" <<'PY'
import pandas as pd, sys
frame = pd.read_csv(sys.argv[1], sep="\t")
thin = frame[(frame.n_kind > 0) & (~frame.exact_1to3_support.astype(bool))]
print(thin.to_string(index=False) if len(thin) else "No thin kind cells.")
PY

  task_after="$(git -C "$task_repo" status --porcelain=v1)"
  task_head_after="$(git -C "$task_repo" rev-parse HEAD)"
  [[ -z "$task_after" && "$task_head_after" == "$task_expected_head" ]] || {
    printf 'ERROR: Repository changed during no-API preparation.\n' >&2
    git -C "$task_repo" status --short >&2
    exit 1
  }
  task_elapsed="$(( $(date +%s) - task_started ))"
  printf '\nFINAL GIT STATUS\n'
  git -C "$task_repo" status --short --branch
  printf '\nPROFILE_ACQUISITION_PREPARE_V100_COMPLETE\n'
  printf 'Certified plan: %s\n' "$task_output"
  printf 'Log: %s\n' "$task_log"
  printf 'Elapsed seconds: %s\n' "$task_elapsed"
  printf 'No API request, Git change, commit, or push was performed.\n'
  printf 'Return the complete terminal output before beginning the API pilot.\n'
} 2>&1 | tee "$task_log"
