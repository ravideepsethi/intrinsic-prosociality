#!/usr/bin/env python3
"""Audit and consolidate one or more lossless profile-fetch roots.

Progress mode reports authenticated completion without requiring every batch.
Final mode fails closed unless the certified query plan is covered exactly once,
then produces the private lossless user snapshot and coverage diagnostics.  It
does not estimate patron regressions or create public data.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import shutil
import sys
import time
import traceback
import uuid
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import duckdb
import pyarrow.parquet as pq


SCRIPT_VERSION = "1.0.0"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def sql_string(value: str | Path) -> str:
    return "'" + str(value).replace("'", "''") + "'"


def atomic_write_text(path: Path, value: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + f".tmp.{uuid.uuid4().hex}")
    with temporary.open("w", encoding="utf-8", newline="") as stream:
        stream.write(value)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def atomic_write_json(path: Path, value: Any) -> None:
    atomic_write_text(path, json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n")


def verify_plan(plan_root: Path) -> tuple[dict[str, Any], str]:
    success_path = plan_root / "_SUCCESS.json"
    manifest_path = plan_root / "plan_file_hashes.tsv"
    if not success_path.is_file() or not manifest_path.is_file():
        raise RuntimeError("Certified acquisition plan is incomplete")
    success = json.loads(success_path.read_text(encoding="utf-8"))
    if success.get("status") != "PROFILE_ACQUISITION_PLAN_CERTIFIED_OK":
        raise RuntimeError("Acquisition plan status is not certified")
    if sha256_file(manifest_path) != success.get("plan_file_hashes_sha256"):
        raise RuntimeError("Acquisition plan hash-manifest SHA mismatch")
    with manifest_path.open(encoding="utf-8", newline="") as stream:
        rows = list(csv.DictReader(stream, delimiter="\t"))
    for row in rows:
        path = plan_root / row["path"]
        if not path.is_file():
            raise RuntimeError(f"Missing acquisition-plan file: {path}")
        if path.stat().st_size != int(row["bytes"]) or sha256_file(path) != row["sha256"]:
            raise RuntimeError(f"Acquisition-plan file changed: {path}")
    return success, sha256_file(success_path)


def read_expected_batches(plan_root: Path) -> dict[str, dict[str, str]]:
    path = plan_root / "query_batches_all.tsv"
    with path.open(encoding="utf-8", newline="") as stream:
        rows = list(csv.DictReader(stream, delimiter="\t"))
    result = {row["batch_id"]: row for row in rows}
    if len(result) != len(rows):
        raise RuntimeError("Certified query plan contains duplicate batch IDs")
    return result


def verify_batch(
    batch_dir: Path,
    expected: dict[str, str],
    plan_success_sha: str,
) -> dict[str, Any]:
    receipt_path = batch_dir / "SUCCESS.json"
    receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
    checks = {
        "status": receipt.get("status") == "PROFILE_BATCH_CERTIFIED_OK",
        "batch_id": receipt.get("batch_id") == expected["batch_id"],
        "batch_index": receipt.get("batch_index") == int(expected["batch_index"]),
        "macro_batch_id": receipt.get("macro_batch_id") == expected["macro_batch_id"],
        "macro_batch_index": receipt.get("macro_batch_index")
        == int(expected["macro_batch_index"]),
        "request_body_sha256": receipt.get("request_body_sha256") == expected["request_body_sha256"],
        "plan_success_sha256": receipt.get("plan_success_sha256") == plan_success_sha,
        "requested_users": (receipt.get("query_diagnostics") or {}).get("requested_users")
        == int(expected["n_users"]),
    }
    failed = [name for name, passed in checks.items() if not passed]
    if failed:
        raise RuntimeError(f"Batch receipt authentication failed at {batch_dir}: {failed}")
    resolved: dict[str, str] = {}
    for key in ("normalized_parquet", "key_inventory", "response_body", "response_headers"):
        item = receipt.get(key) or {}
        path = batch_dir / str(item.get("path", ""))
        if not path.is_file() or path.stat().st_size != int(item.get("bytes", -1)):
            raise RuntimeError(f"Batch artifact missing or wrong size: {path}")
        if sha256_file(path) != item.get("sha256"):
            raise RuntimeError(f"Batch artifact hash mismatch: {path}")
        resolved[key] = str(path.resolve())
    receipt["resolved_paths"] = resolved
    receipt["success_receipt_path"] = str(receipt_path.resolve())
    receipt["success_receipt_sha256"] = sha256_file(receipt_path)
    return receipt


def inventory_fetch_roots(
    fetch_roots: list[Path],
    expected: dict[str, dict[str, str]],
    plan_success_sha: str,
) -> tuple[dict[str, dict[str, Any]], list[dict[str, Any]]]:
    completed: dict[str, dict[str, Any]] = {}
    roots: list[dict[str, Any]] = []
    for root in fetch_roots:
        config_path = root / "fetch_config.json"
        if not config_path.is_file():
            raise RuntimeError(f"Fetch root lacks fetch_config.json: {root}")
        config = json.loads(config_path.read_text(encoding="utf-8"))
        if config.get("plan_success_sha256") != plan_success_sha:
            raise RuntimeError(f"Fetch root points to a different acquisition plan: {root}")
        root_info = {
            "fetch_root": str(root),
            "assignment": config.get("assignment"),
            "config_sha256": sha256_file(config_path),
            "successful_batches": 0,
        }
        for success_path in sorted((root / "batches").glob("*/SUCCESS.json")):
            batch_id = success_path.parent.name
            if batch_id not in expected:
                raise RuntimeError(f"Fetch root contains unplanned batch: {batch_id}")
            if batch_id in completed:
                raise RuntimeError(
                    f"Batch was fetched more than once across supplied roots: {batch_id}"
                )
            completed[batch_id] = verify_batch(
                success_path.parent, expected[batch_id], plan_success_sha
            )
            root_info["successful_batches"] += 1
        roots.append(root_info)
    return completed, roots


def sum_key_inventories(receipts: dict[str, dict[str, Any]], output_path: Path) -> int:
    counter: Counter[tuple[str, str]] = Counter()
    for receipt in receipts.values():
        path = Path(receipt["resolved_paths"]["key_inventory"])
        with path.open(encoding="utf-8", newline="") as stream:
            for row in csv.DictReader(stream, delimiter="\t"):
                counter[(row["json_pointer"], row["json_type"])] += int(row["occurrences"])
    lines = ["json_pointer\tjson_type\toccurrences"]
    lines.extend(
        f"{pointer}\t{kind}\t{count}"
        for (pointer, kind), count in sorted(counter.items())
    )
    atomic_write_text(output_path, "\n".join(lines) + "\n")
    return len(counter)


def write_batch_receipt_manifest(receipts: dict[str, dict[str, Any]], path: Path) -> None:
    lines = [
        "batch_id\tbatch_index\trequested\treturned\tunreturned\t"
        "success_receipt_sha256\tsuccess_receipt_path"
    ]
    for batch_id, receipt in sorted(receipts.items(), key=lambda item: item[1]["batch_index"]):
        qa = receipt["query_diagnostics"]
        lines.append(
            "\t".join(
                [
                    batch_id,
                    str(receipt["batch_index"]),
                    str(qa["requested_users"]),
                    str(qa["returned_users"]),
                    str(qa["unreturned_users"]),
                    receipt["success_receipt_sha256"],
                    receipt["success_receipt_path"],
                ]
            )
        )
    atomic_write_text(path, "\n".join(lines) + "\n")


def database_config(database: duckdb.DuckDBPyConnection, temp_dir: Path, args: argparse.Namespace) -> None:
    temp_dir.mkdir(parents=True, exist_ok=True)
    database.execute(f"SET threads = {int(args.threads)}")
    database.execute(f"SET memory_limit = {sql_string(args.memory_limit)}")
    database.execute(f"SET temp_directory = {sql_string(temp_dir)}")
    database.execute("SET preserve_insertion_order = false")


def table_row(database: duckdb.DuckDBPyConnection, query: str) -> dict[str, Any]:
    values = database.execute(query).fetchone()
    names = [item[0] for item in database.description]
    return dict(zip(names, values))


def final_consolidation(
    database: duckdb.DuckDBPyConnection,
    plan_root: Path,
    receipts: dict[str, dict[str, Any]],
    output_root: Path,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    normalized = [
        receipt["resolved_paths"]["normalized_parquet"]
        for _, receipt in sorted(receipts.items(), key=lambda item: item[1]["batch_index"])
    ]
    normalized_sql = ", ".join(sql_string(path) for path in normalized)
    plan_path = plan_root / "acquisition_users_private.parquet"
    database.execute(
        f"CREATE VIEW normalized AS SELECT * FROM read_parquet([{normalized_sql}], union_by_name=true)"
    )
    database.execute(
        f"CREATE VIEW planned AS SELECT * FROM read_parquet({sql_string(plan_path)})"
    )
    qa = table_row(
        database,
        """
        SELECT
          (SELECT COUNT(*) FROM planned)::BIGINT AS planned_rows,
          (SELECT COUNT(DISTINCT username_norm) FROM planned)::BIGINT AS planned_unique_users,
          (SELECT COUNT(*) FROM normalized)::BIGINT AS normalized_rows,
          (SELECT COUNT(DISTINCT username_norm) FROM normalized)::BIGINT AS normalized_unique_users,
          (SELECT COUNT(*) FROM normalized WHERE returned)::BIGINT AS returned_profiles,
          (SELECT COUNT(*) FROM normalized WHERE NOT returned)::BIGINT AS unreturned_profiles,
          (SELECT COUNT(*) FROM normalized WHERE returned AND patron)::BIGINT AS patrons,
          (SELECT COUNT(*) FROM planned p LEFT JOIN normalized n USING (username_norm)
             WHERE n.username_norm IS NULL)::BIGINT AS planned_without_normalized_row,
          (SELECT COUNT(*) FROM normalized n LEFT JOIN planned p USING (username_norm)
             WHERE p.username_norm IS NULL)::BIGINT AS unplanned_normalized_rows,
          (SELECT COUNT(*) FROM normalized n JOIN planned p USING (username_norm)
             WHERE n.batch_index <> p.canonical_batch_index)::BIGINT AS wrong_batch_rows,
          (SELECT COUNT(*) FROM normalized
             WHERE username_norm <> lower(trim(username_norm)))::BIGINT AS nonnormalized_usernames
        """,
    )
    fail_fields = [
        "planned_without_normalized_row",
        "unplanned_normalized_rows",
        "wrong_batch_rows",
        "nonnormalized_usernames",
    ]
    failures = [f"{name}={qa[name]}" for name in fail_fields if int(qa[name]) != 0]
    if int(qa["planned_rows"]) != int(qa["planned_unique_users"]):
        failures.append("planned usernames not unique")
    if int(qa["normalized_rows"]) != int(qa["normalized_unique_users"]):
        failures.append("normalized usernames not unique")
    if int(qa["planned_rows"]) != int(qa["normalized_rows"]):
        failures.append("planned and normalized row counts differ")
    if failures:
        raise RuntimeError("Final profile-snapshot QA failed: " + ", ".join(failures))

    snapshot_path = output_root / "profile_snapshot_24m_private_lossless.parquet"
    database.execute(
        f"""
        COPY (
          SELECT
            p.*,
            n.* EXCLUDE (username_norm)
          FROM planned p
          JOIN normalized n USING (username_norm)
          ORDER BY p.query_index
        ) TO {sql_string(snapshot_path)}
        (FORMAT PARQUET, COMPRESSION ZSTD, ROW_GROUP_SIZE 250000)
        """
    )
    written_rows = pq.ParquetFile(snapshot_path).metadata.num_rows
    if written_rows != int(qa["planned_rows"]):
        raise RuntimeError("Written private snapshot row count differs from certified QA")

    coverage_path = output_root / "coverage_by_acquisition_role.tsv"
    database.execute(
        f"""
        COPY (
          SELECT
            p.acquisition_role,
            COUNT(*)::BIGINT AS requested_users,
            SUM(CAST(n.returned AS INTEGER))::BIGINT AS returned_profiles,
            SUM(CAST(NOT n.returned AS INTEGER))::BIGINT AS unreturned_profiles,
            SUM(CAST(n.patron AS INTEGER)) FILTER (WHERE n.returned)::BIGINT AS patrons,
            AVG(CAST(n.patron AS INTEGER)) FILTER (WHERE n.returned)::DOUBLE AS patron_rate_returned,
            AVG(CAST(n.profile_present AS INTEGER)) FILTER (WHERE n.returned)::DOUBLE
              AS profile_object_rate_returned
          FROM planned p JOIN normalized n USING (username_norm)
          GROUP BY p.acquisition_role ORDER BY p.acquisition_role
        ) TO {sql_string(coverage_path)} (HEADER, DELIMITER '\t')
        """
    )
    cell_coverage_path = output_root / "coverage_by_match_cell.tsv"
    database.execute(
        f"""
        COPY (
          SELECT
            p.match_cell,
            p.acquisition_role,
            COUNT(*)::BIGINT AS requested_users,
            SUM(CAST(n.returned AS INTEGER))::BIGINT AS returned_profiles,
            SUM(CAST(NOT n.returned AS INTEGER))::BIGINT AS unreturned_profiles,
            SUM(CAST(n.patron AS INTEGER)) FILTER (WHERE n.returned)::BIGINT AS patrons,
            AVG(CAST(n.patron AS INTEGER)) FILTER (WHERE n.returned)::DOUBLE AS patron_rate_returned
          FROM planned p JOIN normalized n USING (username_norm)
          GROUP BY p.match_cell, p.acquisition_role
          ORDER BY p.match_cell, p.acquisition_role
        ) TO {sql_string(cell_coverage_path)} (HEADER, DELIMITER '\t')
        """
    )
    missing_path = output_root / "unreturned_profiles_private.tsv"
    database.execute(
        f"""
        COPY (
          SELECT
            p.username_norm, p.acquisition_role, p.matched_kind_chooser_id,
            p.control_slot, p.match_cell, n.queried_at_utc, n.batch_id
          FROM planned p JOIN normalized n USING (username_norm)
          WHERE NOT n.returned
          ORDER BY p.username_norm
        ) TO {sql_string(missing_path)} (HEADER, DELIMITER '\t')
        """
    )
    coverage_rows = database.execute(
        """
        SELECT
          p.acquisition_role,
          COUNT(*)::BIGINT AS requested,
          SUM(CAST(n.returned AS INTEGER))::BIGINT AS returned,
          SUM(CAST(n.patron AS INTEGER)) FILTER (WHERE n.returned)::BIGINT AS patrons
        FROM planned p JOIN normalized n USING (username_norm)
        GROUP BY p.acquisition_role ORDER BY p.acquisition_role
        """
    ).fetchall()
    coverage = [
        {"acquisition_role": row[0], "requested": int(row[1]), "returned": int(row[2]), "patrons": int(row[3] or 0)}
        for row in coverage_rows
    ]
    qa["snapshot_path"] = str(snapshot_path)
    qa["snapshot_sha256"] = sha256_file(snapshot_path)
    qa["snapshot_bytes"] = snapshot_path.stat().st_size
    return qa, coverage


def write_hash_manifest(output_root: Path) -> str:
    excluded = {"audit_file_hashes.tsv", "_SUCCESS.json", "_PROGRESS.json"}
    files = sorted(path for path in output_root.iterdir() if path.is_file() and path.name not in excluded)
    lines = ["sha256\tbytes\tpath"]
    lines.extend(f"{sha256_file(path)}\t{path.stat().st_size}\t{path.name}" for path in files)
    atomic_write_text(output_root / "audit_file_hashes.tsv", "\n".join(lines) + "\n")
    return sha256_file(output_root / "audit_file_hashes.tsv")


def execute(
    args: argparse.Namespace,
    plan: dict[str, Any],
    plan_success_sha: str,
    expected: dict[str, dict[str, str]],
    completed: dict[str, dict[str, Any]],
    root_info: list[dict[str, Any]],
) -> dict[str, Any]:
    started = time.time()
    output_root = args.output_root.resolve()
    if output_root.exists():
        raise RuntimeError(f"Refusing to overwrite audit output root: {output_root}")
    output_root.parent.mkdir(parents=True, exist_ok=True)
    temporary = output_root.with_name(output_root.name + f".tmp.{uuid.uuid4().hex}")
    temporary.mkdir(mode=0o700)
    try:
        expected_ids = set(expected)
        complete_ids = set(completed)
        missing = sorted(expected_ids - complete_ids)
        progress = {
            "status": "PROFILE_FETCH_PROGRESS_OK",
            "created_utc": utc_now(),
            "mode": args.mode,
            "plan_success_sha256": plan_success_sha,
            "expected_batches": len(expected),
            "completed_batches": len(completed),
            "remaining_batches": len(missing),
            "completed_users": sum(
                int(receipt["query_diagnostics"]["requested_users"])
                for receipt in completed.values()
            ),
            "returned_profiles": sum(
                int(receipt["query_diagnostics"]["returned_users"])
                for receipt in completed.values()
            ),
            "fetch_roots": root_info,
            "auditor_version": SCRIPT_VERSION,
            "auditor_sha256": sha256_file(Path(__file__).resolve()),
            "raw_and_personally_identifying_profile_data": "PRIVATE; DO NOT COMMIT OR PUBLISH",
        }
        atomic_write_json(temporary / "progress_summary.json", progress)
        atomic_write_text(temporary / "remaining_batch_ids.txt", "".join(f"{item}\n" for item in missing))
        write_batch_receipt_manifest(completed, temporary / "completed_batch_receipts.tsv")
        key_count = sum_key_inventories(completed, temporary / "profile_json_key_inventory.tsv")
        progress["distinct_json_pointer_type_pairs_seen"] = key_count

        if args.mode == "final":
            if missing:
                raise RuntimeError(
                    f"Final audit requires every batch; {len(missing):,} of {len(expected):,} remain"
                )
            database = duckdb.connect(str(temporary / "audit.duckdb"))
            try:
                database_config(database, temporary / "duckdb_tmp", args)
                qa, coverage = final_consolidation(
                    database, args.plan_root.resolve(), completed, temporary
                )
                qa["snapshot_path"] = str(
                    output_root / "profile_snapshot_24m_private_lossless.parquet"
                )
            finally:
                database.close()
            for unwanted in (temporary / "audit.duckdb", temporary / "duckdb_tmp"):
                if unwanted.is_file():
                    unwanted.unlink()
                elif unwanted.is_dir():
                    shutil.rmtree(unwanted)
            summary = {
                **progress,
                "status": "PROFILE_SNAPSHOT_24M_CERTIFIED_OK",
                "runtime_seconds": round(time.time() - started, 2),
                "final_qa": qa,
                "coverage_by_role": coverage,
                "interpretation": "Current profile/patron snapshot; patron timing and causal adoption are not identified.",
            }
            atomic_write_json(temporary / "final_summary.json", summary)
            manifest_sha = write_hash_manifest(temporary)
            summary["audit_file_hashes_sha256"] = manifest_sha
            atomic_write_json(temporary / "_SUCCESS.json", summary)
        else:
            summary = {
                **progress,
                "runtime_seconds": round(time.time() - started, 2),
            }
            atomic_write_json(temporary / "_PROGRESS.json", summary)
            write_hash_manifest(temporary)
        os.replace(temporary, output_root)
        print(summary["status"])
        print(json.dumps(summary, indent=2, sort_keys=True))
        return summary
    except Exception:
        print(f"FAILED AUDIT TEMPORARY OUTPUT PRESERVED: {temporary}", file=sys.stderr)
        raise


def self_test() -> None:
    with temporary_directory() as root:
        a = root / "a.tsv"
        b = root / "b.tsv"
        a.write_text("json_pointer\tjson_type\toccurrences\n/profile/bio\tstring\t2\n", encoding="utf-8")
        b.write_text("json_pointer\tjson_type\toccurrences\n/profile/bio\tstring\t3\n/patron\tboolean\t1\n", encoding="utf-8")
        receipts = {
            "a": {"resolved_paths": {"key_inventory": str(a)}},
            "b": {"resolved_paths": {"key_inventory": str(b)}},
        }
        out = root / "out.tsv"
        count = sum_key_inventories(receipts, out)
        text = out.read_text(encoding="utf-8")
        if count != 2 or "/profile/bio\tstring\t5" not in text:
            raise RuntimeError("Auditor key-inventory self-test failed")
    print("PROFILE_SNAPSHOT_AUDITOR_SELF_TEST_OK")


class temporary_directory:
    def __enter__(self) -> Path:
        import tempfile

        self._context = tempfile.TemporaryDirectory()
        return Path(self._context.__enter__())

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> Any:
        return self._context.__exit__(exc_type, exc, tb)


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description=__doc__)
    result.add_argument("--plan-root", type=Path)
    result.add_argument("--fetch-root", type=Path, action="append", default=[])
    result.add_argument("--output-root", type=Path)
    result.add_argument("--mode", choices=["progress", "final"], default="progress")
    result.add_argument("--threads", type=int, default=8)
    result.add_argument("--memory-limit", default="12GB")
    result.add_argument("--execute", action="store_true")
    result.add_argument("--self-test", action="store_true")
    return result


def main() -> None:
    os.umask(0o077)
    args = parser().parse_args()
    if args.self_test:
        self_test()
        return
    if args.plan_root is None or args.output_root is None or not args.fetch_root:
        raise SystemExit("--plan-root, at least one --fetch-root, and --output-root are required")
    plan, plan_success_sha = verify_plan(args.plan_root.resolve())
    expected = read_expected_batches(args.plan_root.resolve())
    roots = [path.resolve() for path in args.fetch_root]
    if len(set(roots)) != len(roots):
        raise RuntimeError("Duplicate --fetch-root arguments are not allowed")
    completed, root_info = inventory_fetch_roots(roots, expected, plan_success_sha)
    print("PROFILE_SNAPSHOT_AUDIT_PLAN_OK")
    print(f"mode: {args.mode}")
    print(f"expected_batches: {len(expected):,}")
    print(f"completed_batches: {len(completed):,}")
    print(f"remaining_batches: {len(expected) - len(completed):,}")
    print(f"output_root: {args.output_root.resolve()}")
    if not args.execute:
        print("No audit outputs were written. Re-run with --execute.")
        return
    execute(args, plan, plan_success_sha, expected, completed, root_info)


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"PROFILE_SNAPSHOT_AUDIT_FAIL_CLOSED: {type(exc).__name__}: {exc}", file=sys.stderr)
        traceback.print_exc()
        raise
