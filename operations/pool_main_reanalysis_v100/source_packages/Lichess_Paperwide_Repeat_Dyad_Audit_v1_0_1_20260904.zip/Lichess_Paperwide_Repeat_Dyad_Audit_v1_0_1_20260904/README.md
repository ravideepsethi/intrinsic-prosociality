# Lichess paper-wide repeat-dyad audit v1.0.1

Version 1.0.1 corrects the Patron rematch ranking so that the deterministic
rank is computed only among kind-role accounts that remain kind under each
dyad restriction. It also verifies the 1:3 ratio separately within every
matched cell/group. All completed v1.0.0 private checkpoints are reusable.

This authenticated, resumable package tests whether the paper's results survive
removing repeat focal relationships. It uses the successful v1.0.1 frequent-dyad
census and the certified 47,587,020-row Stage 07 opportunity panel.

## What it estimates

- Structural results: Table 1 forgone-win-premium diagnostics, the five-bin desert
  profile, game stage, price, and relative-strength results on all opportunities,
  24-month singleton dyads, pair count <3, pair count <5, pair count <10, and repeats.
  The main contrasts are exact chooser fixed-effect linear-probability models with
  chooser-clustered CR1 standard errors.
- Persistence/generalization: calendar halves after removing every dyad spanning
  both halves, plus a disjoint opponent-set split. Results are reported at minimum
  2, 4, and 10 opportunities in each half.
- A1: exact frozen A1 model, progressively requiring the later choice to concern a
  different opponent and a singleton/<3/<5 outcome dyad. The exposure was already
  a first-ever rated meeting in the certified history.
- Patron: reconstructs fair opportunities and kindness under each focal-dyad
  restriction, then performs a fresh deterministic 1:3 rematch within restricted
  fair-opportunity-count and modal-speed cells.
- C9: a 4,999-draw conditional randomization after retaining only singleton focal
  opportunities; chooser kind totals and static propensities remain fixed.
- C6 and C7X: scope/classification reports prevent invalid estimand substitutions.
  C6 already uses a first-ever exposure pair. C7X is relationship-specific by
  construction and cannot be converted into a first-meeting estimand.

## Critical interpretation rule

Whole-window pair counts can include games occurring after a focal decision. They
are therefore strict sensitivity restrictions, not pre-treatment covariates. The
ordering-valid structural authority is C7R, which counts only meetings before the
focal decision in certified Lichess history beginning in 2013. Its first-meeting
desert estimate is carried into the output unchanged.

The package never drops every game involving a player who happens to belong to a
frequent pair. That account-wide rule removes almost the full panel and confounds
player activity with the focal relationship. Only the focal chooser-opponent dyad
is restricted.

## Inputs (read only)

Default project root: `/Volumes/XT_Pro/lichess_kindness`

- `derived/replication/analysis_panel_24m_sf100k`
- `derived/replication/frequent_dyad_census_24m_v101_PRIVATE/stage07_frequency_flags_private`
- `derived/replication/dynamic_prosociality_core_v102_PRIVATE`
- `derived/replication/dynamics_campaign1_c9_v100_PRIVATE/b1_c9_session_private.parquet`
- `derived/replication/patron_profile_snapshot_24m_v100_FINAL_CERTIFIED/profile_snapshot_24m_private_lossless.parquet`
- the frozen `10c_estimate_dynamic_prosociality_core.py` producer in the project

The run authenticates the certified Stage 07 success receipt, all expected row
counts, frozen A1 source, and exact dyad joins. It fails rather than silently
changing an estimand.

## Performance and storage

On the observed MacBook Pro (12 logical CPUs, about 18 GiB RAM) the launcher uses:

- 10 DuckDB Parquet scan threads;
- up to 10 independent C9 randomization workers;
- approximately 11.7 GiB DuckDB memory, leaving headroom for macOS and workers;
- ZSTD Parquet private checkpoints on the external SSD.

Expected first-run runtime: **2–6 hours**. A plausible hardware/spill range is
**1–10 hours**. If the C9 checkpoints must do unusually heavy SSD spilling, allow
up to roughly 12 hours. A resumed run with the joined panel and randomization
checkpoints already complete is typically **30–120 minutes**. After the specific
v1.0.0 Patron-stage stop corrected by v1.0.1, expected remaining runtime is
**1–5 hours**, most likely **2–4 hours**, because the joined Stage 07 Parquet and
A1 crosswalk are already cached but C9 may not yet have started.

Allow at least **80 GiB free** on `/Volumes/XT_Pro`. The launcher checks this before
starting. The largest reusable artifact is the private Stage07/dyad joined Parquet.

## Outputs

Private resumable state:

`derived/replication/paperwide_repeat_dyad_audit_v100_PRIVATE`

Aggregate public results:

`output/paperwide_repeat_dyad_audit_v100/<run_id>`

The launcher also creates a ZIP and SHA-256 file on
`/Users/u6025368/Desktop/Lichess_Desktop`. Public output contains no usernames,
user IDs, or game IDs.

Do not run two copies simultaneously against the same private state.
