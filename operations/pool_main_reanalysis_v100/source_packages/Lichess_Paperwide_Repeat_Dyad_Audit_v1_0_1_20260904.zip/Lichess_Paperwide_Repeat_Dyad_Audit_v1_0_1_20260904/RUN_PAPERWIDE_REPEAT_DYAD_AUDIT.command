#!/bin/bash
set -euo pipefail

package_root="$(cd "$(dirname "$0")" && pwd)"
project_root="/Volumes/XT_Pro/lichess_kindness"
desktop_root="/Users/u6025368/Desktop/Lichess_Desktop"
python_bin="$project_root/venv/bin/python"
state_root="$project_root/derived/replication/paperwide_repeat_dyad_audit_v100_PRIVATE"
output_root="$project_root/output/paperwide_repeat_dyad_audit_v100"
log_root="$project_root/logs/paperwide_repeat_dyad_audit_v100"
run_id="$(/bin/date -u +%Y%m%dT%H%M%SZ)"
log_file="$log_root/paperwide_repeat_dyad_audit_${run_id}.log"
execution_pointer="$output_root/execution_${run_id}.json"

/bin/mkdir -p "$desktop_root" "$state_root" "$output_root" "$log_root"
/usr/bin/touch "$log_file"
exec > >(/usr/bin/tee -a "$log_file") 2>&1

echo "PAPERWIDE_REPEAT_DYAD_AUDIT_LAUNCH_BEGIN run_id=$run_id"
echo "Package: $package_root"
echo "Project: $project_root"
echo "Log: $log_file"
echo "Private resumable state: $state_root"

if [[ ! -x "$python_bin" ]]; then
  echo "ERROR: project Python is missing: $python_bin" >&2
  exit 1
fi

logical_cpus="$(/usr/sbin/sysctl -n hw.logicalcpu 2>/dev/null || /usr/bin/getconf _NPROCESSORS_ONLN)"
memory_bytes="$(/usr/sbin/sysctl -n hw.memsize 2>/dev/null || echo 0)"
memory_mib="$((memory_bytes / 1024 / 1024))"
threads="$logical_cpus"
if (( threads > 10 )); then threads=10; fi
if (( threads < 1 )); then threads=1; fi
workers="$threads"

memory_limit_mib="$((memory_mib * 65 / 100))"
if (( memory_limit_mib > 11980 )); then memory_limit_mib=11980; fi
if (( memory_limit_mib < 4096 )); then memory_limit_mib=4096; fi
memory_limit="${memory_limit_mib}MB"

free_kib="$(/bin/df -Pk "$project_root" | /usr/bin/awk 'NR==2 {print $4}')"
minimum_free_kib="$((80 * 1024 * 1024))"
if (( free_kib < minimum_free_kib )); then
  echo "ERROR: at least 80 GiB free is required on the project volume; available KiB=$free_kib" >&2
  exit 1
fi

echo "Detected Mac resources: logical_cpus=$logical_cpus memory_mib=$memory_mib"
echo "Adaptive plan: parquet_scan_threads=$threads c9_workers=$workers memory_limit=$memory_limit"
if [[ -f "$state_root/stage07_with_dyad_frequency_receipt.json" ]]; then
  echo "Resume detected: the completed Stage07/dyad Parquet checkpoint will be reused."
  echo "Expected remaining runtime: 1--5 hours; likely 2--4 hours (C9 randomizations dominate)."
else
  echo "Expected runtime: 2--6 hours; plausible range 1--10 hours (up to about 12 with heavy SSD spilling)."
fi

cd "$package_root"
/usr/bin/shasum -a 256 -c MANIFEST.sha256

"$python_bin" - <<'PY'
import duckdb, numpy, pandas, pyarrow
expected = {"duckdb":"1.5.2","numpy":"2.4.4","pandas":"3.0.3","pyarrow":"24.0.0"}
observed = {"duckdb":duckdb.__version__,"numpy":numpy.__version__,"pandas":pandas.__version__,"pyarrow":pyarrow.__version__}
if observed != expected:
    raise SystemExit(f"Dependency authentication failed: observed={observed} expected={expected}")
print("DEPENDENCIES_AUTHENTICATED_OK", observed)
PY

echo "Running compact production-math test..."
"$python_bin" -u "$package_root/code/test_paperwide_repeat_dyad_audit_v100.py"

export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export MKL_NUM_THREADS=1
export VECLIB_MAXIMUM_THREADS=1
export NUMEXPR_NUM_THREADS=1

command=(
  "$python_bin" -u "$package_root/code/paperwide_repeat_dyad_audit_v100.py"
  --execute
  --project-root "$project_root"
  --state-root "$state_root"
  --output-root "$output_root"
  --execution-pointer "$execution_pointer"
  --run-id "$run_id"
  --threads "$threads"
  --workers "$workers"
  --memory-limit "$memory_limit"
  --c9-randomizations 4999
  --c9-batch 250
)
printf 'COMMAND'
printf ' %q' "${command[@]}"
printf '\n'
"${command[@]}"

result_root="$output_root/$run_id"
"$python_bin" -u "$package_root/code/verify_paperwide_repeat_dyad_audit_v100.py" "$result_root"

desktop_zip="$desktop_root/paperwide_repeat_dyad_audit_v100_${run_id}.zip"
/usr/bin/ditto -c -k --keepParent "$result_root" "$desktop_zip"
(
  cd "$desktop_root"
  /usr/bin/shasum -a 256 "$(basename "$desktop_zip")" > "$(basename "$desktop_zip").sha256"
)

echo "PAPERWIDE_REPEAT_DYAD_AUDIT_LAUNCH_OK"
echo "Aggregate results: $result_root"
echo "Desktop result ZIP: $desktop_zip"
echo "Log: $log_file"
