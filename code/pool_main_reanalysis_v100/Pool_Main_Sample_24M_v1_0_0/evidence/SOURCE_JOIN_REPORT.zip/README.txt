Aggregate source/observed-adjacency join only. No immediate-rematch timing certification. No private row data included.
