Source recovery 1.0.0
Status: SOURCE_RECOVERY_PARTIAL
Certified baseline verified: True
Months with complete verified source coverage: 2023-11, 2023-12, 2024-01, 2024-02, 2024-03, 2024-04, 2024-05, 2024-06, 2024-07, 2024-08, 2024-09, 2024-10, 2024-11, 2024-12, 2025-01, 2025-02, 2025-03, 2025-04, 2025-05, 2025-06, 2025-07
Unresolved months: 2025-08, 2025-09, 2025-10

This report recovers game source for existing Stage 07 opportunities.
Pool counts use verified observed coverage and may be incomplete.
Rematch analysis and empirical re-estimation: NOT RUN.
No API requests, engine work, rating work, or certified input writes.
Missing source remains unknown. source_block is never used as API source.
Raw response and per-game flags remain in the private directory on the local disk.
This private diagnostic contains input paths and hashes, but no per-game rows.
